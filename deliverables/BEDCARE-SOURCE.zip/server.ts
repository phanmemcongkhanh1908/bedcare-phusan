import http from 'node:http';
import path from 'node:path';
import express from 'express';
import { WebSocketServer } from 'ws';
import { ensureDefaultAdminAccount, seedDemoClusterIfEmpty } from './src/server/demoData';
import { BedcareCluster } from './src/server/p2pCluster';
import { createBedcareRouter } from './src/server/router';

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws/p2p' });

  const broadcastClusterSync = () => {
    const msg = JSON.stringify({ type: 'CLUSTER_EVENT_SYNC', timestamp: new Date().toISOString() });
    for (const client of wss.clients) {
      if (client.readyState === 1) {
        client.send(msg);
      }
    }
  };

  const cluster = new BedcareCluster({
    dataDir: path.resolve(process.cwd(), 'data'),
    onClusterUpdate: broadcastClusterSync,
  });
  seedDemoClusterIfEmpty(cluster);
  ensureDefaultAdminAccount(cluster);

  app.use(express.json({ limit: '10mb' }));
  app.use('/api', createBedcareRouter(cluster));

  // Serve generated deliverables for direct download if present
  app.use('/deliverables', express.static(path.resolve(process.cwd(), 'deliverables')));

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`BEDCARE P2P Server đang chạy tại http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Lỗi khởi động server BEDCARE:', err);
  process.exit(1);
});
