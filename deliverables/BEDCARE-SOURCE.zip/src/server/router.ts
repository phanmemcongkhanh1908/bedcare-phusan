import crypto from 'node:crypto';
import express, { type NextFunction, type Request, type Response } from 'express';
import type { UserRole } from '../types/bedcare';
import { evaluateSystemAlerts } from '../utils/alertsEngine';
import {
  calculateBedOccupancyRate,
  calculateStayMetrics,
  computeExpectedDischargeAt,
  type BedDayConfig,
} from '../utils/bedDays';
import { validateRoomAndBeds } from '../utils/roomBedValidation';
import {
  DEFAULT_ADMIN_PASSWORD,
  DEFAULT_STAFF_RESET_PASSWORD,
  MIN_USER_PASSWORD_LENGTH,
  isDefaultAdminAccount,
  validateUserDeleteRule,
  validateUserStatusRule,
  validateUserUpdateRule,
} from '../utils/userAccountRules';
import { predict4HourBedVacancies } from '../utils/vacancyPredictor';
import { buildPatientVitals24h } from '../utils/vitalsTimeline';
import { hashPassword, verifyPassword } from './crypto';
import { getConfigMap } from './db';
import { clearDemoOperationalData, seedDemoClusterIfEmpty } from './demoData';
import {
  BedcareCluster,
  ConsensusConflictError,
  SecurityRejectionError,
} from './p2pCluster';

interface AuthUser {
  id: string;
  username: string;
  full_name: string;
  role: UserRole;
  department_id: string | null;
}

interface AuthedRequest extends Request {
  authUser?: AuthUser;
}

const TOKEN_SECRET = process.env.BEDCARE_AUTH_SECRET || 'BEDCARE-SESSION-HMAC-KEY-2026';

function signSessionToken(user: AuthUser): string {
  const payload = Buffer.from(
    JSON.stringify({ ...user, exp: Date.now() + 24 * 60 * 60 * 1000 }),
    'utf8'
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token: string): AuthUser | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('base64url');
  if (sig.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as AuthUser & { exp: number };
  if (Date.now() > parsed.exp) return null;
  return {
    id: parsed.id,
    username: parsed.username,
    full_name: parsed.full_name,
    role: parsed.role,
    department_id: parsed.department_id,
  };
}

function getDayConfig(cfg: Record<string, string>): BedDayConfig {
  return {
    method: (cfg.day_calculation_method as BedDayConfig['method']) || 'CALENDAR_DAYS',
    dayStartHour: Number(cfg.day_start_hour || '0'),
    includeAdmissionDay: cfg.include_admission_day !== 'false',
    roundingRule: (cfg.rounding_rule as BedDayConfig['roundingRule']) || 'CEIL',
    dueSoonHours: Number(cfg.due_soon_hours || '24'),
  };
}

export function createBedcareRouter(cluster: BedcareCluster) {
  const router = express.Router();

  const requireAuth = (req: AuthedRequest, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) {
      res.status(401).json({ error: 'Vui lòng đăng nhập để tiếp tục.' });
      return;
    }
    const decoded = verifySessionToken(token);
    if (!decoded) {
      res.status(401).json({ error: 'Phiên đăng nhập hết hạn hoặc không hợp lệ.' });
      return;
    }
    // Check live user status in active node SQLite DB (synced across cluster!)
    const db = cluster.getActiveNode().db;
    const liveUser = db.prepare('SELECT id, username, full_name, role, department_id, status FROM users WHERE id = ?').get(decoded.id) as
      | (AuthUser & { status: string })
      | undefined;
    if (!liveUser || liveUser.status !== 'ACTIVE') {
      res.status(403).json({ error: 'Tài khoản đã bị khóa hoặc thu hồi quyền truy cập.' });
      return;
    }
    req.authUser = {
      id: liveUser.id,
      username: liveUser.username,
      full_name: liveUser.full_name,
      role: liveUser.role,
      department_id: liveUser.department_id,
    };
    next();
  };

  const requireRoles = (...allowed: UserRole[]) => {
    return (req: AuthedRequest, res: Response, next: NextFunction) => {
      if (!req.authUser || !allowed.includes(req.authUser.role)) {
        res.status(403).json({ error: 'Tài khoản không có quyền thực hiện thao tác này.' });
        return;
      }
      next();
    };
  };

  const enforceWardScope = (user: AuthUser, targetDeptId: string): boolean => {
    if (user.role === 'WARD_STAFF' && user.department_id && user.department_id !== targetDeptId) {
      return false;
    }
    return true;
  };

  // --- AUTH ---
  router.post('/auth/login', (req, res) => {
    const { username, password } = req.body as { username?: string; password?: string };
    if (!username || !password) {
      res.status(400).json({ error: 'Vui lòng nhập tên đăng nhập và mật khẩu.' });
      return;
    }
    const node = cluster.getActiveNode();
    const userRow = node.db
      .prepare('SELECT * FROM users WHERE username = ?')
      .get(username.trim()) as (AuthUser & { password_hash: string; status: string }) | undefined;

    if (!userRow || !verifyPassword(password, userRow.password_hash)) {
      res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu.' });
      return;
    }
    if (userRow.status !== 'ACTIVE') {
      res.status(403).json({ error: `Tài khoản đang ở trạng thái ${userRow.status}.` });
      return;
    }
    const authUser: AuthUser = {
      id: userRow.id,
      username: userRow.username,
      full_name: userRow.full_name,
      role: userRow.role,
      department_id: userRow.department_id,
    };
    const token = signSessionToken(authUser);
    res.json({
      token,
      user: authUser,
      activeNode: {
        deviceId: node.deviceId,
        nodeName: node.nodeName,
        isCoordinator: node.isCoordinator,
      },
    });
  });

  router.get('/auth/me', requireAuth, (req: AuthedRequest, res) => {
    const node = cluster.getActiveNode();
    res.json({
      user: req.authUser,
      activeNode: {
        deviceId: node.deviceId,
        nodeName: node.nodeName,
        isCoordinator: node.isCoordinator,
        online: node.online,
        partitionGroup: node.partitionGroup,
      },
    });
  });

  // --- HEALTH ---
  router.get('/health', (_req, res) => {
    const active = cluster.getActiveNode();
    res.json({
      ok: true,
      activeNodeId: active.deviceId,
      nodeCount: cluster.nodes.size,
      quorumRequired: cluster.getRequiredQuorum(),
    });
  });

  // --- CLUSTER / NODES / SYNC / CONSENSUS ---
  router.get('/cluster/status', requireAuth, (_req, res) => {
    const active = cluster.getActiveNode();
    const devices = active.db.prepare('SELECT * FROM devices ORDER BY is_coordinator DESC, node_name ASC').all();
    const events = active.db.prepare('SELECT * FROM events ORDER BY sequence_no DESC LIMIT 80').all();
    const syncQueue = active.db.prepare('SELECT * FROM sync_queue ORDER BY created_at DESC LIMIT 80').all();
    const consensusLogs = active.db.prepare('SELECT * FROM consensus_log ORDER BY created_at DESC LIMIT 80').all();
    const conflicts = active.db.prepare('SELECT * FROM conflicts ORDER BY created_at DESC LIMIT 50').all();
    const pendingRequests = active.db.prepare('SELECT * FROM pending_requests ORDER BY created_at DESC LIMIT 50').all();

    const runtimeNodes = Array.from(cluster.nodes.values()).map((n) => ({
      deviceId: n.deviceId,
      nodeName: n.nodeName,
      departmentId: n.departmentId,
      online: n.online,
      revoked: n.revoked,
      isCoordinator: n.isCoordinator,
      partitionGroup: n.partitionGroup,
      lamportClock: n.lamportClock,
      term: n.term,
      eventCount: (n.db.prepare('SELECT COUNT(*) as c FROM events').get() as { c: number }).c,
      pendingSyncCount: (n.db.prepare("SELECT COUNT(*) as c FROM sync_queue WHERE status = 'PENDING'").get() as { c: number }).c,
    }));

    res.json({
      activeNodeId: cluster.activeNodeId,
      quorumRequired: cluster.getRequiredQuorum(),
      runtimeNodes,
      devices,
      events,
      syncQueue,
      consensusLogs,
      conflicts,
      pendingRequests,
    });
  });

  router.post('/cluster/switch-node', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req, res) => {
    const { deviceId } = req.body as { deviceId: string };
    if (!cluster.nodes.has(deviceId)) {
      res.status(404).json({ error: 'Không tìm thấy thiết bị.' });
      return;
    }
    cluster.activeNodeId = deviceId;
    res.json({ activeNodeId: deviceId });
  });

  router.post('/cluster/node-state', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req, res) => {
    const { deviceId, online, isCoordinator, partitionGroup } = req.body as {
      deviceId: string;
      online?: boolean;
      isCoordinator?: boolean;
      partitionGroup?: string;
    };
    cluster.setNodeState(deviceId, { online, isCoordinator, partitionGroup });
    res.json({ ok: true });
  });

  router.post('/cluster/reconcile', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF', 'CASHIER'), async (_req, res) => {
    const result = await cluster.reconcileCluster();
    res.json(result);
  });

  router.post('/cluster/conflicts/:id/resolve', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req, res) => {
    const { resolutionNote } = req.body as { resolutionNote?: string };
    const now = new Date().toISOString();
    for (const node of cluster.nodes.values()) {
      node.db
        .prepare("UPDATE conflicts SET status = 'RESOLVED', resolution_note = ?, resolved_at = ? WHERE id = ?")
        .run(resolutionNote || 'Đã kiểm tra và xác nhận thủ công', now, req.params.id);
    }
    res.json({ ok: true });
  });

  router.post('/cluster/simulate-race', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), async (req: AuthedRequest, res) => {
    const { bedId, nodeIds } = req.body as { bedId: string; nodeIds?: string[] };
    const candidates = (nodeIds && nodeIds.length >= 2 ? nodeIds : Array.from(cluster.nodes.keys())).slice(0, 5);
    const activeDb = cluster.getActiveNode().db;
    const bed = activeDb.prepare('SELECT * FROM beds WHERE id = ?').get(bedId) as
      | { id: string; room_id: string; department_id: string; code: string; status: string }
      | undefined;

    if (!bed) {
      res.status(404).json({ error: 'Không tìm thấy giường.' });
      return;
    }

    const attempts = await Promise.allSettled(
      candidates.map((nid, idx) => {
        const admId = `adm-race-${crypto.randomUUID().slice(0, 8)}`;
        const now = new Date().toISOString();
        return cluster.proposeCriticalAllocation({
          nodeId: nid,
          userId: req.authUser!.id,
          requestType: 'ASSIGN_BED',
          eventType: 'ADMISSION_CONFIRM',
          aggregateType: 'ADMISSION',
          aggregateId: admId,
          bedId: bed.id,
          roomId: bed.room_id,
          payloadObj: {
            id: admId,
            admission_code: `RACE-${Date.now().toString().slice(-4)}-${idx + 1}`,
            patient_id: `pat-race-${idx + 1}-${Date.now()}`,
            patient_code: `BN-TEST-${idx + 1}`,
            patient_name: `Bệnh nhân Kiểm thử Race #${idx + 1} (${nid})`,
            date_of_birth: '1995-01-01',
            phone: '0900000000',
            diagnosis_group: 'Sinh thường',
            department_id: bed.department_id,
            room_id: bed.room_id,
            bed_id: bed.id,
            is_whole_room: false,
            hospital_admitted_at: now,
            bed_assigned_at: now,
            expected_discharge_at: new Date(Date.now() + 3 * 86400000).toISOString(),
            calculation_method: 'CALENDAR_DAYS',
            status: 'ACTIVE',
            notes: `Kiểm thử đồng thời từ ${nid}`,
            confirmed_by: req.authUser!.id,
            confirmed_by_name: req.authUser!.full_name,
          },
        });
      })
    );

    const results = attempts.map((r, i) => ({
      nodeId: candidates[i],
      outcome: r.status === 'fulfilled' ? (r.value.pendingConfirmation ? 'PENDING_QUORUM' : 'WON_COMMITTED') : 'REJECTED_CONFLICT',
      detail: r.status === 'fulfilled' ? r.value.event.event_id : (r.reason as Error).message,
    }));
    res.json({ bedCode: bed.code, results });
  });

  // --- DEVICES ---
  router.post('/devices/pair', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { nodeName, departmentId } = req.body as { nodeName: string; departmentId?: string | null };
    if (!nodeName?.trim()) {
      res.status(400).json({ error: 'Tên thiết bị không được để trống.' });
      return;
    }
    const created = cluster.pairNewDevice(nodeName.trim(), departmentId || null, req.authUser!.id);
    res.status(201).json({ deviceId: created.deviceId, nodeName: created.nodeName });
  });

  router.post('/devices/:deviceId/revoke', requireAuth, requireRoles('SUPER_ADMIN'), (req: AuthedRequest, res) => {
    try {
      cluster.revokeDevice(req.params.deviceId, req.authUser!.id);
      res.json({ ok: true });
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  // --- DASHBOARD & OVERVIEW ---
  router.get('/dashboard/overview', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const cfg = getConfigMap(db);
    const dayCfg = getDayConfig(cfg);
    const nowIso = new Date().toISOString();

    const depts = db.prepare('SELECT * FROM departments ORDER BY name ASC').all() as Array<Record<string, unknown>>;
    const rooms = db.prepare('SELECT * FROM rooms').all() as Array<Record<string, unknown>>;
    const beds = db.prepare('SELECT * FROM beds').all() as Array<Record<string, unknown>>;
    const admissions = db.prepare("SELECT * FROM admissions WHERE status IN ('ACTIVE', 'PENDING_CONFIRMATION')").all() as Array<Record<string, unknown>>;
    const reservations = db.prepare("SELECT * FROM reservations WHERE status = 'ACTIVE'").all() as Array<Record<string, unknown>>;
    const registrations = db.prepare("SELECT * FROM registrations WHERE status = 'WAITING'").all() as Array<Record<string, unknown>>;
    const devices = db.prepare('SELECT * FROM devices').all() as Array<Record<string, unknown>>;

    const pendingSyncCount = (db.prepare("SELECT COUNT(*) as c FROM sync_queue WHERE status = 'PENDING'").get() as { c: number }).c;
    const openConflictCount = (db.prepare("SELECT COUNT(*) as c FROM conflicts WHERE status = 'OPEN'").get() as { c: number }).c;
    const failedBackupCount = (db.prepare("SELECT COUNT(*) as c FROM backups WHERE status = 'FAILED'").get() as { c: number }).c;
    const pendingRequestCount = (db.prepare("SELECT COUNT(*) as c FROM pending_requests WHERE status = 'WAITING_QUORUM'").get() as { c: number }).c;

    const deptNames: Record<string, string> = {};
    for (const d of depts) deptNames[d.id as string] = d.name as string;

    const roomNames: Record<string, string> = {};
    for (const r of rooms) roomNames[r.id as string] = r.name as string;

    const enrichedBeds: Array<Record<string, unknown>> = beds.map((b) => ({
      ...b,
      department_name: deptNames[b.department_id as string] ?? '',
      room_name: roomNames[b.room_id as string] ?? '',
    }));

    const bedCodes: Record<string, string> = {};
    for (const b of beds) bedCodes[b.id as string] = b.code as string;

    const enrichedAdmissions: Array<Record<string, unknown>> = admissions.map((a) => ({
      ...a,
      bed_code: bedCodes[a.bed_id as string] ?? '',
      department_name: deptNames[a.department_id as string] ?? '',
    }));

    const alerts = evaluateSystemAlerts({
      admissions: enrichedAdmissions as never[],
      reservations: reservations.map((r) => ({ ...r, room_name: roomNames[r.room_id as string] ?? '' })) as never[],
      registrations: registrations as never[],
      beds: enrichedBeds as never[],
      devices: devices as never[],
      pendingSyncCount,
      openConflictCount,
      failedBackupCount,
      pendingRequestCount,
      deptNames,
      dayConfig: dayCfg,
      reservationWarnMinutes: Number(cfg.reservation_warn_minutes || '120'),
      nowIso,
    });

    const countByStatus = (status: string) => beds.filter((b) => b.status === status).length;
    const operationalBeds = beds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length;
    const occupiedCount = countByStatus('OCCUPIED');

    const deptStats = depts.map((d) => {
      const dBeds = beds.filter((b) => b.department_id === d.id);
      const dOps = dBeds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length;
      const dOcc = dBeds.filter((b) => b.status === 'OCCUPIED').length;
      return {
        ...d,
        total_rooms: rooms.filter((r) => r.department_id === d.id).length,
        total_beds: dBeds.length,
        occupied_beds: dOcc,
        vacant_beds: dBeds.filter((b) => b.status === 'VACANT').length,
        reserved_beds: dBeds.filter((b) => b.status === 'RESERVED').length,
        cleaning_beds: dBeds.filter((b) => b.status === 'PENDING_CLEANING' || b.status === 'CLEANING').length,
        maintenance_beds: dBeds.filter((b) => b.status === 'MAINTENANCE').length,
        occupancy_rate: calculateBedOccupancyRate(dOcc, dOps),
      };
    });

    const dueSoonCount = alerts.filter((a) => a.type === 'BED_DUE_SOON' || a.type === 'BED_DUE_TODAY').length;
    const overdueCount = alerts.filter((a) => a.type === 'BED_OVERDUE').length;

    const historicalDischarges = db
      .prepare("SELECT diagnosis_group, bed_assigned_at, actual_discharge_at FROM admissions WHERE status = 'DISCHARGED' AND actual_discharge_at IS NOT NULL")
      .all() as Array<{ diagnosis_group: string; bed_assigned_at: string; actual_discharge_at: string }>;
    const diagnosisBaselines = db
      .prepare('SELECT name, default_days FROM diagnosis_configs WHERE is_active = 1')
      .all() as Array<{ name: string; default_days: number }>;

    const vacancyPrediction = predict4HourBedVacancies({
      activeAdmissions: enrichedAdmissions.map((a) => ({
        id: String(a.id),
        bed_id: String(a.bed_id),
        bed_code: String(a.bed_code ?? ''),
        room_id: String(a.room_id),
        room_name: roomNames[String(a.room_id)] ?? '',
        department_id: String(a.department_id),
        department_name: String(a.department_name ?? ''),
        patient_name: String(a.patient_name ?? ''),
        diagnosis_group: String(a.diagnosis_group ?? ''),
        bed_assigned_at: String(a.bed_assigned_at),
        expected_discharge_at: String(a.expected_discharge_at),
        extension_count: Number(a.extension_count ?? 0),
        is_whole_room: Number(a.is_whole_room ?? 0),
        status: String(a.status),
      })),
      turnaroundBeds: enrichedBeds.map((b) => ({
        id: String(b.id),
        code: String(b.code),
        room_id: String(b.room_id),
        room_name: String(b.room_name ?? ''),
        department_id: String(b.department_id),
        department_name: String(b.department_name ?? ''),
        status: String(b.status),
        updated_at: String(b.updated_at ?? ''),
      })),
      historicalDischarges,
      diagnosisBaselines,
      nowIso,
    });

    const criticalCapacityDepartments = deptStats
      .filter((d) => Number(d.occupancy_rate) > 90)
      .sort((a, b) => Number(b.occupancy_rate) - Number(a.occupancy_rate));

    const nowMs = Date.now();
    const triagePatients = enrichedAdmissions
      .filter((a) => a.status === 'ACTIVE')
      .map((a) => {
        const expectedMs = new Date(String(a.expected_discharge_at)).getTime();
        const medMs = a.medication_deadline_at ? new Date(String(a.medication_deadline_at)).getTime() : null;
        const overdueHours = (nowMs - expectedMs) / 3600000;
        const medHoursLeft = medMs ? (medMs - nowMs) / 3600000 : null;
        const storedPriority = String(a.triage_priority || 'NORMAL');
        const vitalsAlert = String(a.vitals_alert || '');

        let computedPriority: 'CRITICAL' | 'HIGH' | 'NORMAL' = 'NORMAL';
        const reasons: string[] = [];
        if (storedPriority === 'CRITICAL' || overdueHours > 0 || (medHoursLeft !== null && medHoursLeft <= 0)) {
          computedPriority = 'CRITICAL';
        } else if (storedPriority === 'HIGH' || overdueHours > -12 || (medHoursLeft !== null && medHoursLeft <= 2)) {
          computedPriority = 'HIGH';
        }
        if (vitalsAlert) reasons.push(vitalsAlert);
        if (overdueHours > 0) reasons.push(`Quá hạn trả giường ${overdueHours.toFixed(1)}h`);
        else if (overdueHours > -12) reasons.push(`Sắp đến hạn trả (${Math.abs(overdueHours).toFixed(1)}h)`);
        if (medHoursLeft !== null) {
          if (medHoursLeft <= 0) reasons.push('Quá mốc lịch chăm sóc / dùng thuốc');
          else if (medHoursLeft <= 2) reasons.push(`Mốc thuốc/chăm sóc còn ${(medHoursLeft * 60).toFixed(0)} phút`);
        }

        return {
          id: String(a.id),
          admission_code: String(a.admission_code),
          patient_name: String(a.patient_name),
          patient_code: String(a.patient_code),
          bed_id: String(a.bed_id),
          bed_code: String(a.bed_code ?? ''),
          room_id: String(a.room_id),
          room_name: roomNames[String(a.room_id)] ?? '',
          department_id: String(a.department_id),
          department_name: String(a.department_name ?? ''),
          diagnosis_group: String(a.diagnosis_group ?? ''),
          priority: computedPriority,
          vitals_alert: vitalsAlert,
          medication_deadline_at: a.medication_deadline_at ? String(a.medication_deadline_at) : null,
          expected_discharge_at: String(a.expected_discharge_at),
          reason_summary: reasons.length > 0 ? reasons.join(' · ') : 'Theo dõi lưu trú ổn định',
        };
      })
      .sort((a, b) => {
        const rank = { CRITICAL: 0, HIGH: 1, NORMAL: 2 };
        return rank[a.priority] - rank[b.priority];
      });

    res.json({
      summary: {
        totalDepartments: depts.filter((d) => d.status === 'ACTIVE').length,
        totalRooms: rooms.filter((r) => r.status === 'ACTIVE').length,
        totalBeds: beds.length,
        operationalBeds,
        vacantBeds: countByStatus('VACANT'),
        occupiedBeds: occupiedCount,
        reservedBeds: countByStatus('RESERVED'),
        pendingConfirmationBeds: countByStatus('PENDING_CONFIRMATION'),
        cleaningBeds: countByStatus('PENDING_CLEANING') + countByStatus('CLEANING'),
        maintenanceBeds: countByStatus('MAINTENANCE'),
        inactiveBeds: countByStatus('INACTIVE'),
        activeInpatients: admissions.filter((a) => a.status === 'ACTIVE').length,
        dueSoonBeds: dueSoonCount,
        overdueBeds: overdueCount,
        occupancyRate: calculateBedOccupancyRate(occupiedCount, operationalBeds),
        occupancyFormula: 'Số giường đang sử dụng / Tổng giường hoạt động (loại trừ Bảo trì & Ngừng hoạt động)',
        demoModeActive: cfg.demo_mode_active === 'true',
      },
      deptStats,
      criticalCapacityDepartments,
      triagePatients,
      alerts,
      vacancyPrediction,
    });
  });

  // --- DEPARTMENTS ---
  router.get('/departments', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const depts = db.prepare('SELECT * FROM departments ORDER BY name ASC').all() as Array<Record<string, unknown>>;
    const rooms = db.prepare('SELECT * FROM rooms').all() as Array<Record<string, unknown>>;
    const beds = db.prepare('SELECT * FROM beds').all() as Array<Record<string, unknown>>;

    const result = depts.map((d) => {
      const dBeds = beds.filter((b) => b.department_id === d.id);
      const dOps = dBeds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length;
      const dOcc = dBeds.filter((b) => b.status === 'OCCUPIED').length;
      return {
        ...d,
        total_rooms: rooms.filter((r) => r.department_id === d.id).length,
        total_beds: dBeds.length,
        occupied_beds: dOcc,
        vacant_beds: dBeds.filter((b) => b.status === 'VACANT').length,
        occupancy_rate: calculateBedOccupancyRate(dOcc, dOps),
      };
    });
    res.json(result);
  });

  router.post('/departments', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, code, name, description, status } = req.body as {
      id?: string;
      code: string;
      name: string;
      description?: string;
      status?: 'ACTIVE' | 'INACTIVE';
    };
    if (!code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Mã khoa và tên khoa là bắt buộc.' });
      return;
    }
    const deptId = id || `dept-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'DEPARTMENT_UPSERT', 'DEPARTMENT', deptId, {
      id: deptId,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      description: description?.trim() || '',
      status: status || 'ACTIVE',
      audit_action: id ? 'UPDATE_DEPARTMENT' : 'CREATE_DEPARTMENT',
      audit_details: `${id ? 'Cập nhật' : 'Thêm'} khoa ${name}`,
    });
    res.status(201).json({ id: deptId });
  });

  // --- ROOM STANDARDS ---
  router.get('/room-standards', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db.prepare('SELECT * FROM room_standards ORDER BY is_default DESC, name ASC').all() as Array<Record<string, unknown>>;
    res.json(
      rows.map((r) => ({
        ...r,
        attributes: JSON.parse((r.attributes as string) || '{}'),
      }))
    );
  });

  router.post('/room-standards', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, name, code, category, description, attributes, status } = req.body as {
      id?: string;
      name: string;
      code: string;
      category: 'CAPACITY' | 'TOILET' | 'SERVICE' | 'CUSTOM';
      description?: string;
      attributes?: Record<string, unknown>;
      status?: 'ACTIVE' | 'INACTIVE';
    };
    if (!name?.trim() || !code?.trim()) {
      res.status(400).json({ error: 'Tên và mã tiêu chuẩn là bắt buộc.' });
      return;
    }
    const stdId = id || `std-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'ROOM_STANDARD_UPSERT', 'ROOM_STANDARD', stdId, {
      id: stdId,
      name: name.trim(),
      code: code.trim().toUpperCase(),
      category: category || 'CUSTOM',
      description: description?.trim() || '',
      attributes: attributes ?? {},
      is_default: 0,
      status: status || 'ACTIVE',
      audit_action: 'UPSERT_ROOM_STANDARD',
      audit_details: `Cấu hình tiêu chuẩn phòng ${name}`,
    });
    res.status(201).json({ id: stdId });
  });

  // --- BED TYPES & PRICING ---
  router.get('/bed-types', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    res.json(db.prepare('SELECT * FROM bed_types ORDER BY daily_price ASC, name ASC').all());
  });

  router.post('/bed-types', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, code, name, daily_price, hourly_price, description, status } = req.body as {
      id?: string;
      code: string;
      name: string;
      daily_price: number;
      hourly_price?: number;
      description?: string;
      status?: 'ACTIVE' | 'INACTIVE';
    };
    if (!code?.trim() || !name?.trim() || Number(daily_price) < 0) {
      res.status(400).json({ error: 'Mã loại giường, tên loại giường và đơn giá hợp lệ là bắt buộc.' });
      return;
    }
    const btId = id || `bt-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_TYPE_UPSERT', 'BED_TYPE', btId, {
      id: btId,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      daily_price: Number(daily_price) || 0,
      hourly_price: Number(hourly_price) || 0,
      description: description?.trim() || '',
      status: status || 'ACTIVE',
      audit_action: id ? 'UPDATE_BED_TYPE' : 'CREATE_BED_TYPE',
      audit_details: `${id ? 'Cập nhật' : 'Thêm'} loại giường ${name} (${Number(daily_price).toLocaleString('vi-VN')} đ/ngày)`,
    });
    res.status(201).json({ id: btId });
  });

  // --- ROOMS ---
  router.get('/rooms', requireAuth, (req, res) => {
    const db = cluster.getActiveNode().db;
    const deptFilter = req.query.departmentId as string | undefined;
    const depts = db.prepare('SELECT id, name FROM departments').all() as Array<{ id: string; name: string }>;
    const deptMap = Object.fromEntries(depts.map((d) => [d.id, d.name]));

    const rooms = (
      deptFilter
        ? db.prepare('SELECT * FROM rooms WHERE department_id = ? ORDER BY code ASC').all(deptFilter)
        : db.prepare('SELECT * FROM rooms ORDER BY code ASC').all()
    ) as Array<Record<string, unknown>>;

    res.json(
      rooms.map((r) => ({
        ...r,
        department_name: deptMap[r.department_id as string] ?? '',
        standard_ids: JSON.parse((r.standard_ids as string) || '[]'),
      }))
    );
  });

  router.post('/rooms', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const b = req.body as {
      id?: string;
      department_id: string;
      code: string;
      name: string;
      floor?: string;
      capacity: number;
      toilet_type: 'INTERNAL' | 'EXTERNAL';
      room_type: 'STANDARD' | 'SERVICE' | 'VIP' | 'ISOLATION';
      is_service: boolean;
      standard_ids: string[];
      status?: 'ACTIVE' | 'INACTIVE';
      notes?: string;
    };
    if (!b.department_id || !b.code?.trim() || !b.name?.trim() || !b.capacity || b.capacity < 1) {
      res.status(400).json({ error: 'Thông tin phòng và số giường (>= 1) không hợp lệ.' });
      return;
    }

    const db = cluster.getActiveNode().db;
    const roomId = b.id || `room-${crypto.randomUUID().slice(0, 8)}`;
    if (b.id) {
      // Cannot reduce room capacity below existing active/historical beds
      const existingBeds = db.prepare('SELECT COUNT(*) as c FROM beds WHERE room_id = ?').get(b.id) as { c: number };
      const busyBeds = db
        .prepare("SELECT COUNT(*) as c FROM beds WHERE room_id = ? AND status IN ('OCCUPIED', 'RESERVED', 'PENDING_CONFIRMATION')")
        .get(b.id) as { c: number };
      if (b.capacity < busyBeds.c || b.capacity < existingBeds.c) {
        res.status(400).json({
          error: `Không thể giảm số giường xuống ${b.capacity} vì phòng đã có ${existingBeds.c} giường được khai báo (${busyBeds.c} giường đang có giao dịch).`,
        });
        return;
      }
    }

    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'ROOM_UPSERT', 'ROOM', roomId, {
      id: roomId,
      department_id: b.department_id,
      code: b.code.trim().toUpperCase(),
      name: b.name.trim(),
      floor: b.floor || 'Tầng 1',
      capacity: b.capacity,
      toilet_type: b.toilet_type || 'INTERNAL',
      room_type: b.room_type || 'STANDARD',
      is_service: b.is_service ? 1 : 0,
      standard_ids: b.standard_ids || [],
      status: b.status || 'ACTIVE',
      notes: b.notes || '',
      audit_action: b.id ? 'UPDATE_ROOM' : 'CREATE_ROOM',
      audit_details: `${b.id ? 'Cập nhật' : 'Tạo'} phòng ${b.name} (${b.capacity} giường)`,
    });

    // Auto-create beds up to capacity when creating a new room or expanding capacity
    const currentBeds = db.prepare('SELECT COUNT(*) as c FROM beds WHERE room_id = ?').get(roomId) as { c: number };
    for (let i = currentBeds.c + 1; i <= b.capacity; i++) {
      const bId = `bed-${crypto.randomUUID().slice(0, 8)}`;
      const bCode = `${b.code.trim().toUpperCase()}-G${String(i).padStart(2, '0')}`;
      cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_UPSERT', 'BED', bId, {
        id: bId,
        room_id: roomId,
        department_id: b.department_id,
        code: bCode,
        name: `Giường ${String(i).padStart(2, '0')} - ${b.name.trim()}`,
        status: 'VACANT',
      });
    }

    res.status(201).json({ id: roomId });
  });

  router.delete('/rooms/:id', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const roomId = req.params.id;
    const hasAdmissions = (db.prepare('SELECT COUNT(*) as c FROM admissions WHERE room_id = ?').get(roomId) as { c: number }).c;
    const hasReservations = (db.prepare('SELECT COUNT(*) as c FROM reservations WHERE room_id = ?').get(roomId) as { c: number }).c;
    const hasBeds = (db.prepare('SELECT COUNT(*) as c FROM beds WHERE room_id = ?').get(roomId) as { c: number }).c;
    if (hasAdmissions > 0 || hasReservations > 0 || hasBeds > 0) {
      res.status(400).json({ error: 'Không thể xóa phòng đã có giường hoặc dữ liệu nghiệp vụ liên quan.' });
      return;
    }
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'ROOM_DELETE', 'ROOM', roomId, {
      id: roomId,
      audit_action: 'DELETE_ROOM',
      audit_details: `Xóa phòng ${roomId}`,
    });
    res.json({ ok: true });
  });

  // --- BEDS ---
  router.get('/beds', requireAuth, (req, res) => {
    const db = cluster.getActiveNode().db;
    const deptFilter = req.query.departmentId as string | undefined;
    const statusFilter = req.query.status as string | undefined;

    const rows = db
      .prepare(
        `SELECT b.*, r.code as room_code, r.name as room_name, r.floor, r.exclusive_locked, r.exclusive_lock_id,
                r.occupancy_status as room_occupancy_status, r.toilet_type, r.room_type, r.standard_ids,
                d.name as department_name,
                bt.name as bed_type_name, bt.code as bed_type_code, bt.hourly_price as bt_hourly_price,
                COALESCE(NULLIF(b.daily_price, 0), bt.daily_price, 0) as effective_daily_price,
                a.admission_code, a.patient_name, a.patient_code, a.his_record_code, a.date_of_birth,
                a.diagnosis_group, a.confirmed_by_name, a.bed_assigned_at, a.hospital_admitted_at,
                a.expected_discharge_at, a.notes as admission_notes, a.is_whole_room,
                rsv.patient_name as rsv_patient_name, rsv.expires_at as rsv_expires_at,
                a_excl.patient_name as excl_adm_patient_name, a_excl.expected_discharge_at as excl_adm_discharge_at,
                rsv_excl.patient_name as excl_rsv_patient_name, rsv_excl.expires_at as excl_rsv_expires_at
         FROM beds b
         JOIN rooms r ON b.room_id = r.id
         JOIN departments d ON b.department_id = d.id
         LEFT JOIN bed_types bt ON b.bed_type_id = bt.id
         LEFT JOIN admissions a ON b.current_admission_id = a.id
         LEFT JOIN reservations rsv ON b.current_reservation_id = rsv.id
         LEFT JOIN admissions a_excl ON r.exclusive_lock_id = a_excl.id
         LEFT JOIN reservations rsv_excl ON r.exclusive_lock_id = rsv_excl.id
         ORDER BY d.name ASC, r.code ASC, b.code ASC`
      )
      .all() as Array<Record<string, unknown>>;

    const wardStaffRows = db
      .prepare("SELECT full_name, department_id FROM users WHERE status = 'ACTIVE' AND role = 'WARD_STAFF' AND department_id IS NOT NULL")
      .all() as Array<{ full_name: string; department_id: string }>;

    const staffByDept = new Map<string, string[]>();
    for (const u of wardStaffRows) {
      const list = staffByDept.get(u.department_id) ?? [];
      list.push(u.full_name);
      staffByDept.set(u.department_id, list);
    }

    const filtered = rows.filter((b) => {
      if (deptFilter && b.department_id !== deptFilter) return false;
      if (statusFilter && b.status !== statusFilter) return false;
      return true;
    });

    res.json(
      filtered.map((b) => {
        const primary = b.confirmed_by_name ? [String(b.confirmed_by_name)] : [];
        const deptTeam = staffByDept.get(String(b.department_id)) ?? [];
        const careTeam = Array.from(new Set([...primary, ...deptTeam]));
        const isExclusiveLocked = Boolean(b.exclusive_locked);
        const exclusiveHolderName =
          (b.excl_adm_patient_name as string | null) ??
          (b.excl_rsv_patient_name as string | null) ??
          null;
        const isExclusiveCompanion = Boolean(
          isExclusiveLocked && !b.current_admission_id && (b.status === 'RESERVED' || b.status === 'PENDING_CONFIRMATION')
        );
        const reservationPatientName =
          (b.rsv_patient_name as string | null) ?? exclusiveHolderName;
        const reservationExpiresAt =
          (b.rsv_expires_at as string | null) ??
          (b.excl_rsv_expires_at as string | null) ??
          (b.excl_adm_discharge_at as string | null) ??
          null;

        return {
          ...b,
          daily_price: Number(b.effective_daily_price ?? b.daily_price ?? 0),
          hourly_price: Number(b.bt_hourly_price ?? 0),
          exclusive_locked: isExclusiveLocked,
          exclusive_holder_name: exclusiveHolderName,
          is_exclusive_companion: isExclusiveCompanion,
          reservation_patient_name: reservationPatientName,
          reservation_expires_at: reservationExpiresAt,
          standard_ids: JSON.parse((b.standard_ids as string) || '[]'),
          care_team: careTeam,
        };
      })
    );
  });

  router.get('/beds/:id/history', requireAuth, (req, res) => {
    const db = cluster.getActiveNode().db;
    const bed = db
      .prepare(
        `SELECT b.*, r.name as room_name, r.floor, d.name as department_name
         FROM beds b
         JOIN rooms r ON b.room_id = r.id
         JOIN departments d ON b.department_id = d.id
         WHERE b.id = ?`
      )
      .get(req.params.id) as Record<string, unknown> | undefined;

    if (!bed) {
      res.status(404).json({ error: 'Không tìm thấy giường bệnh.' });
      return;
    }

    const cfg = getConfigMap(db);
    const dayCfg = getDayConfig(cfg);
    const nowIso = new Date().toISOString();

    const directRows = db
      .prepare(
        `SELECT a.*, d.name as department_name, r.name as room_name, b.code as bed_code
         FROM admissions a
         JOIN departments d ON a.department_id = d.id
         JOIN rooms r ON a.room_id = r.id
         JOIN beds b ON a.bed_id = b.id
         WHERE a.bed_id = ?
         ORDER BY a.bed_assigned_at DESC`
      )
      .all(req.params.id) as Array<Record<string, unknown>>;

    const transferRows = db
      .prepare(
        `SELECT t.*, a.admission_code, a.patient_code, a.his_record_code, a.patient_name, a.date_of_birth,
                a.diagnosis_group, a.bed_assigned_at, a.expected_discharge_at, a.actual_discharge_at,
                a.status as admission_status, a.extension_count, a.confirmed_by_name, a.calculation_method,
                a.notes as admission_notes,
                d_from.name as from_dept_name, b_from.code as from_bed_code,
                d_to.name as to_dept_name, b_to.code as to_bed_code
         FROM bed_transfers t
         JOIN admissions a ON t.admission_id = a.id
         JOIN departments d_from ON t.from_department_id = d_from.id
         JOIN beds b_from ON t.from_bed_id = b_from.id
         JOIN departments d_to ON t.to_department_id = d_to.id
         JOIN beds b_to ON t.to_bed_id = b_to.id
         WHERE t.from_bed_id = ? OR t.to_bed_id = ?
         ORDER BY t.performed_at DESC`
      )
      .all(req.params.id, req.params.id) as Array<Record<string, unknown>>;

    const seenIds = new Set<string>();
    const history: Array<Record<string, unknown>> = [];

    for (const a of directRows) {
      seenIds.add(String(a.id));
      const metrics = calculateStayMetrics(
        a.bed_assigned_at as string,
        a.expected_discharge_at as string,
        (a.actual_discharge_at as string | null) ?? null,
        (a.calculation_method as BedDayConfig['method']) || 'CALENDAR_DAYS',
        dayCfg,
        nowIso
      );
      const matchingTransferIn = transferRows.find((t) => t.admission_id === a.id && t.to_bed_id === req.params.id);
      history.push({
        id: a.id,
        admission_code: a.admission_code,
        patient_code: a.patient_code,
        his_record_code: a.his_record_code,
        patient_name: a.patient_name,
        date_of_birth: a.date_of_birth,
        diagnosis_group: a.diagnosis_group,
        department_name: a.department_name,
        room_name: a.room_name,
        bed_code: a.bed_code,
        bed_assigned_at: a.bed_assigned_at,
        expected_discharge_at: a.expected_discharge_at,
        actual_discharge_at: a.actual_discharge_at,
        status: a.status,
        extension_count: a.extension_count,
        confirmed_by_name: a.confirmed_by_name,
        notes: a.notes,
        days_stayed: metrics.daysStayed,
        relation_type: matchingTransferIn ? 'TRANSFERRED_IN' : 'DIRECT',
        transfer_note: matchingTransferIn
          ? `Chuyển từ giường ${matchingTransferIn.from_bed_code} (${matchingTransferIn.reason})`
          : undefined,
      });
    }

    for (const t of transferRows) {
      if (t.from_bed_id === req.params.id && !seenIds.has(String(t.admission_id))) {
        seenIds.add(String(t.admission_id));
        const metrics = calculateStayMetrics(
          t.bed_assigned_at as string,
          t.expected_discharge_at as string,
          (t.actual_discharge_at as string | null) ?? (t.performed_at as string),
          (t.calculation_method as BedDayConfig['method']) || 'CALENDAR_DAYS',
          dayCfg,
          nowIso
        );
        history.push({
          id: String(t.admission_id),
          admission_code: t.admission_code,
          patient_code: t.patient_code,
          his_record_code: t.his_record_code,
          patient_name: t.patient_name,
          date_of_birth: t.date_of_birth,
          diagnosis_group: t.diagnosis_group,
          department_name: t.from_dept_name,
          room_name: bed.room_name,
          bed_code: t.from_bed_code,
          bed_assigned_at: t.bed_assigned_at,
          expected_discharge_at: t.expected_discharge_at,
          actual_discharge_at: t.performed_at,
          status: 'TRANSFERRED',
          extension_count: t.extension_count,
          confirmed_by_name: t.confirmed_by_name,
          notes: t.admission_notes,
          days_stayed: metrics.daysStayed,
          relation_type: 'TRANSFERRED_OUT',
          transfer_note: `Đã chuyển sang giường ${t.to_bed_code} (${t.to_dept_name}) · Lý do: ${t.reason}`,
        });
      }
    }

    history.sort((x, y) => String(y.bed_assigned_at).localeCompare(String(x.bed_assigned_at)));
    res.json({ bed, history });
  });

  router.post('/beds', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, room_id, department_id, bed_type_id, daily_price, code, name, status, notes } = req.body as {
      id?: string;
      room_id: string;
      department_id: string;
      bed_type_id?: string | null;
      daily_price?: number;
      code: string;
      name: string;
      status?: string;
      notes?: string;
    };
    if (!room_id || !department_id || !code?.trim() || !name?.trim()) {
      res.status(400).json({ error: 'Thiếu thông tin giường bệnh.' });
      return;
    }
    const bedId = id || `bed-${crypto.randomUUID().slice(0, 8)}`;
    const db = cluster.getActiveNode().db;
    let resolvedPrice = Number(daily_price ?? 0);
    if (!resolvedPrice && bed_type_id) {
      const bt = db.prepare('SELECT daily_price FROM bed_types WHERE id = ?').get(bed_type_id) as { daily_price: number } | undefined;
      if (bt) resolvedPrice = bt.daily_price;
    }
    const existingBed = id ? (db.prepare('SELECT status, current_admission_id, current_reservation_id FROM beds WHERE id = ?').get(id) as Record<string, unknown> | undefined) : undefined;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_UPSERT', 'BED', bedId, {
      id: bedId,
      room_id,
      department_id,
      bed_type_id: bed_type_id ?? null,
      daily_price: resolvedPrice,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      status: existingBed ? (status ?? existingBed.status) : (status ?? 'VACANT'),
      current_admission_id: existingBed?.current_admission_id ?? null,
      current_reservation_id: existingBed?.current_reservation_id ?? null,
      notes: notes || '',
      audit_action: id ? 'UPDATE_BED' : 'CREATE_BED',
      audit_details: `${id ? 'Cập nhật' : 'Thêm'} giường ${code}`,
    });
    res.status(201).json({ id: bedId });
  });

  router.post('/beds/fix-conflicts', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const countConflicts = () => {
      const rooms = db.prepare('SELECT id, code, name, exclusive_locked, exclusive_lock_id, occupancy_status FROM rooms').all() as Array<{
        id: string;
        code: string;
        name: string;
        exclusive_locked: number;
        exclusive_lock_id: string | null;
        occupancy_status: string | null;
      }>;
      const beds = db.prepare('SELECT id, room_id, code, status, current_admission_id, current_reservation_id FROM beds').all() as Array<{
        id: string;
        room_id: string;
        code: string;
        status: string;
        current_admission_id: string | null;
        current_reservation_id: string | null;
      }>;
      const activeWholeIds = new Set([
        ...(db.prepare("SELECT id FROM admissions WHERE status = 'ACTIVE' AND is_whole_room = 1").all() as Array<{ id: string }>).map((r) => r.id),
        ...(db.prepare("SELECT id FROM reservations WHERE status = 'ACTIVE' AND is_whole_room = 1").all() as Array<{ id: string }>).map((r) => r.id),
      ]);
      const activeAdmIds = new Set(
        (db.prepare("SELECT id FROM admissions WHERE status = 'ACTIVE'").all() as Array<{ id: string }>).map((r) => r.id)
      );
      const conflictRooms: string[] = [];
      let conflictCount = 0;
      for (const r of rooms) {
        const rBeds = beds.filter((b) => b.room_id === r.id);
        const v = validateRoomAndBeds(r, rBeds, activeWholeIds, activeAdmIds);
        if (v.hasConflict) {
          conflictRooms.push(r.code);
          conflictCount += v.conflicts.length;
        }
      }
      return { conflictCount, conflictRooms };
    };

    const before = countConflicts();
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'ROOM_CONFLICTS_BATCH_FIX', 'ROOM', 'batch-fix', {
      audit_action: 'BATCH_FIX_ROOM_BED_CONFLICTS',
      audit_details: `Đồng bộ & sửa xung đột trạng thái phòng/giường hàng loạt (${before.conflictCount} xung đột tại ${before.conflictRooms.join(', ') || '0 phòng'})`,
    });
    const after = countConflicts();

    res.json({
      ok: true,
      fixedConflicts: Math.max(0, before.conflictCount - after.conflictCount),
      remainingConflicts: after.conflictCount,
      fixedRooms: before.conflictRooms,
    });
  });

  router.post('/beds/:id/status', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const bed = db.prepare('SELECT * FROM beds WHERE id = ?').get(req.params.id) as
      | { id: string; department_id: string; status: string; code: string }
      | undefined;
    if (!bed) {
      res.status(404).json({ error: 'Không tìm thấy giường.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, bed.department_id)) {
      res.status(403).json({ error: 'Nhân viên khoa không được phép sửa giường thuộc khoa khác.' });
      return;
    }
    const { status, notes } = req.body as { status: 'VACANT' | 'MAINTENANCE' | 'INACTIVE'; notes?: string };
    if (!['VACANT', 'MAINTENANCE', 'INACTIVE'].includes(status)) {
      res.status(400).json({ error: 'Chỉ được chuyển thủ công sang Trống, Bảo trì hoặc Ngừng hoạt động.' });
      return;
    }
    if (['OCCUPIED', 'RESERVED', 'PENDING_CONFIRMATION'].includes(bed.status)) {
      res.status(400).json({ error: `Giường ${bed.code} đang có bệnh nhân hoặc đang giữ chỗ, không thể chuyển trạng thái.` });
      return;
    }
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_STATUS_CHANGE', 'BED', bed.id, {
      bed_id: bed.id,
      status,
      notes,
      audit_action: 'CHANGE_BED_STATUS',
      audit_details: `Đổi trạng thái giường ${bed.code} -> ${status}`,
    });
    res.json({ ok: true });
  });

  // --- REGISTRATIONS (Form A & B + HIS/Excel Import) ---
  router.get('/registrations', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db
      .prepare(
        `SELECT reg.*, d.name as department_name, r.name as room_name, b.code as bed_code
         FROM registrations reg
         LEFT JOIN departments d ON reg.department_id = d.id
         LEFT JOIN rooms r ON reg.room_id = r.id
         LEFT JOIN beds b ON reg.bed_id = b.id
         ORDER BY reg.created_at DESC`
      )
      .all() as Array<Record<string, unknown>>;
    res.json(
      rows.map((r) => ({
        ...r,
        desired_standard_ids: JSON.parse((r.desired_standard_ids as string) || '[]'),
      }))
    );
  });

  router.post('/registrations', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'), async (req: AuthedRequest, res) => {
    try {
      const b = req.body as {
        patient_code: string;
        his_record_code?: string;
        patient_name: string;
        date_of_birth: string;
        phone?: string;
        diagnosis_group: string;
        expected_admission_date: string;
        expected_discharge_date?: string;
        desired_standard_ids: string[];
        registration_mode: 'UNKNOWN_DEPT' | 'KNOWN_DEPT';
        department_id?: string | null;
        room_id?: string | null;
        bed_id?: string | null;
        reservation_type: 'NONE' | 'WAITLIST' | 'SINGLE_BED' | 'WHOLE_ROOM';
        notes?: string;
      };
      if (!b.patient_code?.trim() || !b.patient_name?.trim() || !b.date_of_birth || !b.diagnosis_group) {
        res.status(400).json({ error: 'Vui lòng nhập đầy đủ mã bệnh nhân, họ tên, ngày sinh và nhóm chẩn đoán.' });
        return;
      }

      const db = cluster.getActiveNode().db;
      const cfg = getConfigMap(db);
      const dayCfg = getDayConfig(cfg);
      const diagRow = db.prepare('SELECT default_days FROM diagnosis_configs WHERE name = ?').get(b.diagnosis_group) as
        | { default_days: number }
        | undefined;
      const expectedDischarge =
        b.expected_discharge_date ||
        computeExpectedDischargeAt(b.expected_admission_date || new Date().toISOString(), diagRow?.default_days ?? 3, dayCfg);

      const regId = `reg-${crypto.randomUUID().slice(0, 8)}`;
      const patId = `pat-${crypto.randomUUID().slice(0, 8)}`;
      const regCode = `DK-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`;

      const initialStatus =
        b.reservation_type === 'WAITLIST' || b.reservation_type === 'NONE' ? 'WAITING' : 'WAITING';

      cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'REGISTRATION_CREATE', 'REGISTRATION', regId, {
        id: regId,
        registration_code: regCode,
        patient_id: patId,
        patient_code: b.patient_code.trim(),
        his_record_code: b.his_record_code?.trim() || '',
        patient_name: b.patient_name.trim(),
        date_of_birth: b.date_of_birth,
        phone: b.phone?.trim() || '',
        diagnosis_group: b.diagnosis_group,
        expected_admission_date: b.expected_admission_date || new Date().toISOString(),
        expected_discharge_date: expectedDischarge,
        desired_standard_ids: b.desired_standard_ids || [],
        registration_mode: b.registration_mode,
        department_id: b.registration_mode === 'KNOWN_DEPT' ? b.department_id || null : null,
        room_id: b.room_id || null,
        bed_id: b.bed_id || null,
        reservation_type: b.reservation_type || 'NONE',
        status: initialStatus,
        notes: b.notes || '',
        created_by: req.authUser!.id,
        created_by_name: req.authUser!.full_name,
        audit_action: 'CREATE_REGISTRATION',
        audit_details: `Đăng ký trước ${regCode} cho bệnh nhân ${b.patient_name}`,
      });

      let consensusResult: { committed: boolean; pendingConfirmation: boolean } | null = null;

      // Manual hold if cashier/staff explicitly picked SINGLE_BED or WHOLE_ROOM
      if (b.registration_mode === 'KNOWN_DEPT' && b.department_id && b.room_id && (b.reservation_type === 'SINGLE_BED' || b.reservation_type === 'WHOLE_ROOM')) {
        const resId = `res-${crypto.randomUUID().slice(0, 8)}`;
        const holdHours = Number(cfg.reservation_hold_hours || '12');
        const startTime = new Date().toISOString();
        const expiresAt = new Date(Date.now() + holdHours * 3600 * 1000).toISOString();
        const isWholeRoom = b.reservation_type === 'WHOLE_ROOM';
        const roomBeds = db.prepare("SELECT id FROM beds WHERE room_id = ? AND status != 'INACTIVE'").all(b.room_id) as Array<{ id: string }>;

        consensusResult = await cluster.proposeCriticalAllocation({
          nodeId: cluster.activeNodeId,
          userId: req.authUser!.id,
          requestType: isWholeRoom ? 'EXCLUSIVE_ROOM' : 'RESERVE_BED',
          eventType: 'RESERVATION_CREATE',
          aggregateType: 'RESERVATION',
          aggregateId: resId,
          bedId: isWholeRoom ? null : b.bed_id,
          roomId: b.room_id,
          isWholeRoom,
          payloadObj: {
            id: resId,
            registration_id: regId,
            patient_id: patId,
            patient_name: b.patient_name.trim(),
            department_id: b.department_id,
            room_id: b.room_id,
            bed_id: isWholeRoom ? null : b.bed_id,
            is_whole_room: isWholeRoom,
            locked_bed_ids: isWholeRoom ? roomBeds.map((x) => x.id) : [b.bed_id],
            start_time: startTime,
            expires_at: expiresAt,
            status: 'ACTIVE',
            notes: b.notes || (isWholeRoom ? 'Giữ trọn phòng từ đăng ký trước' : 'Giữ giường từ đăng ký trước'),
            created_by: req.authUser!.id,
            created_by_name: req.authUser!.full_name,
            audit_action: isWholeRoom ? 'RESERVE_WHOLE_ROOM' : 'RESERVE_BED',
            audit_details: `Giữ chỗ cho hồ sơ ${regCode}`,
          },
        });
      }

      res.status(201).json({
        id: regId,
        registration_code: regCode,
        pendingConfirmation: consensusResult?.pendingConfirmation ?? false,
      });
    } catch (err) {
      if (err instanceof ConsensusConflictError) {
        res.status(409).json({ error: err.message, code: err.code });
        return;
      }
      if (err instanceof SecurityRejectionError) {
        res.status(403).json({ error: err.message, code: err.code });
        return;
      }
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // --- RESERVATIONS ---
  router.get('/reservations', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db
      .prepare(
        `SELECT rsv.*, d.name as department_name, rm.name as room_name, b.code as bed_code
         FROM reservations rsv
         JOIN departments d ON rsv.department_id = d.id
         JOIN rooms rm ON rsv.room_id = rm.id
         LEFT JOIN beds b ON rsv.bed_id = b.id
         ORDER BY rsv.created_at DESC`
      )
      .all() as Array<Record<string, unknown>>;
    res.json(
      rows.map((r) => ({
        ...r,
        locked_bed_ids: JSON.parse((r.locked_bed_ids as string) || '[]'),
      }))
    );
  });

  router.post('/reservations', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'), async (req: AuthedRequest, res) => {
    try {
      const b = req.body as {
        registration_id?: string;
        patient_id?: string;
        patient_name: string;
        department_id: string;
        room_id: string;
        bed_id?: string | null;
        is_whole_room: boolean;
        hold_hours?: number;
        notes?: string;
      };
      if (!b.patient_name?.trim() || !b.department_id || !b.room_id || (!b.is_whole_room && !b.bed_id)) {
        res.status(400).json({ error: 'Vui lòng chọn bệnh nhân, khoa, phòng và giường (hoặc bao trọn phòng).' });
        return;
      }
      if (!enforceWardScope(req.authUser!, b.department_id)) {
        res.status(403).json({ error: 'Không có quyền giữ chỗ cho khoa khác.' });
        return;
      }

      const db = cluster.getActiveNode().db;
      const cfg = getConfigMap(db);
      const hours = b.hold_hours || Number(cfg.reservation_hold_hours || '12');
      const resId = `res-${crypto.randomUUID().slice(0, 8)}`;
      const patId = b.patient_id || `pat-${crypto.randomUUID().slice(0, 8)}`;
      const roomBeds = db.prepare("SELECT id FROM beds WHERE room_id = ? AND status != 'INACTIVE'").all(b.room_id) as Array<{ id: string }>;

      const result = await cluster.proposeCriticalAllocation({
        nodeId: cluster.activeNodeId,
        userId: req.authUser!.id,
        requestType: b.is_whole_room ? 'EXCLUSIVE_ROOM' : 'RESERVE_BED',
        eventType: 'RESERVATION_CREATE',
        aggregateType: 'RESERVATION',
        aggregateId: resId,
        bedId: b.is_whole_room ? null : b.bed_id,
        roomId: b.room_id,
        isWholeRoom: b.is_whole_room,
        payloadObj: {
          id: resId,
          registration_id: b.registration_id ?? null,
          patient_id: patId,
          patient_name: b.patient_name.trim(),
          department_id: b.department_id,
          room_id: b.room_id,
          bed_id: b.is_whole_room ? null : b.bed_id,
          is_whole_room: b.is_whole_room,
          locked_bed_ids: b.is_whole_room ? roomBeds.map((x) => x.id) : [b.bed_id],
          start_time: new Date().toISOString(),
          expires_at: new Date(Date.now() + hours * 3600 * 1000).toISOString(),
          status: 'ACTIVE',
          notes: b.notes || '',
          created_by: req.authUser!.id,
          created_by_name: req.authUser!.full_name,
          audit_action: b.is_whole_room ? 'RESERVE_WHOLE_ROOM' : 'RESERVE_BED',
          audit_details: `Giữ chỗ cho ${b.patient_name}`,
        },
      });
      res.status(201).json({ id: resId, ...result });
    } catch (err) {
      if (err instanceof ConsensusConflictError) {
        res.status(409).json({ error: err.message, code: err.code });
        return;
      }
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/reservations/:id/extend', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const { additional_hours, notes } = req.body as { additional_hours: number; notes?: string };
    const db = cluster.getActiveNode().db;
    const rsv = db.prepare('SELECT * FROM reservations WHERE id = ?').get(req.params.id) as { expires_at: string; department_id: string } | undefined;
    if (!rsv) {
      res.status(404).json({ error: 'Không tìm thấy lượt giữ chỗ.' });
      return;
    }
    const newExp = new Date(new Date(rsv.expires_at).getTime() + (additional_hours || 6) * 3600 * 1000).toISOString();
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'RESERVATION_EXTEND', 'RESERVATION', req.params.id, {
      reservation_id: req.params.id,
      expires_at: newExp,
      notes: notes || `Gia hạn giữ chỗ thêm ${additional_hours || 6} giờ`,
      audit_action: 'EXTEND_RESERVATION',
      audit_details: `Gia hạn giữ chỗ ${req.params.id}`,
    });
    res.json({ ok: true, expires_at: newExp });
  });

  router.post('/reservations/:id/cancel', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const rsv = db.prepare('SELECT * FROM reservations WHERE id = ?').get(req.params.id) as { department_id: string } | undefined;
    if (!rsv) {
      res.status(404).json({ error: 'Không tìm thấy lượt giữ chỗ.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, rsv.department_id)) {
      res.status(403).json({ error: 'Không có quyền hủy giữ chỗ của khoa khác.' });
      return;
    }
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'RESERVATION_CANCEL', 'RESERVATION', req.params.id, {
      reservation_id: req.params.id,
      audit_action: 'CANCEL_RESERVATION',
      audit_details: `Hủy giữ chỗ ${req.params.id}`,
    });
    res.json({ ok: true });
  });

  // --- ADMISSIONS (INPATIENTS & WARD CONFIRMATION) ---
  router.get('/admissions', requireAuth, (req, res) => {
    const db = cluster.getActiveNode().db;
    const statusFilter = req.query.status as string | undefined;
    const cfg = getConfigMap(db);
    const dayCfg = getDayConfig(cfg);
    const nowIso = new Date().toISOString();

    const rows = db
      .prepare(
        `SELECT a.*, d.name as department_name, r.name as room_name, b.code as bed_code
         FROM admissions a
         JOIN departments d ON a.department_id = d.id
         JOIN rooms r ON a.room_id = r.id
         JOIN beds b ON a.bed_id = b.id
         ORDER BY a.bed_assigned_at DESC`
      )
      .all() as Array<Record<string, unknown>>;

    const filtered = statusFilter ? rows.filter((a) => a.status === statusFilter) : rows;
    res.json(
      filtered.map((a) => ({
        ...a,
        stay_metrics: calculateStayMetrics(
          a.bed_assigned_at as string,
          a.expected_discharge_at as string,
          (a.actual_discharge_at as string | null) ?? null,
          (a.calculation_method as BedDayConfig['method']) || 'CALENDAR_DAYS',
          dayCfg,
          nowIso
        ),
        vitals_24h: buildPatientVitals24h({
          admissionId: String(a.id),
          patientCode: String(a.patient_code ?? ''),
          triagePriority: (a.triage_priority as string | null) ?? 'NORMAL',
          vitalsAlert: (a.vitals_alert as string | null) ?? '',
          diagnosisGroup: (a.diagnosis_group as string | null) ?? '',
          nowIso,
        }),
      }))
    );
  });

  router.post('/admissions/confirm', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), async (req: AuthedRequest, res) => {
    try {
      const b = req.body as {
        registration_id?: string;
        reservation_id?: string;
        patient_id?: string;
        patient_code: string;
        his_record_code?: string;
        patient_name: string;
        date_of_birth: string;
        phone?: string;
        diagnosis_group: string;
        department_id: string;
        room_id: string;
        bed_id: string;
        is_whole_room?: boolean;
        expected_discharge_at?: string;
        notes?: string;
      };
      if (!b.patient_code?.trim() || !b.patient_name?.trim() || !b.department_id || !b.room_id || !b.bed_id) {
        res.status(400).json({ error: 'Vui lòng nhập đầy đủ thông tin bệnh nhân, khoa, phòng và giường.' });
        return;
      }
      if (!enforceWardScope(req.authUser!, b.department_id)) {
        res.status(403).json({ error: 'Nhân viên khoa nội trú không được xác nhận nhập khoa cho khoa khác.' });
        return;
      }

      const db = cluster.getActiveNode().db;
      const cfg = getConfigMap(db);
      const dayCfg = getDayConfig(cfg);
      const diagRow = db.prepare('SELECT default_days FROM diagnosis_configs WHERE name = ?').get(b.diagnosis_group) as
        | { default_days: number }
        | undefined;
      const now = new Date().toISOString();
      const expectedDischarge =
        b.expected_discharge_at || computeExpectedDischargeAt(now, diagRow?.default_days ?? 3, dayCfg);

      const admId = `adm-${crypto.randomUUID().slice(0, 8)}`;
      const patId = b.patient_id || `pat-${crypto.randomUUID().slice(0, 8)}`;
      const admCode = `HS-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`;

      const result = await cluster.proposeCriticalAllocation({
        nodeId: cluster.activeNodeId,
        userId: req.authUser!.id,
        requestType: b.is_whole_room ? 'EXCLUSIVE_ROOM' : 'ASSIGN_BED',
        eventType: 'ADMISSION_CONFIRM',
        aggregateType: 'ADMISSION',
        aggregateId: admId,
        bedId: b.bed_id,
        roomId: b.room_id,
        reservationId: b.reservation_id || null,
        isWholeRoom: Boolean(b.is_whole_room),
        payloadObj: {
          id: admId,
          admission_code: admCode,
          registration_id: b.registration_id ?? null,
          reservation_id: b.reservation_id ?? null,
          patient_id: patId,
          patient_code: b.patient_code.trim(),
          his_record_code: b.his_record_code?.trim() || '',
          patient_name: b.patient_name.trim(),
          date_of_birth: b.date_of_birth || '1990-01-01',
          phone: b.phone?.trim() || '',
          diagnosis_group: b.diagnosis_group || 'Khác',
          department_id: b.department_id,
          room_id: b.room_id,
          bed_id: b.bed_id,
          is_whole_room: Boolean(b.is_whole_room),
          hospital_admitted_at: now,
          bed_assigned_at: now,
          expected_discharge_at: expectedDischarge,
          calculation_method: dayCfg.method,
          status: 'ACTIVE',
          notes: b.notes || '',
          confirmed_by: req.authUser!.id,
          confirmed_by_name: req.authUser!.full_name,
          audit_action: 'CONFIRM_ADMISSION',
          audit_details: `Tiếp nhận ${b.patient_name} vào giường ${b.bed_id}`,
        },
      });

      res.status(201).json({
        id: admId,
        admission_code: admCode,
        ...result,
      });
    } catch (err) {
      if (err instanceof ConsensusConflictError) {
        res.status(409).json({ error: err.message, code: err.code });
        return;
      }
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // --- EXTENSIONS ---
  router.get('/extensions', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    res.json(db.prepare('SELECT * FROM bed_extensions ORDER BY performed_at DESC').all());
  });

  router.post('/admissions/:id/extend', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const { new_expected_discharge_at, reason } = req.body as {
      new_expected_discharge_at: string;
      reason: string;
    };
    if (!new_expected_discharge_at || !reason?.trim()) {
      res.status(400).json({ error: 'Vui lòng chọn ngày trả mới và nhập lý do gia hạn.' });
      return;
    }
    const db = cluster.getActiveNode().db;
    const adm = db
      .prepare(
        `SELECT a.*, b.code as bed_code FROM admissions a JOIN beds b ON a.bed_id = b.id WHERE a.id = ? AND a.status = 'ACTIVE'`
      )
      .get(req.params.id) as
      | {
          id: string;
          patient_id: string;
          patient_name: string;
          bed_id: string;
          bed_code: string;
          department_id: string;
          expected_discharge_at: string;
        }
      | undefined;
    if (!adm) {
      res.status(404).json({ error: 'Không tìm thấy lượt nằm đang hoạt động.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, adm.department_id)) {
      res.status(403).json({ error: 'Không được phép gia hạn cho bệnh nhân của khoa khác.' });
      return;
    }

    const extId = `ext-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_EXTEND', 'ADMISSION', adm.id, {
      id: extId,
      admission_id: adm.id,
      patient_id: adm.patient_id,
      patient_name: adm.patient_name,
      bed_id: adm.bed_id,
      bed_code: adm.bed_code,
      old_expected_discharge_at: adm.expected_discharge_at,
      new_expected_discharge_at,
      reason: reason.trim(),
      performed_by: req.authUser!.id,
      performed_by_name: req.authUser!.full_name,
      performed_at: new Date().toISOString(),
      audit_action: 'EXTEND_BED',
      audit_details: `Gia hạn giường ${adm.bed_code} cho ${adm.patient_name}`,
    });

    res.status(201).json({ id: extId });
  });

  // --- TRANSFERS ---
  router.get('/transfers', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db
      .prepare(
        `SELECT t.*, fd.name as from_department_name, td.name as to_department_name,
                fb.code as from_bed_code, tb.code as to_bed_code
         FROM bed_transfers t
         JOIN departments fd ON t.from_department_id = fd.id
         JOIN departments td ON t.to_department_id = td.id
         JOIN beds fb ON t.from_bed_id = fb.id
         JOIN beds tb ON t.to_bed_id = tb.id
         ORDER BY t.performed_at DESC`
      )
      .all();
    res.json(rows);
  });

  router.post('/admissions/:id/transfer', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), async (req: AuthedRequest, res) => {
    try {
      const { to_department_id, to_room_id, to_bed_id, reason } = req.body as {
        to_department_id: string;
        to_room_id: string;
        to_bed_id: string;
        reason: string;
      };
      if (!to_department_id || !to_room_id || !to_bed_id || !reason?.trim()) {
        res.status(400).json({ error: 'Vui lòng chọn giường đích và nhập lý do điều chuyển.' });
        return;
      }
      const db = cluster.getActiveNode().db;
      const adm = db.prepare("SELECT * FROM admissions WHERE id = ? AND status = 'ACTIVE'").get(req.params.id) as
        | {
            id: string;
            patient_id: string;
            patient_name: string;
            department_id: string;
            room_id: string;
            bed_id: string;
            is_whole_room: number;
          }
        | undefined;
      if (!adm) {
        res.status(404).json({ error: 'Không tìm thấy lượt nằm đang hoạt động.' });
        return;
      }
      if (!enforceWardScope(req.authUser!, adm.department_id)) {
        res.status(403).json({ error: 'Không được phép điều chuyển bệnh nhân của khoa khác.' });
        return;
      }

      const transferId = `trf-${crypto.randomUUID().slice(0, 8)}`;
      const cleaningLogId = `cln-${crypto.randomUUID().slice(0, 8)}`;
      const result = await cluster.proposeCriticalAllocation({
        nodeId: cluster.activeNodeId,
        userId: req.authUser!.id,
        requestType: 'ASSIGN_BED',
        eventType: 'BED_TRANSFER',
        aggregateType: 'ADMISSION',
        aggregateId: adm.id,
        bedId: to_bed_id,
        roomId: to_room_id,
        payloadObj: {
          id: transferId,
          admission_id: adm.id,
          patient_id: adm.patient_id,
          patient_name: adm.patient_name,
          from_department_id: adm.department_id,
          from_room_id: adm.room_id,
          from_bed_id: adm.bed_id,
          to_department_id,
          to_room_id,
          to_bed_id,
          was_whole_room: Boolean(adm.is_whole_room),
          cleaning_log_id: cleaningLogId,
          reason: reason.trim(),
          performed_by: req.authUser!.id,
          performed_by_name: req.authUser!.full_name,
          performed_at: new Date().toISOString(),
          audit_action: 'TRANSFER_BED',
          audit_details: `Điều chuyển ${adm.patient_name} sang giường ${to_bed_id}`,
        },
      });
      res.status(201).json({ id: transferId, ...result });
    } catch (err) {
      if (err instanceof ConsensusConflictError) {
        res.status(409).json({ error: err.message, code: err.code });
        return;
      }
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // --- DISCHARGE ---
  // Note: CASHIER is strictly forbidden from discharging on behalf of WARD_STAFF!
  router.post('/admissions/:id/discharge', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const { notes } = req.body as { notes?: string };
    const db = cluster.getActiveNode().db;
    const adm = db.prepare("SELECT * FROM admissions WHERE id = ? AND status = 'ACTIVE'").get(req.params.id) as
      | { id: string; department_id: string; patient_name: string; bed_id: string }
      | undefined;
    if (!adm) {
      res.status(404).json({ error: 'Không tìm thấy lượt nằm đang hoạt động.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, adm.department_id)) {
      res.status(403).json({ error: 'Nhân viên khoa nội trú không được trả giường hộ khoa khác.' });
      return;
    }

    const cleaningLogId = `cln-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'BED_DISCHARGE', 'ADMISSION', adm.id, {
      admission_id: adm.id,
      actual_discharge_at: new Date().toISOString(),
      performed_by: req.authUser!.id,
      cleaning_log_id: cleaningLogId,
      notes: notes || 'Xuất viện và chuyển giường sang chờ vệ sinh',
      audit_action: 'DISCHARGE_BED',
      audit_details: `Trả giường cho bệnh nhân ${adm.patient_name}`,
    });
    res.json({ ok: true, cleaning_log_id: cleaningLogId });
  });

  // --- CLEANING ---
  router.get('/cleaning', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db
      .prepare(
        `SELECT cl.*, b.code as bed_code, r.name as room_name, d.name as department_name
         FROM cleaning_logs cl
         JOIN beds b ON cl.bed_id = b.id
         JOIN rooms r ON cl.room_id = r.id
         JOIN departments d ON cl.department_id = d.id
         ORDER BY cl.requested_at DESC`
      )
      .all();
    res.json(rows);
  });

  router.post('/cleaning/:id/start', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const cl = db.prepare('SELECT * FROM cleaning_logs WHERE id = ?').get(req.params.id) as
      | { id: string; bed_id: string; department_id: string }
      | undefined;
    if (!cl) {
      res.status(404).json({ error: 'Không tìm thấy phiếu vệ sinh.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, cl.department_id)) {
      res.status(403).json({ error: 'Không có quyền thao tác vệ sinh cho khoa khác.' });
      return;
    }
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'CLEANING_START', 'CLEANING', cl.id, {
      cleaning_log_id: cl.id,
      bed_id: cl.bed_id,
      performed_by_name: req.authUser!.full_name,
      audit_action: 'START_CLEANING',
      audit_details: `Bắt đầu vệ sinh giường ${cl.bed_id}`,
    });
    res.json({ ok: true });
  });

  router.post('/cleaning/:id/complete', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const cl = db.prepare('SELECT * FROM cleaning_logs WHERE id = ?').get(req.params.id) as
      | { id: string; bed_id: string; department_id: string }
      | undefined;
    if (!cl) {
      res.status(404).json({ error: 'Không tìm thấy phiếu vệ sinh.' });
      return;
    }
    if (!enforceWardScope(req.authUser!, cl.department_id)) {
      res.status(403).json({ error: 'Không có quyền xác nhận vệ sinh cho khoa khác.' });
      return;
    }
    const { notes } = req.body as { notes?: string };
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'CLEANING_COMPLETE', 'CLEANING', cl.id, {
      cleaning_log_id: cl.id,
      bed_id: cl.bed_id,
      performed_by: req.authUser!.id,
      performed_by_name: req.authUser!.full_name,
      notes,
      audit_action: 'COMPLETE_CLEANING',
      audit_details: `Hoàn tất vệ sinh giường ${cl.bed_id}, sẵn sàng đón bệnh nhân mới`,
    });
    res.json({ ok: true });
  });

  // --- HIS / EXCEL IMPORT ---
  router.post('/import/patients', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN', 'CASHIER'), (req: AuthedRequest, res) => {
    const { fileName, rows } = req.body as {
      fileName: string;
      rows: Array<{
        patient_code: string;
        his_record_code?: string;
        full_name: string;
        date_of_birth: string;
        phone?: string;
        diagnosis_group?: string;
      }>;
    };
    if (!Array.isArray(rows) || rows.length === 0) {
      res.status(400).json({ error: 'Không có dữ liệu hợp lệ để nhập.' });
      return;
    }

    const db = cluster.getActiveNode().db;
    const cfg = getConfigMap(db);
    const dayCfg = getDayConfig(cfg);
    let importedCount = 0;
    let duplicateCount = 0;
    let errorCount = 0;
    const errors: Array<{ row: number; reason: string }> = [];

    rows.forEach((r, idx) => {
      if (!r.patient_code?.trim() || !r.full_name?.trim() || !r.date_of_birth?.trim()) {
        errorCount++;
        errors.push({ row: idx + 1, reason: 'Thiếu mã BN, họ tên hoặc ngày sinh' });
        return;
      }
      // Never merge solely by full_name! Check exact patient_code OR exact his_record_code
      const existingByCode = db
        .prepare("SELECT id FROM patients WHERE patient_code = ? OR (his_record_code != '' AND his_record_code = ?)")
        .get(r.patient_code.trim(), r.his_record_code?.trim() || '__NONE__');

      if (existingByCode) {
        duplicateCount++;
        return;
      }

      const patId = `pat-${crypto.randomUUID().slice(0, 8)}`;
      const regId = `reg-${crypto.randomUUID().slice(0, 8)}`;
      const regCode = `DK-IMP-${Date.now().toString().slice(-4)}-${idx + 1}`;
      const diag = r.diagnosis_group?.trim() || 'Khác';
      const now = new Date().toISOString();

      cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'REGISTRATION_CREATE', 'REGISTRATION', regId, {
        id: regId,
        registration_code: regCode,
        patient_id: patId,
        patient_code: r.patient_code.trim(),
        his_record_code: r.his_record_code?.trim() || '',
        patient_name: r.full_name.trim(),
        date_of_birth: r.date_of_birth.trim(),
        phone: r.phone?.trim() || '',
        diagnosis_group: diag,
        expected_admission_date: now,
        expected_discharge_date: computeExpectedDischargeAt(now, 3, dayCfg),
        desired_standard_ids: [],
        registration_mode: 'UNKNOWN_DEPT',
        department_id: null,
        reservation_type: 'WAITLIST',
        status: 'WAITING',
        notes: `Nhập từ file ${fileName}`,
        created_by: req.authUser!.id,
        created_by_name: req.authUser!.full_name,
      });
      importedCount++;
    });

    const logId = `imp-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'HIS_IMPORT_LOG', 'IMPORT', logId, {
      id: logId,
      file_name: fileName || 'import.xlsx',
      total_rows: rows.length,
      imported_rows: importedCount,
      duplicate_rows: duplicateCount,
      error_rows: errorCount,
      performed_by: req.authUser!.full_name,
      audit_action: 'IMPORT_HIS_EXCEL',
      audit_details: `Nhập ${importedCount}/${rows.length} dòng từ ${fileName}`,
    });

    res.json({
      totalRows: rows.length,
      importedRows: importedCount,
      duplicateRows: duplicateCount,
      errorRows: errorCount,
      errors,
    });
  });

  router.get('/import/logs', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    res.json(db.prepare('SELECT * FROM his_import_logs ORDER BY created_at DESC LIMIT 30').all());
  });

  // --- REPORTS (12 real analytical reports) ---
  router.get('/reports/analytics', requireAuth, (req, res) => {
    const db = cluster.getActiveNode().db;
    const deptFilter = (req.query.departmentId as string) || '';
    const cfg = getConfigMap(db);
    const dayCfg = getDayConfig(cfg);
    const nowIso = new Date().toISOString();

    const depts = db.prepare('SELECT * FROM departments').all() as Array<{ id: string; name: string }>;
    const rooms = db.prepare('SELECT * FROM rooms').all() as Array<{ id: string; name: string; code: string; department_id: string; room_type: string; capacity: number }>;
    const beds = db.prepare('SELECT * FROM beds').all() as Array<{ id: string; code: string; room_id: string; department_id: string; status: string }>;
    const admissions = db.prepare('SELECT * FROM admissions').all() as Array<Record<string, unknown>>;
    const extensions = db.prepare('SELECT * FROM bed_extensions ORDER BY performed_at DESC').all();
    const transfers = db.prepare('SELECT * FROM bed_transfers ORDER BY performed_at DESC').all();

    const filteredAdmissions = deptFilter ? admissions.filter((a) => a.department_id === deptFilter) : admissions;
    const filteredBeds = deptFilter ? beds.filter((b) => b.department_id === deptFilter) : beds;
    const filteredRooms = deptFilter ? rooms.filter((r) => r.department_id === deptFilter) : rooms;

    const deptUsage = depts.map((d) => {
      const dBeds = beds.filter((b) => b.department_id === d.id);
      const dOps = dBeds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length;
      const dOcc = dBeds.filter((b) => b.status === 'OCCUPIED').length;
      const dAdms = admissions.filter((a) => a.department_id === d.id);
      const dDischarged = dAdms.filter((a) => a.status === 'DISCHARGED').length;
      return {
        department_id: d.id,
        department_name: d.name,
        total_beds: dBeds.length,
        operational_beds: dOps,
        occupied_beds: dOcc,
        occupancy_rate: calculateBedOccupancyRate(dOcc, dOps),
        admission_count: dAdms.length,
        discharge_count: dDischarged,
      };
    });

    const roomUsage = filteredRooms.map((r) => {
      const rBeds = filteredBeds.filter((b) => b.room_id === r.id);
      const rOps = rBeds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length;
      const rOcc = rBeds.filter((b) => b.status === 'OCCUPIED').length;
      return {
        room_id: r.id,
        room_code: r.code,
        room_name: r.name,
        room_type: r.room_type,
        capacity: r.capacity,
        occupied: rOcc,
        occupancy_rate: calculateBedOccupancyRate(rOcc, rOps),
      };
    });

    let totalBedDays = 0;
    let completedCount = 0;
    let completedHours = 0;
    const overdueList: Array<Record<string, unknown>> = [];
    const dueSoonList: Array<Record<string, unknown>> = [];
    const deptNameMap = Object.fromEntries(depts.map((d) => [d.id, d.name]));
    const bedCodeMap = Object.fromEntries(beds.map((b) => [b.id, b.code]));

    for (const a of filteredAdmissions) {
      const metrics = calculateStayMetrics(
        a.bed_assigned_at as string,
        a.expected_discharge_at as string,
        (a.actual_discharge_at as string | null) ?? null,
        (a.calculation_method as BedDayConfig['method']) || 'CALENDAR_DAYS',
        dayCfg,
        nowIso
      );
      totalBedDays += metrics.daysStayed;
      if (a.status === 'DISCHARGED' && a.actual_discharge_at) {
        completedCount++;
        completedHours += Math.max(1, (new Date(a.actual_discharge_at as string).getTime() - new Date(a.bed_assigned_at as string).getTime()) / 3600000);
      }
      if (a.status === 'ACTIVE') {
        const enriched = {
          ...a,
          department_name: deptNameMap[a.department_id as string] ?? '',
          bed_code: bedCodeMap[a.bed_id as string] ?? '',
          stay_metrics: metrics,
        };
        if (metrics.dueState === 'OVERDUE') overdueList.push(enriched);
        if (metrics.dueState === 'DUE_SOON' || metrics.dueState === 'DUE_TODAY') dueSoonList.push(enriched);
      }
    }

    const avgStayDays = completedCount > 0 ? Math.round((completedHours / completedCount / 24) * 10) / 10 : totalBedDays > 0 && filteredAdmissions.length > 0 ? Math.round((totalBedDays / filteredAdmissions.length) * 10) / 10 : 0;

    res.json({
      kpi: {
        totalAdmissions: filteredAdmissions.length,
        totalDischarges: filteredAdmissions.filter((a) => a.status === 'DISCHARGED').length,
        totalBedDays,
        totalExtensions: extensions.length,
        totalTransfers: transfers.length,
        avgStayDays,
        occupancyRate: calculateBedOccupancyRate(
          filteredBeds.filter((b) => b.status === 'OCCUPIED').length,
          filteredBeds.filter((b) => b.status !== 'INACTIVE' && b.status !== 'MAINTENANCE').length
        ),
      },
      deptUsage,
      roomUsage,
      overdueList,
      dueSoonList,
      transfers,
      extensions,
    });
  });

  // --- USERS & RBAC ---
  router.get('/users', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (_req, res) => {
    const db = cluster.getActiveNode().db;
    const rows = db
      .prepare(
        `SELECT u.id, u.username, u.full_name, u.role, u.department_id, u.status, u.created_at, u.updated_at, d.name as department_name
         FROM users u
         LEFT JOIN departments d ON u.department_id = d.id
         ORDER BY CASE WHEN LOWER(u.username) = 'admin' THEN 0 ELSE 1 END, u.created_at ASC`
      )
      .all() as Array<{ id: string; username: string; [key: string]: unknown }>;
    res.json(
      rows.map((u) => ({
        ...u,
        is_default_admin: isDefaultAdminAccount(u),
      }))
    );
  });

  router.post('/users', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, username, password, full_name, role, department_id, status } = req.body as {
      id?: string;
      username: string;
      password?: string;
      full_name: string;
      role: UserRole;
      department_id?: string | null;
      status?: 'ACTIVE' | 'LOCKED' | 'REVOKED';
    };
    const cleanUsername = username?.trim();
    if (!cleanUsername || !full_name?.trim() || !role) {
      res.status(400).json({ error: 'Thiếu tên đăng nhập, họ tên hoặc nhóm quyền.' });
      return;
    }

    const db = cluster.getActiveNode().db;

    if (id) {
      const existing = db.prepare('SELECT id, username, role FROM users WHERE id = ?').get(id) as
        | { id: string; username: string; role: UserRole }
        | undefined;
      if (!existing) {
        res.status(404).json({ error: 'Không tìm thấy tài khoản cần cập nhật.' });
        return;
      }
      const check = validateUserUpdateRule({
        actorRole: req.authUser!.role,
        targetUser: existing,
        nextUsername: cleanUsername,
        nextRole: role,
        nextStatus: status,
      });
      if (!check.allowed) {
        res.status(check.statusCode).json({ error: check.error });
        return;
      }
    } else {
      if (req.authUser!.role === 'ADMIN' && role === 'SUPER_ADMIN') {
        res.status(403).json({ error: 'Admin không được phép tạo tài khoản Super Admin.' });
        return;
      }
      const dup = db.prepare('SELECT id FROM users WHERE LOWER(username) = ?').get(cleanUsername.toLowerCase());
      if (dup) {
        res.status(409).json({ error: `Tên đăng nhập "${cleanUsername}" đã tồn tại trong hệ thống.` });
        return;
      }
      if (!password || password.length < MIN_USER_PASSWORD_LENGTH) {
        res.status(400).json({ error: `Mật khẩu tạo mới tối thiểu ${MIN_USER_PASSWORD_LENGTH} ký tự.` });
        return;
      }
    }

    const userId = id || `usr-${crypto.randomUUID().slice(0, 8)}`;
    const isDefault = id ? isDefaultAdminAccount({ id, username: cleanUsername }) : false;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'USER_UPSERT', 'USER', userId, {
      id: userId,
      username: isDefault ? 'admin' : cleanUsername,
      password_hash: password ? hashPassword(password) : '',
      full_name: full_name.trim(),
      role: isDefault ? 'SUPER_ADMIN' : role,
      department_id: isDefault ? null : (role === 'WARD_STAFF' ? department_id || null : null),
      status: isDefault ? 'ACTIVE' : (status || 'ACTIVE'),
      audit_action: id ? 'UPDATE_USER' : 'CREATE_USER',
      audit_details: `${id ? 'Cập nhật' : 'Tạo'} tài khoản ${cleanUsername} (${role})`,
    });
    res.status(id ? 200 : 201).json({ id: userId });
  });

  router.put('/users/:id', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const existing = db.prepare('SELECT id, username, role, status FROM users WHERE id = ?').get(req.params.id) as
      | { id: string; username: string; role: UserRole; status: 'ACTIVE' | 'LOCKED' | 'REVOKED' }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
      return;
    }

    const { username, full_name, role, department_id, status, password } = req.body as {
      username?: string;
      full_name: string;
      role: UserRole;
      department_id?: string | null;
      status?: 'ACTIVE' | 'LOCKED' | 'REVOKED';
      password?: string;
    };

    if (!full_name?.trim() || !role) {
      res.status(400).json({ error: 'Họ tên và nhóm quyền là bắt buộc.' });
      return;
    }
    if (password && password.length < MIN_USER_PASSWORD_LENGTH) {
      res.status(400).json({ error: `Mật khẩu mới tối thiểu ${MIN_USER_PASSWORD_LENGTH} ký tự.` });
      return;
    }

    const check = validateUserUpdateRule({
      actorRole: req.authUser!.role,
      targetUser: existing,
      nextUsername: username,
      nextRole: role,
      nextStatus: status,
    });
    if (!check.allowed) {
      res.status(check.statusCode).json({ error: check.error });
      return;
    }

    const isDefault = isDefaultAdminAccount(existing);
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'USER_UPSERT', 'USER', existing.id, {
      id: existing.id,
      username: existing.username,
      password_hash: password ? hashPassword(password) : '',
      full_name: full_name.trim(),
      role: isDefault ? 'SUPER_ADMIN' : role,
      department_id: isDefault ? null : (role === 'WARD_STAFF' ? department_id || null : null),
      status: isDefault ? 'ACTIVE' : (status || existing.status),
      audit_action: 'UPDATE_USER',
      audit_details: `Cập nhật thông tin tài khoản ${existing.username} (${isDefault ? 'SUPER_ADMIN' : role})`,
    });

    res.json({ ok: true, id: existing.id });
  });

  router.post('/users/:id/reset-password', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const existing = db.prepare('SELECT id, username, role FROM users WHERE id = ?').get(req.params.id) as
      | { id: string; username: string; role: UserRole }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
      return;
    }
    if (req.authUser!.role === 'ADMIN' && existing.role === 'SUPER_ADMIN') {
      res.status(403).json({ error: 'Admin hệ thống không được phép đặt lại mật khẩu tài khoản Super Admin.' });
      return;
    }

    const { new_password } = req.body as { new_password?: string };
    const isDefault = isDefaultAdminAccount(existing);
    const trimmed = new_password?.trim();
    if (trimmed && trimmed.length < MIN_USER_PASSWORD_LENGTH) {
      res.status(400).json({ error: `Mật khẩu đặt lại tối thiểu ${MIN_USER_PASSWORD_LENGTH} ký tự.` });
      return;
    }

    const finalPassword = trimmed || (isDefault ? DEFAULT_ADMIN_PASSWORD : DEFAULT_STAFF_RESET_PASSWORD);
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'USER_PASSWORD_RESET', 'USER', existing.id, {
      user_id: existing.id,
      password_hash: hashPassword(finalPassword),
      audit_action: 'RESET_USER_PASSWORD',
      audit_details: `Reset mật khẩu tài khoản ${existing.username}${trimmed ? ' (mật khẩu tùy chỉnh)' : ` (về mặc định)`}`,
    });

    res.json({
      ok: true,
      resetToDefault: !trimmed,
      defaultHint: trimmed ? null : finalPassword,
    });
  });

  router.post('/users/:id/status', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { status } = req.body as { status: 'ACTIVE' | 'LOCKED' | 'REVOKED' };
    const db = cluster.getActiveNode().db;
    const existing = db.prepare('SELECT id, username, role FROM users WHERE id = ?').get(req.params.id) as
      | { id: string; username: string; role: UserRole }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
      return;
    }

    const check = validateUserStatusRule({
      actorId: req.authUser!.id,
      actorRole: req.authUser!.role,
      targetUser: existing,
      nextStatus: status,
    });
    if (!check.allowed) {
      res.status(check.statusCode).json({ error: check.error });
      return;
    }

    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'USER_STATUS_CHANGE', 'USER', existing.id, {
      user_id: existing.id,
      status,
      audit_action: 'CHANGE_USER_STATUS',
      audit_details: `Đổi trạng thái tài khoản ${existing.username} -> ${status}`,
    });
    res.json({ ok: true });
  });

  router.delete('/users/:id', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const db = cluster.getActiveNode().db;
    const existing = db.prepare('SELECT id, username, role FROM users WHERE id = ?').get(req.params.id) as
      | { id: string; username: string; role: UserRole }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
      return;
    }

    const check = validateUserDeleteRule({
      actorId: req.authUser!.id,
      actorRole: req.authUser!.role,
      targetUser: existing,
    });
    if (!check.allowed) {
      res.status(check.statusCode).json({ error: check.error });
      return;
    }

    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'USER_DELETE', 'USER', existing.id, {
      user_id: existing.id,
      audit_action: 'DELETE_USER',
      audit_details: `Xóa tài khoản ${existing.username} (${existing.role})`,
    });
    res.json({ ok: true });
  });

  // --- BACKUP & RESTORE ---
  router.get('/backups', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (_req, res) => {
    const db = cluster.getActiveNode().db;
    res.json(db.prepare('SELECT * FROM backups ORDER BY created_at DESC').all());
  });

  router.post('/backups', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const created = cluster.createEncryptedBackup(cluster.activeNodeId, req.authUser!.username);
    res.status(201).json(created);
  });

  router.post('/backups/:id/restore', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), async (req: AuthedRequest, res) => {
    try {
      const result = await cluster.restoreEncryptedBackup(cluster.activeNodeId, req.params.id, req.authUser!.username);
      res.json(result);
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  // --- SYSTEM CONFIGS & DIAGNOSIS CONFIGS & AUDIT LOGS ---
  router.get('/settings', requireAuth, (_req, res) => {
    const db = cluster.getActiveNode().db;
    const configs = getConfigMap(db);
    const diagnoses = db.prepare('SELECT * FROM diagnosis_configs ORDER BY name ASC').all();
    const auditLogs = db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 80').all();
    res.json({ configs, diagnoses, auditLogs });
  });

  router.post('/settings/configs', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { configs } = req.body as { configs: Record<string, string> };
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'SYSTEM_CONFIG_UPDATE', 'CONFIG', 'system', {
      configs,
      audit_action: 'UPDATE_SYSTEM_CONFIG',
      audit_details: 'Cập nhật cấu hình phương pháp tính ngày giường và cảnh báo',
    });
    res.json({ ok: true });
  });

  router.post('/settings/diagnoses', requireAuth, requireRoles('SUPER_ADMIN', 'ADMIN'), (req: AuthedRequest, res) => {
    const { id, name, default_days, description, is_active } = req.body as {
      id?: string;
      name: string;
      default_days: number;
      description?: string;
      is_active?: number;
    };
    if (!name?.trim() || !default_days || default_days < 1) {
      res.status(400).json({ error: 'Tên nhóm chẩn đoán và số ngày dự kiến (>= 1) là bắt buộc.' });
      return;
    }
    const diagId = id || `diag-${crypto.randomUUID().slice(0, 8)}`;
    cluster.commitStandardEvent(cluster.activeNodeId, req.authUser!.id, 'DIAGNOSIS_CONFIG_UPSERT', 'DIAGNOSIS', diagId, {
      id: diagId,
      name: name.trim(),
      default_days: Number(default_days),
      description: description || '',
      is_active: is_active ?? 1,
      audit_action: 'UPSERT_DIAGNOSIS_CONFIG',
      audit_details: `Cấu hình ngày nằm nhóm ${name}: ${default_days} ngày`,
    });
    res.status(201).json({ id: diagId });
  });

  router.post('/settings/clear-demo-data', requireAuth, requireRoles('SUPER_ADMIN'), (req: AuthedRequest, res) => {
    clearDemoOperationalData(cluster, req.authUser!.id);
    res.json({ ok: true });
  });

  router.post('/settings/seed-demo-data', requireAuth, requireRoles('SUPER_ADMIN'), (_req, res) => {
    const node = cluster.getActiveNode();
    const admCount = (node.db.prepare('SELECT COUNT(*) as c FROM admissions').get() as { c: number }).c;
    if (admCount === 0) {
      // Re-seed operational demo data safely only if empty
      node.db.exec('DELETE FROM users');
      seedDemoClusterIfEmpty(cluster);
    }
    res.json({ ok: true });
  });

  return router;
}
