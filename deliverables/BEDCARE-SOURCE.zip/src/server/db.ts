import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const SCHEMA_PATH = path.resolve(process.cwd(), 'database/schema/schema.sql');
const MIGRATION_001_PATH = path.resolve(process.cwd(), 'database/migrations/001_initial.sql');

function ensureColumn(db: DatabaseSync, table: string, column: string, definition: string) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

export function openNodeDatabase(dbFilePath: string): DatabaseSync {
  if (dbFilePath !== ':memory:') {
    const dir = path.dirname(dbFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
  const db = new DatabaseSync(dbFilePath);
  const schemaSql = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schemaSql);
  const migrationSql = fs.readFileSync(MIGRATION_001_PATH, 'utf8');
  db.exec(migrationSql);

  ensureColumn(db, 'room_standards', 'attributes', "TEXT NOT NULL DEFAULT '{}'");
  ensureColumn(db, 'rooms', 'occupancy_status', "TEXT NOT NULL DEFAULT 'AVAILABLE'");
  ensureColumn(db, 'beds', 'bed_type_id', 'TEXT');
  ensureColumn(db, 'beds', 'daily_price', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn(db, 'admissions', 'triage_priority', "TEXT NOT NULL DEFAULT 'NORMAL'");
  ensureColumn(db, 'admissions', 'vitals_alert', "TEXT DEFAULT ''");
  ensureColumn(db, 'admissions', 'medication_deadline_at', 'TEXT');

  return db;
}

export function getConfigMap(db: DatabaseSync): Record<string, string> {
  const rows = db.prepare('SELECT key, value FROM system_configs').all() as Array<{
    key: string;
    value: string;
  }>;
  const map: Record<string, string> = {};
  for (const r of rows) {
    map[r.key] = r.value;
  }
  return map;
}
