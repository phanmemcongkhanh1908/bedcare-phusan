import { AlertTriangle, History, Plus, Printer, RefreshCw, Wrench } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { BedStatusBadge } from '../../components/BedStatusBadge';
import type { ScreenId } from '../../components/LayoutShell';
import { apiFetch } from '../../services/api';
import type { Bed, BedHistoryEntry, BedStatus, Department, Room, UserRole } from '../../types/bedcare';
import { BED_STATUS_META, formatDateTimeVN, formatDateVN } from '../../utils/formatters';
import {
  ROOM_OCCUPANCY_LABELS,
  validateRoomAndBeds,
  type RoomValidationResult,
} from '../../utils/roomBedValidation';

interface BedsMapPageProps {
  userRole: UserRole;
  userDeptId?: string | null;
  initialDepartmentFilter?: string;
  globalSearch: string;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
  onNavigate: (id: ScreenId) => void;
}

const ALL_STATUSES: BedStatus[] = [
  'VACANT',
  'RESERVED',
  'OCCUPIED',
  'PENDING_CONFIRMATION',
  'PENDING_CLEANING',
  'CLEANING',
  'MAINTENANCE',
  'INACTIVE',
];

const ADMISSION_STATUS_LABELS: Record<BedHistoryEntry['status'], { label: string; cls: string }> = {
  ACTIVE: { label: 'Đang nằm', cls: 'text-sky-700 bg-sky-50 border-sky-200' },
  DISCHARGED: { label: 'Đã trả giường', cls: 'text-emerald-700 bg-emerald-50 border-emerald-200' },
  TRANSFERRED: { label: 'Đã chuyển giường', cls: 'text-amber-700 bg-amber-50 border-amber-200' },
  PENDING_CONFIRMATION: { label: 'Chờ xác nhận', cls: 'text-orange-700 bg-orange-50 border-orange-200' },
};

export function BedsMapPage({
  userRole,
  userDeptId,
  initialDepartmentFilter,
  globalSearch,
  onNotify,
  onNavigate,
}: BedsMapPageProps) {
  const [beds, setBeds] = useState<Bed[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [deptFilter, setDeptFilter] = useState(initialDepartmentFilter ?? '');
  const [statusFilter, setStatusFilter] = useState<BedStatus | ''>('');
  const [loading, setLoading] = useState(true);
  const [fixingConflicts, setFixingConflicts] = useState(false);
  const [selectedBed, setSelectedBed] = useState<Bed | null>(null);
  const [modalTab, setModalTab] = useState<'INFO' | 'HISTORY'>('INFO');
  const [historyItems, setHistoryItems] = useState<BedHistoryEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState('');
  const [printingBed, setPrintingBed] = useState<Bed | null>(null);

  // Add bed modal
  const [showAddBed, setShowAddBed] = useState(false);
  const [newRoomId, setNewRoomId] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');

  const canManageStructure = userRole === 'SUPER_ADMIN' || userRole === 'ADMIN';
  const canToggleMaintenance = canManageStructure || userRole === 'WARD_STAFF';

  useEffect(() => {
    if (printingBed) {
      document.body.classList.add('printing-bedcard');
    } else {
      document.body.classList.remove('printing-bedcard');
    }
    return () => {
      document.body.classList.remove('printing-bedcard');
    };
  }, [printingBed]);

  const load = async () => {
    setLoading(true);
    try {
      const [bData, dData, rData] = await Promise.all([
        apiFetch<Bed[]>('/beds'),
        apiFetch<Department[]>('/departments'),
        apiFetch<Room[]>('/rooms'),
      ]);
      setBeds(bData);
      setDepartments(dData);
      setRooms(rData);
      if (!newRoomId && rData.length > 0) setNewRoomId(rData[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    if (initialDepartmentFilter !== undefined) {
      setDeptFilter(initialDepartmentFilter);
    }
  }, [initialDepartmentFilter]);

  const openBedModal = (bed: Bed) => {
    setSelectedBed(bed);
    setModalTab('INFO');
    setHistoryItems([]);
    setHistoryError('');
  };

  const loadBedHistory = async (bedId: string) => {
    setModalTab('HISTORY');
    setHistoryLoading(true);
    setHistoryError('');
    try {
      const res = await apiFetch<{ bed: Bed; history: BedHistoryEntry[] }>(`/beds/${bedId}/history`);
      setHistoryItems(res.history);
    } catch (e) {
      setHistoryError((e as Error).message);
    } finally {
      setHistoryLoading(false);
    }
  };

  const filteredBeds = beds.filter((b) => {
    if (deptFilter && b.department_id !== deptFilter) return false;
    if (statusFilter && b.status !== statusFilter) return false;
    if (globalSearch.trim()) {
      const q = globalSearch.toLowerCase();
      const hay = `${b.code} ${b.name} ${b.room_name ?? ''} ${b.patient_name ?? ''} ${b.department_name ?? ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  // Validate ALL rooms against ALL beds in the facility
  const roomValidationMap = new Map<string, RoomValidationResult>();
  let totalConflictRooms = 0;
  let totalConflictIssues = 0;
  for (const rm of rooms) {
    const rmBeds = beds.filter((b) => b.room_id === rm.id);
    const v = validateRoomAndBeds(rm, rmBeds);
    roomValidationMap.set(rm.id, v);
    if (v.hasConflict) {
      totalConflictRooms++;
      totalConflictIssues += v.conflicts.length;
    }
  }

  // Group beds by department -> room
  const groupedByRoom = new Map<
    string,
    {
      roomCode: string;
      roomName: string;
      deptName: string;
      floor: string;
      exclusive: boolean;
      validation?: RoomValidationResult;
      beds: Bed[];
    }
  >();
  for (const b of filteredBeds) {
    const key = b.room_id;
    if (!groupedByRoom.has(key)) {
      const rm = rooms.find((r) => r.id === key);
      groupedByRoom.set(key, {
        roomCode: b.room_code || rm?.code || '',
        roomName: b.room_name || rm?.name || key,
        deptName: b.department_name || '',
        floor: b.floor || rm?.floor || '',
        exclusive: Boolean(rm?.exclusive_locked),
        validation: roomValidationMap.get(key),
        beds: [],
      });
    }
    groupedByRoom.get(key)!.beds.push(b);
  }

  const handleBatchFixConflicts = async () => {
    setFixingConflicts(true);
    try {
      const res = await apiFetch<{ fixedConflicts: number; remainingConflicts: number; fixedRooms: string[] }>(
        '/beds/fix-conflicts',
        { method: 'POST' }
      );
      if (res.fixedConflicts > 0) {
        onNotify(
          `Đã sửa ${res.fixedConflicts} xung đột phòng/giường tại ${res.fixedRooms.join(', ')}. Còn lại: ${res.remainingConflicts}.`
        );
      } else {
        onNotify('Đã đồng bộ và kiểm tra toàn bộ trạng thái phòng/giường (không còn xung đột).');
      }
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    } finally {
      setFixingConflicts(false);
    }
  };

  const handleStatusChange = async (bed: Bed, status: 'VACANT' | 'MAINTENANCE' | 'INACTIVE') => {
    try {
      await apiFetch(`/beds/${bed.id}/status`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      onNotify(`Đã chuyển giường ${bed.code} sang trạng thái ${BED_STATUS_META[status].label}.`);
      setSelectedBed(null);
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  const handleAddBed = async (e: FormEvent) => {
    e.preventDefault();
    const rm = rooms.find((r) => r.id === newRoomId);
    if (!rm) return;
    try {
      await apiFetch('/beds', {
        method: 'POST',
        body: JSON.stringify({
          room_id: rm.id,
          department_id: rm.department_id,
          code: newCode,
          name: newName,
        }),
      });
      onNotify('Đã thêm giường mới.');
      setShowAddBed(false);
      setNewCode('');
      setNewName('');
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    }
  };

  const openBedcardPrint = (bed: Bed) => {
    setSelectedBed(null);
    setPrintingBed(bed);
  };

  return (
    <div className="space-y-6">
      <div className={`space-y-6 ${printingBed ? 'no-print-during-bedcard' : ''}`}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">Sơ đồ Giường bệnh trực quan</h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Hiển thị 8 trạng thái giường chuẩn theo từng phòng và khoa nội trú. Nhấn vào giường để xem lịch sử hoặc in phiếu đầu giường.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              aria-label="Lọc theo khoa"
              className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700"
            >
              <option value="">Tất cả khoa</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as BedStatus | '')}
              aria-label="Lọc theo trạng thái giường"
              className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700"
            >
              <option value="">Tất cả trạng thái</option>
              {ALL_STATUSES.map((s) => (
                <option key={s} value={s}>{BED_STATUS_META[s].label}</option>
              ))}
            </select>
            {canToggleMaintenance && (
              <button
                type="button"
                onClick={handleBatchFixConflicts}
                disabled={fixingConflicts}
                className={`flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                  totalConflictIssues > 0
                    ? 'border-amber-300 bg-amber-50 text-amber-900 hover:bg-amber-100'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Wrench className="h-3.5 w-3.5" />
                <span>
                  {fixingConflicts
                    ? 'Đang sửa...'
                    : totalConflictIssues > 0
                      ? `Sửa xung đột hàng loạt (${totalConflictRooms})`
                      : 'Sửa xung đột hàng loạt'}
                </span>
              </button>
            )}
            <button
              type="button"
              onClick={load}
              className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Tải lại</span>
            </button>
            {canManageStructure && (
              <button
                type="button"
                onClick={() => setShowAddBed((v) => !v)}
                className="flex items-center gap-1.5 rounded-md bg-sky-700 px-3.5 py-2 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap"
              >
                <Plus className="h-4 w-4" />
                <span>Thêm giường</span>
              </button>
            )}
          </div>
        </div>

        {/* Legend Bar */}
        <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 flex flex-wrap items-center gap-x-5 gap-y-2">
          {ALL_STATUSES.map((st) => {
            const cnt = beds.filter((b) => b.status === st && (!deptFilter || b.department_id === deptFilter)).length;
            return (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter((prev) => (prev === st ? '' : st))}
                className={`flex items-center gap-1.5 text-xs font-medium py-0.5 transition-opacity ${
                  statusFilter && statusFilter !== st ? 'opacity-45' : 'opacity-100'
                }`}
              >
                <BedStatusBadge status={st} compact />
                <span className="font-mono tabular-nums text-slate-500">({cnt})</span>
              </button>
            );
          })}
        </div>

        {showAddBed && canManageStructure && (
          <form onSubmit={handleAddBed} className="rounded-lg border border-slate-200 bg-white p-5 grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phòng *</label>
              <select value={newRoomId} onChange={(e) => setNewRoomId(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>{r.name} ({r.department_name})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Mã giường *</label>
              <input type="text" required value={newCode} onChange={(e) => setNewCode(e.target.value)} placeholder="VD: A101-G02" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Tên giường *</label>
              <input type="text" required value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="VD: Giường 02 - Phòng A101" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div className="flex gap-2">
              <button type="submit" className="rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800">Lưu giường</button>
              <button type="button" onClick={() => setShowAddBed(false)} className="rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-600">Hủy</button>
            </div>
          </form>
        )}

        {loading ? (
          <div className="h-64 rounded-lg border border-slate-200 bg-white animate-pulse" />
        ) : groupedByRoom.size === 0 ? (
          <div className="rounded-lg border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
            Không có giường nào phù hợp bộ lọc hiện tại.
          </div>
        ) : (
          <div className="space-y-4">
            {Array.from(groupedByRoom.entries()).map(([roomId, grp]) => {
              const validation = grp.validation;
              const occMeta = validation
                ? ROOM_OCCUPANCY_LABELS[validation.expectedOccupancyStatus]
                : ROOM_OCCUPANCY_LABELS.AVAILABLE;
              const hasConflict = Boolean(validation?.hasConflict);
              return (
                <div
                  key={roomId}
                  className={`rounded-lg border bg-white p-5 ${
                    hasConflict ? 'border-rose-300 ring-1 ring-rose-100' : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100">
                    <div className="flex flex-wrap items-center gap-2">
                      {hasConflict && (
                        <AlertTriangle
                          className="h-4 w-4 text-rose-600 shrink-0"
                          aria-label={`Cảnh báo xung đột trạng thái tại ${grp.roomCode || grp.roomName}`}
                        />
                      )}
                      <span className="text-base font-semibold text-slate-900">{grp.roomName}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-sm text-slate-600">{grp.deptName}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-xs text-slate-500">{grp.floor}</span>
                      {hasConflict && (
                        <span className="inline-flex items-center gap-1 rounded border border-rose-200 bg-rose-50 px-2 py-0.5 text-xs font-semibold text-rose-700">
                          Xung đột trạng thái (Conflicting Status)
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`rounded border px-2 py-0.5 text-xs font-semibold ${occMeta.cls}`}>
                        {occMeta.label}
                      </span>
                    </div>
                  </div>

                  {hasConflict && validation && (
                    <div className="mb-3 rounded-md border border-rose-200 bg-rose-50/70 px-3.5 py-2 text-xs text-rose-900 space-y-0.5">
                      {validation.conflicts.map((c, idx) => (
                        <div key={`${c.code}-${idx}`} className="flex items-center gap-1.5">
                          <AlertTriangle className="h-3.5 w-3.5 text-rose-600 shrink-0" />
                          <span>{c.message}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {grp.beds.map((b) => {
                      const meta = BED_STATUS_META[b.status];
                      const secondaryText = (() => {
                        if (b.patient_name) return { text: b.patient_name, strong: true };
                        if (b.is_exclusive_companion) {
                          return {
                            text: b.exclusive_holder_name
                              ? `Khóa bao phòng · ${b.exclusive_holder_name}`
                              : 'Khóa kèm theo phòng bao trọn',
                            strong: false,
                          };
                        }
                        if (b.status === 'RESERVED') {
                          return {
                            text: b.reservation_patient_name
                              ? `Giữ chỗ: ${b.reservation_patient_name}`
                              : b.notes || 'Đã khóa giữ chỗ',
                            strong: false,
                          };
                        }
                        if (b.status === 'PENDING_CONFIRMATION') return { text: 'Chờ xác nhận đồng thuận P2P', strong: false };
                        if (b.status === 'PENDING_CLEANING') return { text: 'Chờ vệ sinh khử khuẩn', strong: false };
                        if (b.status === 'CLEANING') return { text: 'Đang vệ sinh giường', strong: false };
                        if (b.status === 'MAINTENANCE') return { text: b.notes || 'Đang bảo trì kỹ thuật', strong: false };
                        if (b.status === 'INACTIVE') return { text: b.notes || 'Tạm ngừng hoạt động', strong: false };
                        return { text: b.notes || 'Sẵn sàng phục vụ', strong: false };
                      })();

                      return (
                        <button
                          key={b.id}
                          type="button"
                          onClick={() => openBedModal(b)}
                          className={`text-left rounded-lg border p-3.5 transition-colors hover:border-sky-500 ${meta.border} ${meta.bg}`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-sm font-bold text-slate-900">{b.code}</span>
                            <BedStatusBadge status={b.status} compact />
                          </div>
                          <div className="mt-2 text-xs text-slate-700 truncate">
                            <span className={secondaryText.strong ? 'font-medium text-slate-900' : 'text-slate-600'}>
                              {secondaryText.text}
                            </span>
                          </div>
                          {b.expected_discharge_at ? (
                            <div className="mt-1 text-[11px] font-mono tabular-nums text-slate-600">
                              Dự kiến trả: {formatDateVN(b.expected_discharge_at)}
                            </div>
                          ) : b.is_exclusive_companion && b.reservation_expires_at ? (
                            <div className="mt-1 text-[11px] font-mono tabular-nums text-amber-800">
                              Khóa đến: {formatDateVN(b.reservation_expires_at)}
                            </div>
                          ) : b.status === 'RESERVED' && b.reservation_expires_at ? (
                            <div className="mt-1 text-[11px] font-mono tabular-nums text-amber-800">
                              Hết giữ: {formatDateTimeVN(b.reservation_expires_at)}
                            </div>
                          ) : null}
                          {(b.bed_type_name || (b.daily_price ?? 0) > 0) && (
                            <div className="mt-1.5 pt-1.5 border-t border-slate-200/60 flex items-center justify-between gap-2 text-[11px] text-slate-500">
                              <span className="truncate">{b.bed_type_name || 'Tiêu chuẩn'}</span>
                              {(b.daily_price ?? 0) > 0 && (
                                <span className="font-mono tabular-nums font-semibold text-slate-700 shrink-0">
                                  {Number(b.daily_price).toLocaleString('vi-VN')}đ/ngày
                                </span>
                              )}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Selected Bed Drawer / Modal */}
      {selectedBed && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/45 p-4 no-print" role="dialog" aria-modal="true" aria-labelledby="bed-modal-title">
          <div className="w-full max-w-2xl rounded-lg border border-slate-200 bg-white p-6 space-y-4 shadow-lg max-h-[90vh] flex flex-col">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-mono text-slate-500">{selectedBed.department_name} · {selectedBed.room_name}</div>
                <h3 id="bed-modal-title" className="text-lg font-semibold text-slate-900 mt-0.5">Giường {selectedBed.code}</h3>
              </div>
              <BedStatusBadge status={selectedBed.status} />
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
              <button
                type="button"
                onClick={() => setModalTab('INFO')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  modalTab === 'INFO' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Thông tin &amp; Thao tác
              </button>
              <button
                type="button"
                onClick={() => loadBedHistory(selectedBed.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  modalTab === 'HISTORY' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <History className="h-3.5 w-3.5" />
                <span>Xem lịch sử giường</span>
              </button>
            </div>

            {modalTab === 'INFO' ? (
              <div className="space-y-4 overflow-y-auto">
                <div className="text-sm text-slate-600 space-y-1.5 border-t border-b border-slate-100 py-3">
                  <div>Tên giường: <span className="font-medium text-slate-900">{selectedBed.name}</span></div>
                  {selectedBed.patient_name && (
                    <>
                      <div>
                        Bệnh nhân hiện tại: <span className="font-semibold text-slate-900">{selectedBed.patient_name}</span>
                        {selectedBed.patient_code ? <span className="font-mono text-xs text-slate-500"> ({selectedBed.patient_code})</span> : null}
                      </div>
                      {selectedBed.diagnosis_group && (
                        <div>Chẩn đoán: <span className="font-medium text-slate-800">{selectedBed.diagnosis_group}</span></div>
                      )}
                      {selectedBed.confirmed_by_name && (
                        <div>BS/ĐD phụ trách: <span className="font-medium text-slate-800">{selectedBed.confirmed_by_name}</span></div>
                      )}
                    </>
                  )}
                  {selectedBed.is_exclusive_companion && (
                    <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                      Giường này đang bị khóa kèm do <strong>{selectedBed.room_name}</strong> đang được bao trọn
                      {selectedBed.exclusive_holder_name ? ` bởi bệnh nhân ${selectedBed.exclusive_holder_name}` : ''}. Không thể tiếp nhận bệnh nhân khác vào giường này cho tới khi kết thúc bao phòng.
                    </div>
                  )}
                  {!selectedBed.is_exclusive_companion && selectedBed.status === 'RESERVED' && selectedBed.reservation_patient_name && (
                    <div>
                      Đang giữ chỗ cho: <span className="font-semibold text-slate-900">{selectedBed.reservation_patient_name}</span>
                      {selectedBed.reservation_expires_at ? ` (đến ${formatDateTimeVN(selectedBed.reservation_expires_at)})` : ''}
                    </div>
                  )}
                  {selectedBed.expected_discharge_at && (
                    <div>Ngày trả dự kiến: <span className="font-mono">{formatDateVN(selectedBed.expected_discharge_at)}</span></div>
                  )}
                  {selectedBed.notes && <div>Ghi chú: {selectedBed.notes}</div>}
                </div>

                <div className="flex flex-wrap gap-2">
                  {selectedBed.status === 'VACANT' && (
                    <>
                      {roomValidationMap.get(selectedBed.room_id)?.isReservationBlocked ? (
                        <div className="w-full rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                          {roomValidationMap.get(selectedBed.room_id)?.blockReason}
                        </div>
                      ) : (
                        userRole !== 'EXECUTIVE' && (
                          <button
                            type="button"
                            onClick={() => { setSelectedBed(null); onNavigate('reservations'); }}
                            className="rounded-md bg-amber-600 px-3 py-2 text-xs font-medium text-white hover:bg-amber-700"
                          >
                            Giữ chỗ giường này
                          </button>
                        )
                      )}
                      {(userRole === 'SUPER_ADMIN' || userRole === 'ADMIN' || userRole === 'WARD_STAFF') && (
                        <button
                          type="button"
                          onClick={() => { setSelectedBed(null); onNavigate('admissions'); }}
                          className="rounded-md bg-sky-700 px-3 py-2 text-xs font-medium text-white hover:bg-sky-800"
                        >
                          Tiếp nhận bệnh nhân
                        </button>
                      )}
                      {canToggleMaintenance && (!userDeptId || userDeptId === selectedBed.department_id) && (
                        <button
                          type="button"
                          onClick={() => handleStatusChange(selectedBed, 'MAINTENANCE')}
                          className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700 hover:bg-rose-100"
                        >
                          Chuyển bảo trì
                        </button>
                      )}
                    </>
                  )}

                  {(selectedBed.status === 'MAINTENANCE' || selectedBed.status === 'INACTIVE') && canToggleMaintenance && (!userDeptId || userDeptId === selectedBed.department_id) && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(selectedBed, 'VACANT')}
                      className="rounded-md bg-emerald-700 px-3 py-2 text-xs font-medium text-white hover:bg-emerald-800"
                    >
                      Khôi phục về Trống
                    </button>
                  )}

                  {(selectedBed.status === 'PENDING_CLEANING' || selectedBed.status === 'CLEANING') && (
                    <button
                      type="button"
                      onClick={() => { setSelectedBed(null); onNavigate('cleaning'); }}
                      className="rounded-md bg-teal-700 px-3 py-2 text-xs font-medium text-white hover:bg-teal-800"
                    >
                      Mở hàng đợi vệ sinh
                    </button>
                  )}

                  {selectedBed.status === 'OCCUPIED' && (
                    <>
                      <button
                        type="button"
                        onClick={() => openBedcardPrint(selectedBed)}
                        className="flex items-center gap-1.5 rounded-md bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                      >
                        <Printer className="h-3.5 w-3.5" />
                        <span>In phiếu đầu giường</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => { setSelectedBed(null); onNavigate('inpatients'); }}
                        className="rounded-md bg-sky-700 px-3 py-2 text-xs font-medium text-white hover:bg-sky-800"
                      >
                        Quản lý lượt nằm
                      </button>
                    </>
                  )}

                  <button
                    type="button"
                    onClick={() => loadBedHistory(selectedBed.id)}
                    className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
                  >
                    <History className="h-3.5 w-3.5" />
                    <span>Xem lịch sử giường</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto border-t border-b border-slate-100 py-3 space-y-3">
                {historyLoading ? (
                  <div className="py-8 text-center text-sm text-slate-500">Đang tải lịch sử sử dụng giường...</div>
                ) : historyError ? (
                  <div className="rounded-md border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-sm text-rose-700">{historyError}</div>
                ) : historyItems.length === 0 ? (
                  <div className="py-8 text-center text-sm text-slate-500">
                    Giường {selectedBed.code} chưa ghi nhận lượt tiếp nhận nào trong lịch sử.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {historyItems.map((item) => {
                      const stMeta = ADMISSION_STATUS_LABELS[item.status] ?? ADMISSION_STATUS_LABELS.DISCHARGED;
                      return (
                        <div key={`${item.id}-${item.relation_type}`} className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5 space-y-1.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="text-sm font-semibold text-slate-900">
                              {item.patient_name}{' '}
                              <span className="font-mono text-xs font-normal text-slate-500">
                                ({item.patient_code} · {item.admission_code})
                              </span>
                            </div>
                            <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${stMeta.cls}`}>
                              {stMeta.label}
                            </span>
                          </div>
                          <div className="text-xs text-slate-600 flex flex-wrap gap-x-3 gap-y-1">
                            <span>Chẩn đoán: <strong className="text-slate-800">{item.diagnosis_group}</strong></span>
                            <span className="font-mono tabular-nums">Nhận: {formatDateTimeVN(item.bed_assigned_at)}</span>
                            <span className="font-mono tabular-nums">
                              {item.actual_discharge_at
                                ? `Trả/Chuyển: ${formatDateTimeVN(item.actual_discharge_at)}`
                                : `Dự kiến trả: ${formatDateTimeVN(item.expected_discharge_at)}`}
                            </span>
                            <span className="font-mono tabular-nums">Số ngày: {item.days_stayed}</span>
                          </div>
                          <div className="text-xs text-slate-500">
                            BS/ĐD phụ trách: {item.confirmed_by_name || '—'} · Gia hạn: {item.extension_count} lần
                            {item.transfer_note ? ` · ${item.transfer_note}` : ''}
                            {item.notes ? ` · Ghi chú: ${item.notes}` : ''}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setSelectedBed(null)}
                className="rounded-md border border-slate-300 px-4 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Bedcard Modal & CSS Print Media Sheet */}
      {printingBed && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 print:static print:inset-auto print:bg-white print:p-0 print:block"
          role="dialog"
          aria-modal="true"
          aria-label="Phiếu thông tin đầu giường"
        >
          <div className="w-full max-w-2xl rounded-xl bg-white p-6 space-y-5 shadow-xl print:shadow-none print:p-0 print:max-w-none">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 no-print">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Xem trước Phiếu đầu giường (Bedcard)</h3>
                <p className="text-xs text-slate-500">Định dạng tối ưu cho máy in A5 / A4 qua CSS Print Media Query.</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 rounded-md bg-sky-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-800"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>In phiếu (Print)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPrintingBed(null)}
                  className="rounded-md border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  Đóng
                </button>
              </div>
            </div>

            {/* Printer-friendly Bedcard */}
            <div className="bedcard-print-sheet rounded-lg border-2 border-slate-900 bg-white p-6 space-y-5 text-slate-900">
              <div className="flex items-start justify-between border-b-2 border-slate-900 pb-3">
                <div>
                  <div className="text-xs font-semibold tracking-wide text-slate-600">
                    BỆNH VIỆN ĐA KHOA · HỆ THỐNG QUẢN LÝ GIƯỜNG BỆNH BEDCARE
                  </div>
                  <h4 className="text-xl font-bold tracking-tight mt-1">
                    PHIẾU THÔNG TIN ĐẦU GIƯỜNG (BEDCARD)
                  </h4>
                </div>
                <div className="text-right">
                  <div className="font-mono text-2xl font-bold">{printingBed.code}</div>
                  <div className="text-xs text-slate-600">
                    {printingBed.room_name} · {printingBed.floor || 'Nội trú'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1.5">
                  <div className="text-xs font-semibold text-slate-500">THÔNG TIN BỆNH NHÂN</div>
                  <div className="text-lg font-bold">{printingBed.patient_name || '—'}</div>
                  <div>
                    Mã BN: <span className="font-mono font-semibold">{printingBed.patient_code || '—'}</span>
                    {printingBed.his_record_code ? (
                      <> · HIS: <span className="font-mono">{printingBed.his_record_code}</span></>
                    ) : null}
                  </div>
                  <div>
                    Mã hồ sơ: <span className="font-mono">{printingBed.admission_code || '—'}</span> · Ngày sinh:{' '}
                    <span className="font-mono">{printingBed.date_of_birth || '—'}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="text-xs font-semibold text-slate-500">KHOA ĐIỀU TRỊ &amp; THỜI GIAN</div>
                  <div className="font-semibold text-base">{printingBed.department_name}</div>
                  <div>
                    Nhận giường:{' '}
                    <span className="font-mono">
                      {printingBed.bed_assigned_at ? formatDateTimeVN(printingBed.bed_assigned_at) : '—'}
                    </span>
                  </div>
                  <div>
                    Dự kiến trả:{' '}
                    <span className="font-mono font-semibold">
                      {printingBed.expected_discharge_at ? formatDateVN(printingBed.expected_discharge_at) : '—'}
                    </span>
                    {printingBed.is_whole_room ? ' · (Bao trọn phòng)' : ''}
                  </div>
                </div>
              </div>

              <div className="rounded-md border border-slate-300 bg-slate-50/60 p-3.5 space-y-1">
                <div className="text-xs font-semibold text-slate-500">CHẨN ĐOÁN / NHÓM ĐIỀU TRỊ</div>
                <div className="text-base font-bold">{printingBed.diagnosis_group || 'Theo dõi nội trú'}</div>
                {(printingBed.admission_notes || printingBed.notes) && (
                  <div className="text-xs text-slate-700 pt-1">
                    Lưu ý chăm sóc: {printingBed.admission_notes || printingBed.notes}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 border-t border-slate-300 pt-3 text-sm">
                <div className="space-y-1">
                  <div className="text-xs font-semibold text-slate-500">Ê-KÍP ĐIỀU TRỊ &amp; CHĂM SÓC (CARE TEAM)</div>
                  <div>
                    Phụ trách chính:{' '}
                    <span className="font-semibold">{printingBed.confirmed_by_name || 'Bác sĩ / Điều dưỡng trực khoa'}</span>
                  </div>
                  <div className="text-xs text-slate-700">
                    Nhân sự khoa:{' '}
                    {printingBed.care_team && printingBed.care_team.length > 0
                      ? printingBed.care_team.join(', ')
                      : printingBed.confirmed_by_name || 'Điều dưỡng trực'}
                  </div>
                </div>
                <div className="space-y-1 text-right text-xs text-slate-600">
                  <div>In lúc: <span className="font-mono">{new Date().toLocaleString('vi-VN')}</span></div>
                  <div className="pt-4 font-semibold text-slate-800">Xác nhận Điều dưỡng trưởng khoa</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
