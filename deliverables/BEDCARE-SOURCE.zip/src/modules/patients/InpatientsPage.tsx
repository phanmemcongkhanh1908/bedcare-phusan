import { Activity, FileSpreadsheet, FileText, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { apiFetch } from '../../services/api';
import type { Admission, Department, VitalPoint } from '../../types/bedcare';
import { exportHandoverPdf, exportToCsv, type ExportColumn } from '../../utils/exportUtils';
import { formatDateTimeVN } from '../../utils/formatters';

interface EnrichedAdmission extends Admission {
  stay_metrics: {
    daysStayed: number;
    daysRemaining: number;
    hoursRemaining: number;
    dueState: 'ON_TIME' | 'DUE_SOON' | 'DUE_TODAY' | 'OVERDUE';
  };
}

interface InpatientsPageProps {
  globalSearch: string;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

const HANDOVER_COLUMNS: ExportColumn[] = [
  { header: 'Mã BN', key: 'patient_code', width: 14 },
  { header: 'Mã HS', key: 'admission_code', width: 16 },
  { header: 'Họ tên bệnh nhân', key: 'patient_name', width: 24 },
  { header: 'Khoa / Phòng / Giường', key: 'department_bed', width: 26 },
  { header: 'Chẩn đoán', key: 'diagnosis_group', width: 18 },
  { header: 'Sinh hiệu hiện tại', key: 'vitals_summary', width: 22 },
  { header: 'Nhận giường', key: 'bed_assigned_at', width: 18 },
  { header: 'Dự kiến trả', key: 'expected_discharge_at', width: 18 },
  { header: 'Số ngày / Còn lại', key: 'stay_summary', width: 18 },
  { header: 'Tình trạng', key: 'due_label', width: 16 },
  { header: 'BS/ĐD tiếp nhận', key: 'confirmed_by_name', width: 20 },
  { header: 'Ghi chú bàn giao', key: 'notes', width: 26 },
];

interface SparklineTooltipProps {
  active?: boolean;
  payload?: Array<{ payload?: VitalPoint }>;
}

function SparklineTooltip({ active, payload }: SparklineTooltipProps) {
  if (!active || !payload || payload.length === 0 || !payload[0]?.payload) return null;
  const pt = payload[0].payload;
  return (
    <div className="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] shadow-md text-slate-800 space-y-0.5">
      <div className="font-semibold text-slate-900">{pt.timeLabel}</div>
      <div className="font-mono tabular-nums text-sky-700">
        Huyết áp: {pt.systolicBp}/{pt.diastolicBp} mmHg
      </div>
      <div className="font-mono tabular-nums text-rose-700">
        Nhịp tim: {pt.heartRate} l/ph
      </div>
      <div className="font-mono tabular-nums text-slate-600">
        SpO2: {pt.spo2}% · {pt.temperature}°C
      </div>
    </div>
  );
}

export function InpatientsPage({ globalSearch, onNotify }: InpatientsPageProps) {
  const [admissions, setAdmissions] = useState<EnrichedAdmission[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [deptFilter, setDeptFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ACTIVE' | 'DISCHARGED' | 'ALL'>('ACTIVE');
  const [exportingPdf, setExportingPdf] = useState(false);
  const [detailPatient, setDetailPatient] = useState<EnrichedAdmission | null>(null);

  const load = async () => {
    try {
      const [adms, depts] = await Promise.all([
        apiFetch<EnrichedAdmission[]>('/admissions'),
        apiFetch<Department[]>('/departments'),
      ]);
      setAdmissions(adms);
      setDepartments(depts);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    if (!detailPatient) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setDetailPatient(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [detailPatient]);

  const filtered = admissions.filter((a) => {
    if (statusFilter !== 'ALL' && a.status !== statusFilter) return false;
    if (deptFilter && a.department_id !== deptFilter) return false;
    if (globalSearch.trim()) {
      const q = globalSearch.toLowerCase();
      const hay = `${a.admission_code} ${a.patient_code} ${a.patient_name} ${a.bed_code ?? ''} ${a.diagnosis_group}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const getDueStatusText = (a: EnrichedAdmission): string => {
    if (a.status === 'DISCHARGED') {
      return `Đã trả (${a.actual_discharge_at ? formatDateTimeVN(a.actual_discharge_at) : '—'})`;
    }
    switch (a.stay_metrics.dueState) {
      case 'OVERDUE':
        return 'Quá ngày trả';
      case 'DUE_TODAY':
        return 'Đến hạn hôm nay';
      case 'DUE_SOON':
        return 'Sắp trả giường';
      default:
        return 'Đúng tiến độ';
    }
  };

  const buildHandoverRows = () =>
    filtered.map((a) => {
      const m = a.stay_metrics;
      const v = a.vitals_24h;
      const remainText =
        a.status === 'DISCHARGED'
          ? 'Đã trả'
          : m.daysRemaining < 0
            ? `Quá ${Math.abs(m.daysRemaining)} ngày`
            : `Còn ${m.daysRemaining} ngày`;
      return {
        patient_code: a.patient_code,
        admission_code: a.admission_code,
        patient_name: a.patient_name,
        department_bed: `${a.department_name ?? ''} / ${a.bed_code ?? ''}${a.is_whole_room ? ' (Bao phòng)' : ''}`,
        diagnosis_group: a.diagnosis_group,
        vitals_summary: v
          ? `HA ${v.latestSystolicBp}/${v.latestDiastolicBp} · Mạch ${v.latestHeartRate} · SpO2 ${v.latestSpo2}%`
          : '—',
        bed_assigned_at: formatDateTimeVN(a.bed_assigned_at),
        expected_discharge_at: formatDateTimeVN(a.expected_discharge_at),
        stay_summary: `${m.daysStayed} ngày · ${remainText} (GH: ${a.extension_count})`,
        due_label: getDueStatusText(a),
        confirmed_by_name: a.confirmed_by_name || '—',
        notes: a.notes || '—',
      };
    });

  const getFilterSummary = () => {
    const deptName = deptFilter
      ? departments.find((d) => d.id === deptFilter)?.name || 'Khoa đã chọn'
      : 'Toàn viện';
    const statusName =
      statusFilter === 'ACTIVE' ? 'Đang nằm' : statusFilter === 'DISCHARGED' ? 'Đã trả giường' : 'Tất cả trạng thái';
    const searchPart = globalSearch.trim() ? ` · Từ khóa: "${globalSearch.trim()}"` : '';
    return `Phạm vi: ${deptName} · Trạng thái: ${statusName}${searchPart} · Tổng: ${filtered.length} bệnh nhân`;
  };

  const handleExportCsv = () => {
    if (filtered.length === 0) {
      onNotify('Không có bệnh nhân trong danh sách lọc hiện tại để xuất.', 'error');
      return;
    }
    const stamp = new Date().toISOString().slice(0, 10);
    exportToCsv(`bedcare-ban-giao-ca-${stamp}.csv`, HANDOVER_COLUMNS, buildHandoverRows());
    onNotify(`Đã xuất CSV bàn giao ca (${filtered.length} bệnh nhân).`);
  };

  const handleExportPdf = async () => {
    if (filtered.length === 0) {
      onNotify('Không có bệnh nhân trong danh sách lọc hiện tại để xuất.', 'error');
      return;
    }
    setExportingPdf(true);
    try {
      const stamp = new Date().toISOString().slice(0, 10);
      await exportHandoverPdf(
        `bedcare-ban-giao-ca-${stamp}.pdf`,
        getFilterSummary(),
        HANDOVER_COLUMNS,
        buildHandoverRows()
      );
      onNotify(`Đã xuất PDF bàn giao ca (${filtered.length} bệnh nhân).`);
    } catch (e) {
      onNotify(`Lỗi xuất PDF: ${(e as Error).message}`, 'error');
    } finally {
      setExportingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Bệnh nhân đang nằm &amp; Theo dõi sinh hiệu 24h</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Theo dõi diễn biến mạch, huyết áp 24 giờ gần nhất (Sparkline), ngày giường và xuất phiếu bàn giao ca.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            aria-label="Lọc theo khoa"
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
          >
            <option value="">Tất cả khoa</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {[
              { id: 'ACTIVE', label: 'Đang nằm' },
              { id: 'DISCHARGED', label: 'Đã trả giường' },
              { id: 'ALL', label: 'Tất cả' },
            ].map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setStatusFilter(s.id as typeof statusFilter)}
                className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                  statusFilter === s.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={handleExportCsv}
            disabled={filtered.length === 0}
            className="flex items-center gap-1.5 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 disabled:opacity-50 whitespace-nowrap"
          >
            <FileSpreadsheet className="h-3.5 w-3.5" />
            <span>Xuất CSV bàn giao</span>
          </button>
          <button
            type="button"
            onClick={handleExportPdf}
            disabled={filtered.length === 0 || exportingPdf}
            className="flex items-center gap-1.5 rounded-md bg-sky-700 px-3 py-2 text-xs font-semibold text-white hover:bg-sky-800 disabled:opacity-50 whitespace-nowrap"
          >
            <FileText className="h-3.5 w-3.5" />
            <span>{exportingPdf ? 'Đang tạo PDF...' : 'Xuất PDF bàn giao'}</span>
          </button>
        </div>
      </div>

      {/* Sparkline legend */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs text-slate-600">
        <div className="flex flex-wrap items-center gap-4">
          <span className="font-semibold text-slate-800">Chú giải biểu đồ Sparkline 24h:</span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block w-4 h-0.5 bg-sky-600" />
            <span>Huyết áp tâm thu (mmHg)</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block w-4 h-0.5 bg-rose-600" />
            <span>Nhịp tim (lần/phút)</span>
          </span>
        </div>
        <span className="text-slate-500">Di chuột vào đường biểu đồ để xem chỉ số từng mốc 3 giờ hoặc nhấn &ldquo;Chi tiết 24h&rdquo;</span>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-3 py-3 text-left font-medium">Bệnh nhân</th>
                <th className="px-3 py-3 text-left font-medium">Khoa / Giường</th>
                <th className="px-3 py-3 text-left font-medium">Sinh hiệu 24h (Mạch &amp; HA)</th>
                <th className="px-3 py-3 text-left font-medium">Nhập viện / Nhận giường</th>
                <th className="px-3 py-3 text-left font-medium">Dự kiến trả</th>
                <th className="px-3 py-3 text-right font-medium">Đã nằm / Còn lại</th>
                <th className="px-3 py-3 text-left font-medium">Tình trạng</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Không có hồ sơ bệnh nhân phù hợp.</td></tr>
              ) : filtered.map((a) => {
                const m = a.stay_metrics;
                const v = a.vitals_24h;
                const statusColor =
                  v?.clinicalStatus === 'CRITICAL'
                    ? 'text-rose-700'
                    : v?.clinicalStatus === 'WARNING'
                      ? 'text-amber-700'
                      : 'text-emerald-700';
                const statusText =
                  v?.clinicalStatus === 'CRITICAL'
                    ? 'Cảnh báo sát'
                    : v?.clinicalStatus === 'WARNING'
                      ? 'Cần lưu ý'
                      : 'Ổn định';

                return (
                  <tr key={a.id} className="hover:bg-slate-50 align-middle">
                    <td className="px-3 py-3">
                      <div className="font-semibold text-slate-900 leading-snug">{a.patient_name}</div>
                      <div className="font-mono text-xs text-slate-500">{a.patient_code} · {a.diagnosis_group}</div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="text-slate-800 whitespace-nowrap">{a.department_name}</div>
                      <div className="font-mono text-xs text-sky-700 font-medium whitespace-nowrap">{a.bed_code} {a.is_whole_room ? '(Bao phòng)' : ''}</div>
                    </td>
                    <td className="px-3 py-2.5">
                      {v ? (
                        <div className="flex items-center gap-2.5">
                          <div className="shrink-0" data-testid={`vitals-sparkline-${a.id}`}>
                            <LineChart width={116} height={40} data={v.points} margin={{ top: 4, right: 3, bottom: 4, left: 3 }}>
                              <YAxis hide domain={[50, 175]} />
                              <Tooltip content={<SparklineTooltip />} />
                              <Line
                                type="monotone"
                                dataKey="systolicBp"
                                stroke="#0284c7"
                                strokeWidth={1.75}
                                dot={false}
                                isAnimationActive={false}
                              />
                              <Line
                                type="monotone"
                                dataKey="heartRate"
                                stroke="#e11d48"
                                strokeWidth={1.75}
                                dot={false}
                                isAnimationActive={false}
                              />
                            </LineChart>
                          </div>
                          <div className="min-w-0 space-y-0.5">
                            <div className="font-mono tabular-nums text-xs text-slate-900 font-semibold whitespace-nowrap">
                              HA {v.latestSystolicBp}/{v.latestDiastolicBp} · M {v.latestHeartRate}
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] whitespace-nowrap">
                              <span className={`font-semibold ${statusColor}`}>{statusText}</span>
                              <span className="text-slate-300">·</span>
                              <button
                                type="button"
                                onClick={() => setDetailPatient(a)}
                                aria-label={`Xem chi tiết sinh hiệu 24h của ${a.patient_name}`}
                                className="inline-flex items-center gap-1 font-medium text-sky-700 hover:underline"
                              >
                                <Activity className="h-3 w-3" />
                                <span>Chi tiết 24h</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400">Chưa có dữ liệu sinh hiệu</span>
                      )}
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-slate-600 whitespace-nowrap">
                      <div>NV: {formatDateTimeVN(a.hospital_admitted_at)}</div>
                      <div>NG: {formatDateTimeVN(a.bed_assigned_at)}</div>
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-slate-700 whitespace-nowrap">{formatDateTimeVN(a.expected_discharge_at)}</td>
                    <td className="px-3 py-3 text-right font-mono tabular-nums whitespace-nowrap">
                      <div className="font-medium text-slate-900">{m.daysStayed} ngày (GH: {a.extension_count})</div>
                      <div className="text-xs font-semibold">
                        {a.status === 'DISCHARGED' ? (
                          <span className="text-slate-400">Đã trả</span>
                        ) : m.daysRemaining < 0 ? (
                          <span className="text-rose-700">Quá {Math.abs(m.daysRemaining)} ngày</span>
                        ) : (
                          <span className={m.dueState === 'DUE_SOON' || m.dueState === 'DUE_TODAY' ? 'text-amber-700' : 'text-emerald-700'}>
                            Còn {m.daysRemaining} ngày
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-3 text-xs whitespace-nowrap">
                      {a.actual_discharge_at ? (
                        <span className="font-mono text-slate-600">{formatDateTimeVN(a.actual_discharge_at)}</span>
                      ) : m.dueState === 'OVERDUE' ? (
                        <span className="font-semibold text-rose-700">Quá ngày trả</span>
                      ) : m.dueState === 'DUE_TODAY' ? (
                        <span className="font-semibold text-amber-700">Đến hạn hôm nay</span>
                      ) : m.dueState === 'DUE_SOON' ? (
                        <span className="font-semibold text-amber-600">Sắp trả giường</span>
                      ) : (
                        <span className="text-emerald-700 font-medium">Đúng tiến độ</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 24-Hour Clinical Vitals Detail Modal */}
      {detailPatient && detailPatient.vitals_24h && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 no-print"
          role="dialog"
          aria-modal="true"
          aria-labelledby="vitals-detail-title"
        >
          <div className="w-full max-w-3xl max-h-[88vh] flex flex-col rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 px-6 py-4 bg-slate-50/70">
              <div>
                <h3 id="vitals-detail-title" className="text-lg font-semibold text-slate-900">
                  Biểu đồ Sinh hiệu 24 giờ — {detailPatient.patient_name}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5 font-mono">
                  {detailPatient.patient_code} · Giường {detailPatient.bed_code} · {detailPatient.department_name} · {detailPatient.diagnosis_group}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDetailPatient(null)}
                aria-label="Đóng biểu đồ sinh hiệu"
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-200/70 hover:text-slate-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5">
              {/* Latest Vital Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-lg border border-slate-200 p-3">
                  <div className="text-xs text-slate-500">Huyết áp hiện tại</div>
                  <div className="mt-1 text-lg font-bold font-mono tabular-nums text-sky-700">
                    {detailPatient.vitals_24h.latestSystolicBp}/{detailPatient.vitals_24h.latestDiastolicBp}
                  </div>
                  <div className="text-[11px] text-slate-500">mmHg (24h: {detailPatient.vitals_24h.bpDelta >= 0 ? `+${detailPatient.vitals_24h.bpDelta}` : detailPatient.vitals_24h.bpDelta})</div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3">
                  <div className="text-xs text-slate-500">Nhịp tim</div>
                  <div className="mt-1 text-lg font-bold font-mono tabular-nums text-rose-700">
                    {detailPatient.vitals_24h.latestHeartRate} l/ph
                  </div>
                  <div className="text-[11px] text-slate-500">Biến thiên 24h: {detailPatient.vitals_24h.hrDelta >= 0 ? `+${detailPatient.vitals_24h.hrDelta}` : detailPatient.vitals_24h.hrDelta}</div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3">
                  <div className="text-xs text-slate-500">SpO2</div>
                  <div className="mt-1 text-lg font-bold font-mono tabular-nums text-emerald-700">
                    {detailPatient.vitals_24h.latestSpo2}%
                  </div>
                  <div className="text-[11px] text-slate-500">Độ bão hòa oxy</div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3">
                  <div className="text-xs text-slate-500">Nhiệt độ</div>
                  <div className="mt-1 text-lg font-bold font-mono tabular-nums text-slate-900">
                    {detailPatient.vitals_24h.latestTemp}°C
                  </div>
                  <div className="text-[11px] text-slate-500">Đo thân nhiệt</div>
                </div>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50/70 px-4 py-2.5 text-xs text-slate-700">
                <span className="font-semibold text-slate-900">Nhận định lâm sàng: </span>
                {detailPatient.vitals_24h.clinicalNote}
              </div>

              {/* Full Recharts 24h Chart */}
              <div className="rounded-lg border border-slate-200 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs">
                  <span className="font-semibold text-slate-800">Diễn biến mạch &amp; huyết áp trong 24 giờ qua</span>
                  <div className="flex items-center gap-4 text-slate-600">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="inline-block w-3 h-0.5 bg-sky-600" />
                      HA tâm thu
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="inline-block w-3 h-0.5 bg-teal-600" />
                      HA tâm trương
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="inline-block w-3 h-0.5 bg-rose-600" />
                      Nhịp tim
                    </span>
                  </div>
                </div>
                <div className="w-full h-[250px]">
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={detailPatient.vitals_24h.points} margin={{ top: 10, right: 16, left: 0, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="timeLabel" tick={{ fontSize: 11, fill: '#64748b' }} />
                      <YAxis domain={[55, 175]} tick={{ fontSize: 11, fill: '#64748b' }} />
                      <Tooltip content={<SparklineTooltip />} />
                      <ReferenceLine y={140} stroke="#f59e0b" strokeDasharray="4 4" />
                      <ReferenceLine y={100} stroke="#f43f5e" strokeDasharray="4 4" />
                      <Line type="monotone" dataKey="systolicBp" name="HA tâm thu" stroke="#0284c7" strokeWidth={2.2} dot={{ r: 3 }} isAnimationActive={false} />
                      <Line type="monotone" dataKey="diastolicBp" name="HA tâm trương" stroke="#0d9488" strokeWidth={1.8} dot={{ r: 2.5 }} isAnimationActive={false} />
                      <Line type="monotone" dataKey="heartRate" name="Nhịp tim" stroke="#e11d48" strokeWidth={2.2} dot={{ r: 3 }} isAnimationActive={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
