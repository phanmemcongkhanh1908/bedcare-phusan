import { DatabaseBackup, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ConfirmModal } from '../../components/ConfirmModal';
import { apiFetch } from '../../services/api';
import { formatDateTimeVN } from '../../utils/formatters';

interface BackupRecord {
  id: string;
  backup_name: string;
  device_id: string;
  app_version: string;
  schema_version: string;
  checksum_sha256: string;
  encrypted: number;
  record_count: number;
  status: 'SUCCESS' | 'FAILED' | 'RESTORED';
  file_path: string;
  created_by: string;
  created_at: string;
}

interface BackupRestorePageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function BackupRestorePage({ onNotify }: BackupRestorePageProps) {
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [creating, setCreating] = useState(false);
  const [restoreTarget, setRestoreTarget] = useState<BackupRecord | null>(null);
  const [restoring, setRestoring] = useState(false);

  const load = async () => {
    try {
      const data = await apiFetch<BackupRecord[]>('/backups');
      setBackups(data);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async () => {
    setCreating(true);
    try {
      const b = await apiFetch<{ backup_name: string; checksum_sha256: string }>('/backups', {
        method: 'POST',
      });
      onNotify(`Đã tạo bản sao lưu mã hóa AES-256-GCM: ${b.backup_name}`);
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleRestore = async () => {
    if (!restoreTarget) return;
    setRestoring(true);
    try {
      const res = await apiFetch<{ restored: boolean; reconciledEvents: number; checksumVerified: boolean }>(
        `/backups/${restoreTarget.id}/restore`,
        { method: 'POST' }
      );
      onNotify(
        `Khôi phục thành công (Checksum hợp lệ: ${res.checksumVerified ? 'Có' : 'Không'}). Đã đối chiếu đồng thuận +${res.reconciledEvents} sự kiện mới từ cụm P2P.`
      );
      setRestoreTarget(null);
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
      setRestoreTarget(null);
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Sao lưu &amp; Phục hồi dữ liệu cục bộ</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Bản sao lưu được mã hóa AES-256-GCM kèm SHA-256 checksum; quá trình phục hồi luôn đối chiếu giao dịch đồng thuận từ mạng P2P, không ghi đè mù.
          </p>
        </div>
        <button
          type="button"
          onClick={handleCreate}
          disabled={creating}
          className="flex items-center gap-1.5 rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 disabled:opacity-60 whitespace-nowrap"
        >
          <DatabaseBackup className="h-4 w-4" />
          <span>{creating ? 'Đang mã hóa sao lưu...' : 'Tạo bản sao lưu thủ công'}</span>
        </button>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-4 flex items-center gap-3 text-sm text-slate-700">
        <ShieldCheck className="h-5 w-5 text-teal-700 shrink-0" />
        <span>
          Quy trình khôi phục an toàn: Kiểm tra toàn vẹn SHA-256 -&gt; Giải mã AES-256-GCM -&gt; Khôi phục bảng cục bộ -&gt; Đối chiếu đồng thuận giao dịch mới nhất từ các máy tin cậy.
        </span>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Tên bản sao lưu</th>
                <th className="px-4 py-3 text-left font-medium">Thiết bị / Phiên bản</th>
                <th className="px-4 py-3 text-left font-medium">Checksum SHA-256</th>
                <th className="px-4 py-3 text-right font-medium">Số bản ghi</th>
                <th className="px-4 py-3 text-left font-medium">Trạng thái</th>
                <th className="px-4 py-3 text-left font-medium">Thời gian</th>
                <th className="px-4 py-3 text-right font-medium">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {backups.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Chưa có bản sao lưu nào trên máy trạm này.</td></tr>
              ) : backups.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">{b.backup_name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600">{b.device_id} · v{b.app_version} (DB {b.schema_version})</td>
                  <td className="px-4 py-3 font-mono text-[11px] text-slate-500 max-w-[180px] truncate">{b.checksum_sha256}</td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums">{b.record_count}</td>
                  <td className="px-4 py-3 text-xs font-semibold">
                    <span className={b.status === 'FAILED' ? 'text-rose-700' : b.status === 'RESTORED' ? 'text-sky-700' : 'text-emerald-700'}>
                      {b.status === 'SUCCESS' ? 'Hợp lệ (AES-256)' : b.status === 'RESTORED' ? 'Đã khôi phục' : 'Lỗi'}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-500">{formatDateTimeVN(b.created_at)}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      type="button"
                      onClick={() => setRestoreTarget(b)}
                      className="rounded-md border border-sky-200 bg-sky-50 px-3 py-1.5 text-xs font-medium text-sky-800 hover:bg-sky-100"
                    >
                      Khôi phục &amp; Đối chiếu
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ConfirmModal
        open={Boolean(restoreTarget)}
        title="Khôi phục dữ liệu từ bản sao lưu"
        description={`Khôi phục từ ${restoreTarget?.backup_name}? Hệ thống sẽ kiểm tra toàn vẹn SHA-256, giải mã AES-256-GCM và đối chiếu lại toàn bộ sự kiện đồng thuận mới hơn trên mạng P2P.`}
        confirmLabel="Bắt đầu khôi phục"
        busy={restoring}
        onConfirm={handleRestore}
        onCancel={() => setRestoreTarget(null)}
      />
    </div>
  );
}
