import { Lock, ShieldCheck, User } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import { apiFetch, setAuthToken } from '../../services/api';
import type { UserRole } from '../../types/bedcare';

interface LoginResponse {
  token: string;
  user: {
    id: string;
    username: string;
    full_name: string;
    role: UserRole;
    department_id: string | null;
  };
  activeNode: {
    deviceId: string;
    nodeName: string;
    isCoordinator: boolean;
  };
}

interface LoginScreenProps {
  onSuccess: (data: LoginResponse) => void;
}

const DEMO_ACCOUNTS = [
  { label: 'Admin (Mặc định)', username: 'admin', pass: 'admin', desc: 'Quyền cao nhất · Quản trị toàn hệ thống' },
  { label: 'Super Admin', username: 'superadmin', pass: 'Bedcare@2026', desc: 'Toàn quyền hệ thống & P2P' },
  { label: 'Thu viện phí', username: 'thuvienphi', pass: 'Vienphi@2026', desc: 'Đăng ký trước & giữ chỗ' },
  { label: 'Khoa Sản A', username: 'khoasana', pass: 'Khoasan@2026', desc: 'Tiếp nhận, gia hạn, trả giường' },
  { label: 'Lãnh đạo', username: 'lanhdao', pass: 'Lanhdao@2026', desc: 'Xem dashboard & báo cáo' },
];

export function LoginScreen({ onSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username.trim() || !password) {
      setError('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiFetch<LoginResponse>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username: username.trim(), password }),
      });
      setAuthToken(res.token);
      onSuccess(res);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-12">
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
        <div className="md:col-span-5 bg-sky-900 text-white p-8 flex flex-col justify-between">
          <div>
            <div className="text-xl font-bold tracking-tight">BEDCARE</div>
            <h1 className="mt-6 text-2xl font-semibold leading-snug text-balance">
              Quản lý Giường bệnh & Phòng bệnh Bệnh viện
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-sky-100">
              Vận hành theo kiến trúc Local-first Peer-to-Peer, lưu trữ SQLite độc lập trên từng máy trạm và đồng thuận phân tán chống cấp trùng giường.
            </p>
          </div>
          <div className="mt-8 pt-6 border-t border-sky-800 space-y-2 text-xs text-sky-200">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-teal-300 shrink-0" />
              <span>Chữ ký số Ed25519 &amp; đồng thuận Raft Quorum</span>
            </div>
            <div>Cơ sở dữ liệu cục bộ SQLite · Không phụ thuộc máy chủ cố định</div>
          </div>
        </div>

        <div className="md:col-span-7 p-8">
          <h2 className="text-lg font-semibold text-slate-900">Đăng nhập hệ thống</h2>
          <p className="mt-1 text-sm text-slate-500">
            Sử dụng tài khoản được cấp để truy cập máy trạm BEDCARE.
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {error && (
              <div role="alert" className="rounded-md border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-sm text-rose-700">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="login-username" className="block text-sm font-medium text-slate-700">
                Tên đăng nhập
              </label>
              <div className="mt-1.5 relative">
                <User className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="login-username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Nhập tên đăng nhập"
                  className="w-full rounded-md border border-slate-300 pl-9 pr-3 py-2 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="login-password" className="block text-sm font-medium text-slate-700">
                Mật khẩu
              </label>
              <div className="mt-1.5 relative">
                <Lock className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="login-password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Nhập mật khẩu"
                  className="w-full rounded-md border border-slate-300 pl-9 pr-3 py-2 text-sm text-slate-900 focus:border-sky-600 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-md bg-sky-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-800 transition-colors disabled:opacity-60"
            >
              {loading ? 'Đang xác thực...' : 'Đăng nhập'}
            </button>
          </form>

          <div className="mt-7 pt-5 border-t border-slate-200">
            <div className="text-xs font-medium text-slate-500 mb-2.5">
              Tài khoản mẫu theo phân quyền (chế độ kiểm thử demo):
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.username}
                  type="button"
                  onClick={() => {
                    setUsername(acc.username);
                    setPassword(acc.pass);
                    setError('');
                  }}
                  className="text-left rounded-md border border-slate-200 px-3 py-2 hover:border-sky-400 hover:bg-sky-50/50 transition-colors"
                >
                  <div className="text-xs font-semibold text-slate-800">{acc.label}</div>
                  <div className="text-[11px] text-slate-500 truncate">{acc.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
