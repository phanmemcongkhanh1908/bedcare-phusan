import { RefreshCw, Zap } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch } from '../../services/api';
import type { Bed, UserRole } from '../../types/bedcare';
import { formatDateTimeVN } from '../../utils/formatters';

interface RuntimeNodeInfo {
  deviceId: string;
  nodeName: string;
  online: boolean;
  revoked: boolean;
  isCoordinator: boolean;
  partitionGroup: string;
  lamportClock: number;
  term: number;
  eventCount: number;
  pendingSyncCount: number;
}

interface ClusterStatusResponse {
  activeNodeId: string;
  quorumRequired: number;
  runtimeNodes: RuntimeNodeInfo[];
  events: Array<Record<string, unknown>>;
  syncQueue: Array<Record<string, unknown>>;
  consensusLogs: Array<Record<string, unknown>>;
  conflicts: Array<Record<string, unknown>>;
  pendingRequests: Array<Record<string, unknown>>;
}

interface SyncConsensusPageProps {
  userRole: UserRole;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function SyncConsensusPage({ userRole, onNotify }: SyncConsensusPageProps) {
  const [data, setData] = useState<ClusterStatusResponse | null>(null);
  const [beds, setBeds] = useState<Bed[]>([]);
  const [raceBedId, setRaceBedId] = useState('');
  const [raceResult, setRaceResult] = useState<Array<{ nodeId: string; outcome: string; detail: string }> | null>(null);
  const [activeTab, setActiveTab] = useState<'consensus' | 'events' | 'queue' | 'conflicts' | 'pending'>('consensus');

  const isAdmin = userRole === 'SUPER_ADMIN' || userRole === 'ADMIN';

  const load = async () => {
    try {
      const [cl, bds] = await Promise.all([
        apiFetch<ClusterStatusResponse>('/cluster/status'),
        apiFetch<Bed[]>('/beds'),
      ]);
      setData(cl);
      const vacant = bds.filter((b) => b.status === 'VACANT');
      setBeds(vacant);
      if (!raceBedId && vacant.length > 0) setRaceBedId(vacant[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleToggleNode = async (n: RuntimeNodeInfo, patch: Partial<{ online: boolean; partitionGroup: string; isCoordinator: boolean }>) => {
    try {
      await apiFetch('/cluster/node-state', {
        method: 'POST',
        body: JSON.stringify({ deviceId: n.deviceId, ...patch }),
      });
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  const handleReconcile = async () => {
    try {
      const res = await apiFetch<{ syncedEvents: number; resolvedPending: number; rejectedConflicts: number }>('/cluster/reconcile', {
        method: 'POST',
      });
      onNotify(`Đồng bộ xong: +${res.syncedEvents} sự kiện, xử lý ${res.resolvedPending} yêu cầu chờ, từ chối xung đột ${res.rejectedConflicts}.`);
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  const handleSimulateRace = async () => {
    if (!raceBedId) return;
    try {
      const res = await apiFetch<{ bedCode: string; results: Array<{ nodeId: string; outcome: string; detail: string }> }>('/cluster/simulate-race', {
        method: 'POST',
        body: JSON.stringify({ bedId: raceBedId }),
      });
      setRaceResult(res.results);
      onNotify(`Đã chạy kiểm thử tranh chấp đồng thời trên giường ${res.bedCode}. Chỉ duy nhất 1 máy thắng khóa!`);
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  const handleResolveConflict = async (id: string) => {
    try {
      await apiFetch(`/cluster/conflicts/${id}/resolve`, {
        method: 'POST',
        body: JSON.stringify({ resolutionNote: 'Đã xác nhận giữ giao dịch thắng đồng thuận' }),
      });
      onNotify('Đã đánh dấu xử lý xung đột.');
      await load();
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  if (!data) return <div className="h-64 rounded-lg border border-slate-200 bg-white animate-pulse" />;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Đồng bộ P2P &amp; Đồng thuận Giao dịch</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Local-first Event Log + chữ ký Ed25519 + Quorum tối thiểu {data.quorumRequired} nút để xác nhận cấp giường (chống Last-Write-Wins).
          </p>
        </div>
        <button
          type="button"
          onClick={handleReconcile}
          className="flex items-center gap-1.5 rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap"
        >
          <RefreshCw className="h-4 w-4" />
          <span>Đồng bộ &amp; Đối chiếu cụm P2P</span>
        </button>
      </div>

      {/* Node Topology & Partition Controls */}
      <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-semibold text-slate-900">Cấu trúc cụm máy ngang hàng (SQLite độc lập)</h3>
          <span className="text-xs font-mono text-slate-500">Nút đang thao tác: {data.activeNodeId}</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.runtimeNodes.map((n) => (
            <div key={n.deviceId} className="rounded-lg border border-slate-200 p-4 space-y-2.5 bg-slate-50/50">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="font-mono text-xs font-bold text-slate-900">{n.deviceId}</div>
                  <div className="text-sm font-semibold text-slate-800">{n.nodeName}</div>
                </div>
                <span className={`text-xs font-semibold ${n.revoked ? 'text-rose-700' : n.online ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {n.revoked ? 'Thu hồi' : n.online ? 'Trực tuyến' : 'Ngoại tuyến'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs text-slate-600 pt-1">
                <div>Lamport: <span className="font-mono font-semibold text-slate-900">{n.lamportClock}</span></div>
                <div>Sự kiện: <span className="font-mono font-semibold text-slate-900">{n.eventCount}</span></div>
                <div>Hàng đợi: <span className="font-mono font-semibold text-amber-700">{n.pendingSyncCount}</span></div>
              </div>
              <div className="text-xs text-slate-500">
                Nhóm mạng: <span className="font-mono font-semibold text-slate-800">{n.partitionGroup}</span>
                {n.isCoordinator && <span className="ml-2 text-sky-700 font-semibold">· Leader (Term {n.term})</span>}
              </div>
              {isAdmin && !n.revoked && (
                <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => handleToggleNode(n, { online: !n.online })}
                    className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100"
                  >
                    {n.online ? 'Ngắt kết nối' : 'Kết nối lại'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleNode(n, { partitionGroup: n.partitionGroup === 'MAIN' ? 'ISOLATED_B' : 'MAIN' })}
                    className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100"
                  >
                    {n.partitionGroup === 'MAIN' ? 'Tách phân vùng B' : 'Gộp về MAIN'}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Live Multi-Node Race Condition Tester */}
      {isAdmin && (
        <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-slate-900">Kiểm thử tranh chấp cấp cùng một giường từ nhiều máy</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Phát lệnh tiếp nhận đồng thời trên cùng 1 giường trống từ các nút P2P để kiểm chứng chỉ 1 giao dịch thành công.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select value={raceBedId} onChange={(e) => setRaceBedId(e.target.value)} aria-label="Chọn giường kiểm thử" className="rounded-md border border-slate-300 px-3 py-1.5 text-sm">
                {beds.map((b) => (
                  <option key={b.id} value={b.id}>{b.code} ({b.department_name})</option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleSimulateRace}
                disabled={!raceBedId}
                className="flex items-center gap-1.5 rounded-md bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap"
              >
                <Zap className="h-3.5 w-3.5" />
                <span>Chạy kiểm thử đồng thời</span>
              </button>
            </div>
          </div>

          {raceResult && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-2">
              {raceResult.map((r) => (
                <div key={r.nodeId} className="rounded border border-slate-200 p-3 text-xs">
                  <div className="font-mono font-bold text-slate-900">{r.nodeId}</div>
                  <div className={`mt-1 font-semibold ${r.outcome === 'WON_COMMITTED' ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {r.outcome}
                  </div>
                  <div className="mt-0.5 text-slate-600">{r.detail}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Logs Tabs */}
      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex flex-wrap gap-1.5">
          {[
            { id: 'consensus', label: `Nhật ký đồng thuận (${data.consensusLogs.length})` },
            { id: 'events', label: `Nhật ký sự kiện (${data.events.length})` },
            { id: 'queue', label: `Hàng đợi đồng bộ (${data.syncQueue.length})` },
            { id: 'conflicts', label: `Xung đột (${data.conflicts.length})` },
            { id: 'pending', label: `Chờ xác nhận (${data.pendingRequests.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                activeTab === t.id ? 'bg-white text-sky-800 border border-slate-200 shadow-sm' : 'text-slate-600'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="overflow-x-auto">
          {activeTab === 'consensus' && (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Term / Leader</th>
                  <th className="px-4 py-2.5 text-left">Tài nguyên khóa</th>
                  <th className="px-4 py-2.5 text-left">Quorum</th>
                  <th className="px-4 py-2.5 text-left">Quyết định</th>
                  <th className="px-4 py-2.5 text-left">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.consensusLogs.map((c) => (
                  <tr key={String(c.id)}>
                    <td className="px-4 py-2.5 font-mono">T{String(c.term)} · {String(c.coordinator_id)}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-800">{String(c.resource_key)}</td>
                    <td className="px-4 py-2.5 font-mono tabular-nums">{String(c.quorum_achieved)}/{String(c.quorum_required)}</td>
                    <td className="px-4 py-2.5 font-semibold">
                      <span className={c.decision === 'COMMITTED' ? 'text-emerald-700' : c.decision === 'DEFERRED_NO_QUORUM' ? 'text-amber-700' : 'text-rose-700'}>
                        {String(c.decision)}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-slate-500">{formatDateTimeVN(String(c.created_at))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'events' && (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Lamport / Seq</th>
                  <th className="px-4 py-2.5 text-left">Loại sự kiện</th>
                  <th className="px-4 py-2.5 text-left">Thiết bị / Người thực hiện</th>
                  <th className="px-4 py-2.5 text-left">Đồng thuận</th>
                  <th className="px-4 py-2.5 text-left">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.events.map((ev) => (
                  <tr key={String(ev.event_id)}>
                    <td className="px-4 py-2.5 font-mono">L{String(ev.lamport_clock)} (#{String(ev.sequence_no)})</td>
                    <td className="px-4 py-2.5 font-semibold text-slate-900">{String(ev.event_type)}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-600">{String(ev.device_id)} · {String(ev.user_id)}</td>
                    <td className="px-4 py-2.5 text-emerald-700 font-semibold">{String(ev.consensus_status)}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-500">{formatDateTimeVN(String(ev.created_at))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'queue' && (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Event ID</th>
                  <th className="px-4 py-2.5 text-left">Máy đích</th>
                  <th className="px-4 py-2.5 text-left">Trạng thái</th>
                  <th className="px-4 py-2.5 text-left">Lý do</th>
                  <th className="px-4 py-2.5 text-left">Tạo lúc</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.syncQueue.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-6 text-center text-slate-500">Hàng đợi đồng bộ trống.</td></tr>
                ) : data.syncQueue.map((sq) => (
                  <tr key={String(sq.id)}>
                    <td className="px-4 py-2.5 font-mono">{String(sq.event_id)}</td>
                    <td className="px-4 py-2.5 font-mono font-semibold">{String(sq.target_device_id)}</td>
                    <td className="px-4 py-2.5 font-semibold">{String(sq.status)}</td>
                    <td className="px-4 py-2.5 text-slate-600">{String(sq.last_error)}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-500">{formatDateTimeVN(String(sq.created_at))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'conflicts' && (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Tài nguyên</th>
                  <th className="px-4 py-2.5 text-left">Máy thắng / Máy xung đột</th>
                  <th className="px-4 py-2.5 text-left">Nguyên nhân</th>
                  <th className="px-4 py-2.5 text-left">Trạng thái</th>
                  <th className="px-4 py-2.5 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.conflicts.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-6 text-center text-slate-500">Chưa ghi nhận xung đột dữ liệu nào.</td></tr>
                ) : data.conflicts.map((c) => (
                  <tr key={String(c.id)}>
                    <td className="px-4 py-2.5 font-mono">{String(c.resource_type)}:{String(c.resource_id)}</td>
                    <td className="px-4 py-2.5 font-mono">{String(c.winning_device_id || '—')} vs {String(c.conflicting_device_id)}</td>
                    <td className="px-4 py-2.5 text-rose-700">{String(c.reason)}</td>
                    <td className="px-4 py-2.5 font-semibold">{String(c.status)}</td>
                    <td className="px-4 py-2.5 text-right">
                      {c.status === 'OPEN' && isAdmin && (
                        <button type="button" onClick={() => handleResolveConflict(String(c.id))} className="text-sky-700 font-medium hover:underline">
                          Đánh dấu đã xử lý
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'pending' && (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Loại yêu cầu</th>
                  <th className="px-4 py-2.5 text-left">Mục tiêu</th>
                  <th className="px-4 py-2.5 text-left">Thiết bị gửi</th>
                  <th className="px-4 py-2.5 text-left">Trạng thái</th>
                  <th className="px-4 py-2.5 text-left">Ghi chú xung đột</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.pendingRequests.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-6 text-center text-slate-500">Không có yêu cầu nào đang chờ xác nhận.</td></tr>
                ) : data.pendingRequests.map((pr) => (
                  <tr key={String(pr.id)}>
                    <td className="px-4 py-2.5 font-semibold">{String(pr.request_type)}</td>
                    <td className="px-4 py-2.5 font-mono">{String(pr.target_id)}</td>
                    <td className="px-4 py-2.5 font-mono">{String(pr.device_id)}</td>
                    <td className="px-4 py-2.5 font-semibold text-amber-700">{String(pr.status)}</td>
                    <td className="px-4 py-2.5 text-slate-600">{String(pr.conflict_reason || '—')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
