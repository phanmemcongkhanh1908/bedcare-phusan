import { useEffect, useState, type FormEvent } from 'react';
import { apiFetch } from '../../services/api';
import type { Admission, Bed, Department, Room } from '../../types/bedcare';
import { formatDateTimeVN } from '../../utils/formatters';

interface TransfersPageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function TransfersPage({ onNotify }: TransfersPageProps) {
  const [admissions, setAdmissions] = useState<Admission[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [beds, setBeds] = useState<Bed[]>([]);
  const [transfers, setTransfers] = useState<Array<Record<string, unknown>>>([]);

  const [admId, setAdmId] = useState('');
  const [toDeptId, setToDeptId] = useState('');
  const [toRoomId, setToRoomId] = useState('');
  const [toBedId, setToBedId] = useState('');
  const [reason, setReason] = useState('');

  const load = async () => {
    try {
      const [adms, depts, rms, bds, trfs] = await Promise.all([
        apiFetch<Admission[]>('/admissions?status=ACTIVE'),
        apiFetch<Department[]>('/departments'),
        apiFetch<Room[]>('/rooms'),
        apiFetch<Bed[]>('/beds'),
        apiFetch<Array<Record<string, unknown>>>('/transfers'),
      ]);
      setAdmissions(adms);
      setDepartments(depts);
      setRooms(rms);
      setBeds(bds);
      setTransfers(trfs);
      if (!admId && adms.length > 0) setAdmId(adms[0].id);
      if (!toDeptId && depts.length > 0) setToDeptId(depts[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const targetRooms = rooms.filter((r) => r.department_id === toDeptId && r.status === 'ACTIVE' && !r.exclusive_locked);
  const targetBeds = beds.filter((b) => b.room_id === toRoomId && b.status === 'VACANT');

  const handleTransfer = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch(`/admissions/${admId}/transfer`, {
        method: 'POST',
        body: JSON.stringify({
          to_department_id: toDeptId,
          to_room_id: toRoomId,
          to_bed_id: toBedId,
          reason,
        }),
      });
      onNotify('Đã điều chuyển giường thành công. Giường cũ đã chuyển sang Chờ vệ sinh.');
      setReason('');
      setToBedId('');
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900">Điều chuyển giường bệnh</h2>
        <p className="text-sm text-slate-500 mt-0.5">
          Chuyển bệnh nhân sang giường/phòng/khoa mới qua đồng thuận P2P và tự động đưa giường cũ vào hàng đợi vệ sinh.
        </p>
      </div>

      <form onSubmit={handleTransfer} className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
        <h3 className="text-base font-semibold text-slate-900">Thực hiện điều chuyển</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Bệnh nhân hiện tại *</label>
            <select value={admId} onChange={(e) => setAdmId(e.target.value)} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
              {admissions.map((a) => (
                <option key={a.id} value={a.id}>{a.patient_name} ({a.bed_code})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Khoa đích *</label>
            <select value={toDeptId} onChange={(e) => { setToDeptId(e.target.value); setToRoomId(''); setToBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Phòng đích *</label>
            <select required value={toRoomId} onChange={(e) => { setToRoomId(e.target.value); setToBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
              <option value="">-- Chọn phòng --</option>
              {targetRooms.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Giường trống đích *</label>
            <select required value={toBedId} onChange={(e) => setToBedId(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
              <option value="">-- Chọn giường --</option>
              {targetBeds.map((b) => (
                <option key={b.id} value={b.id}>{b.code}</option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">Lý do điều chuyển *</label>
          <input type="text" required value={reason} onChange={(e) => setReason(e.target.value)} placeholder="VD: Yêu cầu nâng hạng phòng dịch vụ" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div className="flex justify-end">
          <button type="submit" disabled={admissions.length === 0} className="rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 disabled:opacity-50">
            Xác nhận điều chuyển
          </button>
        </div>
      </form>

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-200 font-semibold text-sm text-slate-900">
          Lịch sử điều chuyển ({transfers.length})
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-4 py-2.5 text-left font-medium">Bệnh nhân</th>
                <th className="px-4 py-2.5 text-left font-medium">Từ giường</th>
                <th className="px-4 py-2.5 text-left font-medium">Đến giường</th>
                <th className="px-4 py-2.5 text-left font-medium">Lý do</th>
                <th className="px-4 py-2.5 text-left font-medium">Người thực hiện</th>
                <th className="px-4 py-2.5 text-left font-medium">Thời gian</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transfers.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-6 text-center text-slate-500">Chưa có lượt điều chuyển nào.</td></tr>
              ) : transfers.map((t) => (
                <tr key={String(t.id)}>
                  <td className="px-4 py-2.5 font-medium text-slate-900">{String(t.patient_name)}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-600">{String(t.from_department_name)} · <span className="font-mono">{String(t.from_bed_code)}</span></td>
                  <td className="px-4 py-2.5 text-xs text-sky-800 font-medium">{String(t.to_department_name)} · <span className="font-mono">{String(t.to_bed_code)}</span></td>
                  <td className="px-4 py-2.5 text-slate-700">{String(t.reason)}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-600">{String(t.performed_by_name)}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{formatDateTimeVN(String(t.performed_at))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
