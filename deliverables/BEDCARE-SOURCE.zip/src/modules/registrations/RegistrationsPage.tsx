import { FileSpreadsheet, Upload } from 'lucide-react';
import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { apiFetch } from '../../services/api';
import type { Bed, Department, DiagnosisConfig, Registration, Room, RoomStandard } from '../../types/bedcare';
import { parseSpreadsheetFile } from '../../utils/exportUtils';
import { formatDateTimeVN, formatDateVN } from '../../utils/formatters';

interface RegistrationsPageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function RegistrationsPage({ onNotify }: RegistrationsPageProps) {
  const [tab, setTab] = useState<'form' | 'import' | 'list'>('form');
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [beds, setBeds] = useState<Bed[]>([]);
  const [standards, setStandards] = useState<RoomStandard[]>([]);
  const [diagnoses, setDiagnoses] = useState<DiagnosisConfig[]>([]);

  // Registration Form
  const [patientCode, setPatientCode] = useState('');
  const [hisCode, setHisCode] = useState('');
  const [patientName, setPatientName] = useState('');
  const [dob, setDob] = useState('1995-01-01');
  const [phone, setPhone] = useState('');
  const [diagGroup, setDiagGroup] = useState('Sinh thường');
  const [expectedAdmit, setExpectedAdmit] = useState(new Date().toISOString().slice(0, 16));
  const [desiredStds, setDesiredStds] = useState<string[]>([]);
  const [mode, setMode] = useState<'UNKNOWN_DEPT' | 'KNOWN_DEPT'>('UNKNOWN_DEPT');
  const [deptId, setDeptId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [bedId, setBedId] = useState('');
  const [holdType, setHoldType] = useState<'NONE' | 'WAITLIST' | 'SINGLE_BED' | 'WHOLE_ROOM'>('WAITLIST');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Excel/CSV Import Wizard
  const [importFileName, setImportFileName] = useState('');
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<Array<Record<string, string>>>([]);
  const [colMap, setColMap] = useState({
    patient_code: '',
    his_record_code: '',
    full_name: '',
    date_of_birth: '',
    phone: '',
    diagnosis_group: '',
  });
  const [importResult, setImportResult] = useState<{
    totalRows: number;
    importedRows: number;
    duplicateRows: number;
    errorRows: number;
  } | null>(null);
  const [importLogs, setImportLogs] = useState<Array<Record<string, unknown>>>([]);

  const load = async () => {
    try {
      const [regs, depts, rms, bds, stds, settingsRes, logs] = await Promise.all([
        apiFetch<Registration[]>('/registrations'),
        apiFetch<Department[]>('/departments'),
        apiFetch<Room[]>('/rooms'),
        apiFetch<Bed[]>('/beds'),
        apiFetch<RoomStandard[]>('/room-standards'),
        apiFetch<{ diagnoses: DiagnosisConfig[] }>('/settings'),
        apiFetch<Array<Record<string, unknown>>>('/import/logs'),
      ]);
      setRegistrations(regs);
      setDepartments(depts);
      setRooms(rms);
      setBeds(bds);
      setStandards(stds);
      setDiagnoses(settingsRes.diagnoses);
      setImportLogs(logs);
      if (!deptId && depts.length > 0) setDeptId(depts[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const matchingRooms = rooms.filter((r) => {
    if (r.department_id !== deptId || r.status !== 'ACTIVE' || r.exclusive_locked) return false;
    if (desiredStds.length > 0) {
      return desiredStds.every((s) => (r.standard_ids || []).includes(s));
    }
    return true;
  });

  const matchingVacantBeds = beds.filter(
    (b) => b.room_id === roomId && b.status === 'VACANT'
  );

  const wholeRoomEligible = (rId: string) => {
    const rBeds = beds.filter((b) => b.room_id === rId && b.status !== 'INACTIVE');
    return rBeds.length > 0 && rBeds.every((b) => b.status === 'VACANT');
  };

  const handleSubmitReg = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ registration_code: string; pendingConfirmation: boolean }>('/registrations', {
        method: 'POST',
        body: JSON.stringify({
          patient_code: patientCode,
          his_record_code: hisCode,
          patient_name: patientName,
          date_of_birth: dob,
          phone,
          diagnosis_group: diagGroup,
          expected_admission_date: new Date(expectedAdmit).toISOString(),
          desired_standard_ids: desiredStds,
          registration_mode: mode,
          department_id: mode === 'KNOWN_DEPT' ? deptId : null,
          room_id: mode === 'KNOWN_DEPT' ? roomId || null : null,
          bed_id: mode === 'KNOWN_DEPT' && holdType === 'SINGLE_BED' ? bedId || null : null,
          reservation_type: mode === 'UNKNOWN_DEPT' ? 'WAITLIST' : holdType,
          notes,
        }),
      });
      onNotify(
        res.pendingConfirmation
          ? `Đã tạo hồ sơ ${res.registration_code} ở trạng thái Chờ xác nhận do mạng P2P chưa đủ quorum.`
          : `Đã tạo hồ sơ đăng ký trước ${res.registration_code}.`
      );
      setPatientCode('');
      setHisCode('');
      setPatientName('');
      setPhone('');
      setNotes('');
      await load();
      setTab('list');
    } catch (err) {
      onNotify((err as Error).message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleFilePick = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { headers, rows } = await parseSpreadsheetFile(file);
      setImportFileName(file.name);
      setRawHeaders(headers);
      setRawRows(rows);
      setImportResult(null);
      const guess = (keywords: string[]) =>
        headers.find((h) => keywords.some((k) => h.toLowerCase().includes(k))) || '';
      setColMap({
        patient_code: guess(['mã bn', 'patient_code', 'mabn', 'mã bệnh nhân']),
        his_record_code: guess(['his', 'hồ sơ']),
        full_name: guess(['họ tên', 'tên', 'full_name', 'hoten']),
        date_of_birth: guess(['ngày sinh', 'dob', 'ngaysinh']),
        phone: guess(['điện thoại', 'sđt', 'phone', 'sdt']),
        diagnosis_group: guess(['chẩn đoán', 'diagnosis', 'nhóm']),
      });
    } catch (err) {
      onNotify('Không đọc được file Excel/CSV: ' + (err as Error).message, 'error');
    }
  };

  const handleConfirmImport = async () => {
    if (!colMap.patient_code || !colMap.full_name || !colMap.date_of_birth) {
      onNotify('Vui lòng ghép tối thiểu 3 cột: Mã BN, Họ tên và Ngày sinh.', 'error');
      return;
    }
    const mapped = rawRows.map((r) => ({
      patient_code: r[colMap.patient_code] || '',
      his_record_code: colMap.his_record_code ? r[colMap.his_record_code] || '' : '',
      full_name: r[colMap.full_name] || '',
      date_of_birth: r[colMap.date_of_birth] || '',
      phone: colMap.phone ? r[colMap.phone] || '' : '',
      diagnosis_group: colMap.diagnosis_group ? r[colMap.diagnosis_group] || 'Khác' : 'Khác',
    }));

    try {
      const res = await apiFetch<{
        totalRows: number;
        importedRows: number;
        duplicateRows: number;
        errorRows: number;
      }>('/import/patients', {
        method: 'POST',
        body: JSON.stringify({ fileName: importFileName, rows: mapped }),
      });
      setImportResult(res);
      onNotify(`Đã nhập ${res.importedRows}/${res.totalRows} bệnh nhân (trùng mã: ${res.duplicateRows}, lỗi: ${res.errorRows}).`);
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Đăng ký trước giường &amp; Nhận diện HIS</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Hỗ trợ đăng ký chưa biết khoa (chờ phân bổ), đã biết khoa (giữ giường/bao trọn phòng thủ công) và nhập Excel/CSV.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
          {[
            { id: 'form', label: 'Tạo đăng ký mới' },
            { id: 'import', label: 'Nhập Excel / CSV' },
            { id: 'list', label: `Danh sách (${registrations.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as typeof tab)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                tab === t.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'form' && (
        <form onSubmit={handleSubmitReg} className="rounded-lg border border-slate-200 bg-white p-6 space-y-6">
          <div>
            <h3 className="text-base font-semibold text-slate-900 mb-3">1. Thông tin bệnh nhân</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Mã bệnh nhân *</label>
                <input type="text" required value={patientCode} onChange={(e) => setPatientCode(e.target.value)} placeholder="VD: BN-2026-101" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Mã hồ sơ HIS (nếu có)</label>
                <input type="text" value={hisCode} onChange={(e) => setHisCode(e.target.value)} placeholder="VD: HIS-88123" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Họ và tên *</label>
                <input type="text" required value={patientName} onChange={(e) => setPatientName(e.target.value)} placeholder="Nguyễn Thị B" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Ngày sinh *</label>
                <input type="date" required value={dob} onChange={(e) => setDob(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Số điện thoại</label>
                <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="090xxxxxxx" className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Nhóm chẩn đoán dự kiến *</label>
                <select value={diagGroup} onChange={(e) => setDiagGroup(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                  {diagnoses.map((d) => (
                    <option key={d.id} value={d.name}>{d.name} (dự kiến {d.default_days} ngày)</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Ngày giờ dự kiến nhập viện *</label>
                <input type="datetime-local" required value={expectedAdmit} onChange={(e) => setExpectedAdmit(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">Ghi chú chuyên môn / hành chính</label>
                <input type="text" value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-base font-semibold text-slate-900 mb-2">2. Tiêu chuẩn phòng mong muốn</h3>
            <div className="flex flex-wrap gap-2">
              {standards.map((s) => {
                const active = desiredStds.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setDesiredStds((p) => (p.includes(s.id) ? p.filter((x) => x !== s.id) : [...p, s.id]))}
                    className={`rounded-md border px-3 py-1.5 text-xs font-medium ${
                      active ? 'border-sky-600 bg-sky-50 text-sky-800' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {s.name}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 space-y-4">
            <h3 className="text-base font-semibold text-slate-900">3. Hình thức đăng ký &amp; Giữ chỗ thủ công</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => { setMode('UNKNOWN_DEPT'); setHoldType('WAITLIST'); }}
                className={`text-left rounded-lg border p-4 ${
                  mode === 'UNKNOWN_DEPT' ? 'border-sky-600 bg-sky-50/70' : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="text-sm font-semibold text-slate-900">Hình thức A: Chưa biết khoa</div>
                <div className="text-xs text-slate-600 mt-1">
                  Chỉ ghi nhận nhu cầu tiêu chuẩn phòng và đưa vào danh sách chờ phân bổ (không tự động cấp giường vật lý).
                </div>
              </button>

              <button
                type="button"
                onClick={() => { setMode('KNOWN_DEPT'); setHoldType('NONE'); }}
                className={`text-left rounded-lg border p-4 ${
                  mode === 'KNOWN_DEPT' ? 'border-sky-600 bg-sky-50/70' : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="text-sm font-semibold text-slate-900">Hình thức B: Đã biết khoa</div>
                <div className="text-xs text-slate-600 mt-1">
                  Hiển thị các phòng &amp; giường phù hợp đang trống; tùy chọn không giữ chỗ, giữ 1 giường hoặc bao trọn phòng.
                </div>
              </button>
            </div>

            {mode === 'KNOWN_DEPT' && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Khoa mong muốn</label>
                  <select value={deptId} onChange={(e) => { setDeptId(e.target.value); setRoomId(''); setBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Thao tác giữ chỗ thủ công</label>
                  <select value={holdType} onChange={(e) => setHoldType(e.target.value as typeof holdType)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                    <option value="NONE">Không giữ chỗ</option>
                    <option value="WAITLIST">Đưa vào danh sách chờ</option>
                    <option value="SINGLE_BED">Giữ một giường cụ thể</option>
                    <option value="WHOLE_ROOM">Giữ trọn phòng (Bao phòng)</option>
                  </select>
                </div>
                {(holdType === 'SINGLE_BED' || holdType === 'WHOLE_ROOM') && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Chọn phòng phù hợp</label>
                    <select value={roomId} onChange={(e) => { setRoomId(e.target.value); setBedId(''); }} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                      <option value="">-- Chọn phòng ({matchingRooms.length}) --</option>
                      {matchingRooms
                        .filter((r) => (holdType === 'WHOLE_ROOM' ? wholeRoomEligible(r.id) : true))
                        .map((r) => (
                          <option key={r.id} value={r.id}>{r.name} ({r.capacity} giường)</option>
                        ))}
                    </select>
                  </div>
                )}
                {holdType === 'SINGLE_BED' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Chọn giường trống</label>
                    <select value={bedId} onChange={(e) => setBedId(e.target.value)} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                      <option value="">-- Chọn giường ({matchingVacantBeds.length}) --</option>
                      {matchingVacantBeds.map((b) => (
                        <option key={b.id} value={b.id}>{b.code}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-100">
            <button
              type="submit"
              disabled={submitting}
              className="rounded-md bg-sky-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-sky-800 disabled:opacity-60"
            >
              {submitting ? 'Đang xử lý đồng thuận...' : 'Lưu hồ sơ đăng ký trước'}
            </button>
          </div>
        </form>
      )}

      {tab === 'import' && (
        <div className="space-y-6">
          <div className="rounded-lg border border-slate-200 bg-white p-6 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Nhập danh sách bệnh nhân từ Excel / CSV</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Kiểm tra lỗi từng dòng, phát hiện trùng mã bệnh nhân / mã HIS (không gộp tự động theo họ tên) và lưu nhật ký nhập.
                </p>
              </div>
              <label className="cursor-pointer inline-flex items-center gap-2 rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap">
                <Upload className="h-4 w-4" />
                <span>Chọn file .xlsx / .csv</span>
                <input type="file" accept=".xlsx,.csv" onChange={handleFilePick} className="hidden" />
              </label>
            </div>

            {rawHeaders.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
                  <span>File: {importFileName} ({rawRows.length} dòng dữ liệu)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  {[
                    { key: 'patient_code', label: 'Mã bệnh nhân *' },
                    { key: 'his_record_code', label: 'Mã hồ sơ HIS' },
                    { key: 'full_name', label: 'Họ tên *' },
                    { key: 'date_of_birth', label: 'Ngày sinh *' },
                    { key: 'phone', label: 'Số điện thoại' },
                    { key: 'diagnosis_group', label: 'Chẩn đoán' },
                  ].map((field) => (
                    <div key={field.key}>
                      <label className="block text-xs font-medium text-slate-600 mb-1">{field.label}</label>
                      <select
                        value={colMap[field.key as keyof typeof colMap]}
                        onChange={(e) => setColMap({ ...colMap, [field.key]: e.target.value })}
                        className="w-full rounded-md border border-slate-300 px-2.5 py-1.5 text-xs"
                      >
                        <option value="">-- Không ghép --</option>
                        {rawHeaders.map((h) => (
                          <option key={h} value={h}>{h}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-md">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <tr>
                        <th className="px-3 py-2 text-left">#</th>
                        {rawHeaders.map((h) => (
                          <th key={h} className="px-3 py-2 text-left font-medium">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rawRows.slice(0, 8).map((r, idx) => (
                        <tr key={idx}>
                          <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                          {rawHeaders.map((h) => (
                            <td key={h} className="px-3 py-2 text-slate-700">{r[h]}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex items-center justify-between">
                  {importResult ? (
                    <div className="text-sm text-slate-700">
                      Kết quả: <span className="font-semibold text-emerald-700">{importResult.importedRows} thành công</span> ·{' '}
                      <span className="font-semibold text-amber-700">{importResult.duplicateRows} trùng mã</span> ·{' '}
                      <span className="font-semibold text-rose-700">{importResult.errorRows} dòng lỗi</span>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-500">Xem trước tối đa 8 dòng đầu trước khi xác nhận nhập.</span>
                  )}
                  <button
                    type="button"
                    onClick={handleConfirmImport}
                    className="rounded-md bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800"
                  >
                    Xác nhận nhập dữ liệu
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 font-semibold text-sm text-slate-900">
              Nhật ký nhập file Excel / CSV
            </div>
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Tên file</th>
                  <th className="px-4 py-2.5 text-right">Tổng dòng</th>
                  <th className="px-4 py-2.5 text-right">Đã nhập</th>
                  <th className="px-4 py-2.5 text-right">Trùng mã</th>
                  <th className="px-4 py-2.5 text-right">Lỗi</th>
                  <th className="px-4 py-2.5 text-left">Người nhập</th>
                  <th className="px-4 py-2.5 text-left">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {importLogs.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-6 text-center text-slate-500">Chưa có lần nhập file nào.</td></tr>
                ) : importLogs.map((l) => (
                  <tr key={String(l.id)}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{String(l.file_name)}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{String(l.total_rows)}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-emerald-700">{String(l.imported_rows)}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-amber-700">{String(l.duplicate_rows)}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-rose-700">{String(l.error_rows)}</td>
                    <td className="px-4 py-2.5 text-slate-600">{String(l.performed_by)}</td>
                    <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{formatDateTimeVN(String(l.created_at))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'list' && (
        <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Mã ĐK / BN</th>
                  <th className="px-4 py-3 text-left font-medium">Họ tên</th>
                  <th className="px-4 py-3 text-left font-medium">Chẩn đoán</th>
                  <th className="px-4 py-3 text-left font-medium">Hình thức</th>
                  <th className="px-4 py-3 text-left font-medium">Khoa / Giường</th>
                  <th className="px-4 py-3 text-left font-medium">Trạng thái</th>
                  <th className="px-4 py-3 text-left font-medium">Dự kiến nhập</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {registrations.map((reg) => (
                  <tr key={reg.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <div className="font-mono text-xs font-semibold text-slate-900">{reg.registration_code}</div>
                      <div className="font-mono text-xs text-slate-500">{reg.patient_code}</div>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">{reg.patient_name}</td>
                    <td className="px-4 py-3 text-slate-600">{reg.diagnosis_group}</td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      {reg.registration_mode === 'UNKNOWN_DEPT' ? 'Chưa biết khoa' : 'Đã biết khoa'}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-700">
                      {reg.department_name || 'Chờ phân bổ'} {reg.bed_code ? `· ${reg.bed_code}` : reg.room_name ? `· ${reg.room_name}` : ''}
                    </td>
                    <td className="px-4 py-3 text-xs font-semibold">
                      <span className={reg.status === 'RESERVED' ? 'text-amber-700' : reg.status === 'ADMITTED' ? 'text-sky-700' : 'text-slate-700'}>
                        {reg.status === 'WAITING' ? 'Đang chờ' : reg.status === 'RESERVED' ? 'Đã giữ chỗ' : reg.status === 'ADMITTED' ? 'Đã nhập khoa' : reg.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-slate-500">{formatDateVN(reg.expected_admission_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
