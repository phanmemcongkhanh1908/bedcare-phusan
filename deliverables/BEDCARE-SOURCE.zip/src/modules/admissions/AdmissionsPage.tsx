import { useEffect, useState, type FormEvent } from 'react';
import { apiFetch } from '../../services/api';
import type { Bed, Department, DiagnosisConfig, Registration, Reservation, Room } from '../../types/bedcare';

interface AdmissionsPageProps {
  userDeptId?: string | null;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function AdmissionsPage({ userDeptId, onNotify }: AdmissionsPageProps) {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [beds, setBeds] = useState<Bed[]>([]);
  const [diagnoses, setDiagnoses] = useState<DiagnosisConfig[]>([]);

  const [selectedRegId, setSelectedRegId] = useState('');
  const [selectedResId, setSelectedResId] = useState('');
  const [patientCode, setPatientCode] = useState('');
  const [hisCode, setHisCode] = useState('');
  const [patientName, setPatientName] = useState('');
  const [dob, setDob] = useState('1994-01-01');
  const [phone, setPhone] = useState('');
  const [diagGroup, setDiagGroup] = useState('Sinh thường');
  const [deptId, setDeptId] = useState(userDeptId || '');
  const [roomId, setRoomId] = useState('');
  const [bedId, setBedId] = useState('');
  const [isWholeRoom, setIsWholeRoom] = useState(false);
  const [expectedDischarge, setExpectedDischarge] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    try {
      const [regs, rsvs, depts, rms, bds, cfg] = await Promise.all([
        apiFetch<Registration[]>('/registrations'),
        apiFetch<Reservation[]>('/reservations'),
        apiFetch<Department[]>('/departments'),
        apiFetch<Room[]>('/rooms'),
        apiFetch<Bed[]>('/beds'),
        apiFetch<{ diagnoses: DiagnosisConfig[] }>('/settings'),
      ]);
      setRegistrations(regs.filter((r) => r.status === 'WAITING' || r.status === 'RESERVED'));
      setReservations(rsvs.filter((r) => r.status === 'ACTIVE'));
      setDepartments(depts);
      setRooms(rms);
      setBeds(bds);
      setDiagnoses(cfg.diagnoses);
      if (!deptId && depts.length > 0) setDeptId(userDeptId || depts[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const pickRegistration = (reg: Registration) => {
    setSelectedRegId(reg.id);
    setPatientCode(reg.patient_code);
    setHisCode(reg.his_record_code || '');
    setPatientName(reg.patient_name);
    setDob(reg.date_of_birth);
    setPhone(reg.phone || '');
    setDiagGroup(reg.diagnosis_group);
    if (reg.department_id) setDeptId(reg.department_id);
    if (reg.room_id) setRoomId(reg.room_id);
    if (reg.bed_id) setBedId(reg.bed_id);
    const matchedRes = reservations.find((r) => r.registration_id === reg.id);
    if (matchedRes) {
      setSelectedResId(matchedRes.id);
      setIsWholeRoom(Boolean(matchedRes.is_whole_room));
      if (matchedRes.is_whole_room && matchedRes.locked_bed_ids.length > 0) {
        setBedId(matchedRes.locked_bed_ids[0]);
      }
    } else {
      setSelectedResId('');
      setIsWholeRoom(false);
    }
  };

  const allowedDepts = userDeptId ? departments.filter((d) => d.id === userDeptId) : departments;
  const deptRooms = rooms.filter((r) => r.department_id === deptId && r.status === 'ACTIVE');
  const selectableBeds = beds.filter((b) => {
    if (b.room_id !== roomId) return false;
    if (b.status === 'VACANT') return true;
    if (b.status === 'RESERVED' && selectedResId && b.current_reservation_id === selectedResId) return true;
    return false;
  });

  const handleConfirm = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ admission_code: string; pendingConfirmation: boolean }>('/admissions/confirm', {
        method: 'POST',
        body: JSON.stringify({
          registration_id: selectedRegId || undefined,
          reservation_id: selectedResId || undefined,
          patient_code: patientCode,
          his_record_code: hisCode,
          patient_name: patientName,
          date_of_birth: dob,
          phone,
          diagnosis_group: diagGroup,
          department_id: deptId,
          room_id: roomId,
          bed_id: bedId,
          is_whole_room: isWholeRoom,
          expected_discharge_at: expectedDischarge ? new Date(expectedDischarge).toISOString() : undefined,
          notes,
        }),
      });
      onNotify(
        res.pendingConfirmation
          ? `Hồ sơ ${res.admission_code} đang Chờ xác nhận đồng thuận do mạng phân vùng.`
          : `Đã tiếp nhận bệnh nhân (${res.admission_code}) vào giường thành công.`
      );
      setSelectedRegId('');
      setSelectedResId('');
      setPatientCode('');
      setHisCode('');
      setPatientName('');
      setPhone('');
      setNotes('');
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900">Tiếp nhận vào khoa &amp; Cấp giường</h2>
        <p className="text-sm text-slate-500 mt-0.5">
          Chọn hồ sơ đăng ký trước hoặc nhập tiếp nhận trực tiếp, kiểm tra đồng thuận P2P trước khi cấp giường chính thức.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-lg border border-slate-200 bg-white overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 font-semibold text-sm text-slate-900">
            Hồ sơ đăng ký chờ tiếp nhận ({registrations.length})
          </div>
          <div className="divide-y divide-slate-100 max-h-[540px] overflow-y-auto">
            {registrations.length === 0 ? (
              <div className="p-6 text-sm text-slate-500">Chưa có hồ sơ đăng ký trước đang chờ.</div>
            ) : (
              registrations.map((reg) => (
                <button
                  key={reg.id}
                  type="button"
                  onClick={() => pickRegistration(reg)}
                  className={`w-full text-left px-4 py-3 hover:bg-sky-50/50 transition-colors ${
                    selectedRegId === reg.id ? 'bg-sky-50' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm text-slate-900">{reg.patient_name}</span>
                    <span className="font-mono text-xs text-sky-700">{reg.registration_code}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {reg.patient_code} · {reg.diagnosis_group}
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {reg.department_name || 'Chưa chọn khoa'} {reg.bed_code ? `· Đã giữ ${reg.bed_code}` : ''}
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        <form onSubmit={handleConfirm} className="lg:col-span-7 rounded-lg border border-slate-200 bg-white p-6 space-y-4">
          <h3 className="text-base font-semibold text-slate-900">Thông tin xác nhận nhập khoa &amp; cấp giường</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Mã bệnh nhân *</label>
              <input type="text" required value={patientCode} onChange={(e) => setPatientCode(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Mã HIS</label>
              <input type="text" value={hisCode} onChange={(e) => setHisCode(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Họ tên bệnh nhân *</label>
              <input type="text" required value={patientName} onChange={(e) => setPatientName(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Ngày sinh *</label>
              <input type="date" required value={dob} onChange={(e) => setDob(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Chẩn đoán *</label>
              <select value={diagGroup} onChange={(e) => setDiagGroup(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                {diagnoses.map((d) => (
                  <option key={d.id} value={d.name}>{d.name} ({d.default_days} ngày)</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Khoa tiếp nhận *</label>
              <select value={deptId} onChange={(e) => { setDeptId(e.target.value); setRoomId(''); setBedId(''); }} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                {allowedDepts.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phòng *</label>
              <select value={roomId} onChange={(e) => { setRoomId(e.target.value); setBedId(''); }} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                <option value="">-- Chọn phòng --</option>
                {deptRooms.map((r) => (
                  <option key={r.id} value={r.id}>{r.name} ({r.capacity} giường)</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Giường cấp *</label>
              <select value={bedId} onChange={(e) => setBedId(e.target.value)} required className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                <option value="">-- Chọn giường khả dụng --</option>
                {selectableBeds.map((b) => (
                  <option key={b.id} value={b.id}>{b.code} {b.status === 'RESERVED' ? '(Đã giữ chỗ)' : ''}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Điều chỉnh ngày trả dự kiến (tùy chọn)</label>
              <input type="datetime-local" value={expectedDischarge} onChange={(e) => setExpectedDischarge(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div className="flex items-end pb-2">
              <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input type="checkbox" checked={isWholeRoom} onChange={(e) => setIsWholeRoom(e.target.checked)} className="rounded border-slate-300" />
                <span>Khóa bao trọn phòng này</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Ghi chú tiếp nhận</label>
            <input type="text" value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="rounded-md bg-sky-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-sky-800 disabled:opacity-60"
            >
              {submitting ? 'Đang xác nhận đồng thuận...' : 'Xác nhận tiếp nhận & Cấp giường'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
