import { Plus } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { ConfirmModal } from '../../components/ConfirmModal';
import { apiFetch } from '../../services/api';
import type { Bed, Department, Reservation, Room } from '../../types/bedcare';
import { formatDateTimeVN } from '../../utils/formatters';
import { canReserveInRoom } from '../../utils/roomBedValidation';

interface ReservationsPageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function ReservationsPage({ onNotify }: ReservationsPageProps) {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [beds, setBeds] = useState<Bed[]>([]);
  const [showCreate, setShowCreate] = useState(false);

  const [patientName, setPatientName] = useState('');
  const [deptId, setDeptId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [bedId, setBedId] = useState('');
  const [isWholeRoom, setIsWholeRoom] = useState(false);
  const [holdHours, setHoldHours] = useState(12);
  const [notes, setNotes] = useState('');

  const [cancelTarget, setCancelTarget] = useState<Reservation | null>(null);

  const load = async () => {
    try {
      const [rsvs, depts, rms, bds] = await Promise.all([
        apiFetch<Reservation[]>('/reservations'),
        apiFetch<Department[]>('/departments'),
        apiFetch<Room[]>('/rooms'),
        apiFetch<Bed[]>('/beds'),
      ]);
      setReservations(rsvs);
      setDepartments(depts);
      setRooms(rms);
      setBeds(bds);
      if (!deptId && depts.length > 0) setDeptId(depts[0].id);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const deptRooms = rooms.filter((r) => r.department_id === deptId && r.status === 'ACTIVE' && !r.exclusive_locked);
  const wholeRoomReady = (rId: string) => {
    const rb = beds.filter((b) => b.room_id === rId && b.status !== 'INACTIVE');
    return rb.length > 0 && rb.every((b) => b.status === 'VACANT');
  };
  const selectedRoomObj = rooms.find((r) => r.id === roomId);
  const selectedRoomCheck = selectedRoomObj
    ? canReserveInRoom(
        selectedRoomObj,
        beds.filter((b) => b.room_id === selectedRoomObj.id)
      )
    : { allowed: true };
  const roomVacantBeds = selectedRoomCheck.allowed
    ? beds.filter((b) => b.room_id === roomId && b.status === 'VACANT')
    : [];

  const handleCreate = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedRoomCheck.allowed) {
      onNotify(selectedRoomCheck.reason || 'Phòng đang sử dụng, hệ thống chặn giữ chỗ.', 'error');
      return;
    }
    try {
      const res = await apiFetch<{ pendingConfirmation: boolean }>('/reservations', {
        method: 'POST',
        body: JSON.stringify({
          patient_name: patientName,
          department_id: deptId,
          room_id: roomId,
          bed_id: isWholeRoom ? null : bedId,
          is_whole_room: isWholeRoom,
          hold_hours: Number(holdHours),
          notes,
        }),
      });
      onNotify(
        res.pendingConfirmation
          ? 'Yêu cầu giữ chỗ đang ở trạng thái Chờ xác nhận do thiếu quorum mạng P2P.'
          : isWholeRoom
          ? 'Đã khóa bao trọn phòng thành công qua đồng thuận P2P.'
          : 'Đã giữ chỗ giường thành công qua đồng thuận P2P.'
      );
      setShowCreate(false);
      setPatientName('');
      setNotes('');
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    }
  };

  const handleExtend = async (id: string) => {
    try {
      await apiFetch(`/reservations/${id}/extend`, {
        method: 'POST',
        body: JSON.stringify({ additional_hours: 6 }),
      });
      onNotify('Đã gia hạn giữ chỗ thêm 6 giờ.');
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
    }
  };

  const handleCancel = async () => {
    if (!cancelTarget) return;
    try {
      await apiFetch(`/reservations/${cancelTarget.id}/cancel`, { method: 'POST' });
      onNotify('Đã hủy giữ chỗ và giải phóng giường/phòng.');
      setCancelTarget(null);
      await load();
    } catch (err) {
      onNotify((err as Error).message, 'error');
      setCancelTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Giữ chỗ Giường &amp; Bao trọn phòng</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Giữ chỗ thủ công theo từng giường hoặc bao trọn toàn bộ phòng với kiểm soát đồng thuận P2P chống đặt trùng.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate((v) => !v)}
          className="flex items-center gap-1.5 rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          <span>Tạo giữ chỗ / Bao phòng</span>
        </button>
      </div>

      {showCreate && (
        <form onSubmit={handleCreate} className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
          <h3 className="text-base font-semibold text-slate-900">Giữ chỗ thủ công mới</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Họ tên bệnh nhân *</label>
              <input type="text" required value={patientName} onChange={(e) => setPatientName(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Khoa *</label>
              <select value={deptId} onChange={(e) => { setDeptId(e.target.value); setRoomId(''); setBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Hình thức giữ</label>
              <select value={isWholeRoom ? 'WHOLE' : 'SINGLE'} onChange={(e) => { setIsWholeRoom(e.target.value === 'WHOLE'); setRoomId(''); setBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                <option value="SINGLE">Giữ 1 giường cụ thể</option>
                <option value="WHOLE">Bao trọn toàn bộ phòng</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phòng *</label>
              <select required value={roomId} onChange={(e) => { setRoomId(e.target.value); setBedId(''); }} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                <option value="">-- Chọn phòng --</option>
                {deptRooms
                  .filter((r) => (isWholeRoom ? wholeRoomReady(r.id) : true))
                  .map((r) => {
                    const chk = canReserveInRoom(
                      r,
                      beds.filter((b) => b.room_id === r.id)
                    );
                    return (
                      <option key={r.id} value={r.id} disabled={!chk.allowed}>
                        {r.name} ({r.capacity} giường){!chk.allowed ? ' · Đang sử dụng (Chặn giữ chỗ)' : ''}
                      </option>
                    );
                  })}
              </select>
            </div>
            {!isWholeRoom && (
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Giường trống *</label>
                <select required value={bedId} onChange={(e) => setBedId(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
                  <option value="">-- Chọn giường --</option>
                  {roomVacantBeds.map((b) => (
                    <option key={b.id} value={b.id}>{b.code}</option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Thời gian giữ (giờ)</label>
              <input type="number" min={1} max={72} value={holdHours} onChange={(e) => setHoldHours(Number(e.target.value))} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono tabular-nums" />
            </div>
          </div>
          {!selectedRoomCheck.allowed && (
            <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              {selectedRoomCheck.reason}
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Ghi chú</label>
            <input type="text" value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowCreate(false)} className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700">Hủy</button>
            <button type="submit" disabled={!selectedRoomCheck.allowed} className="rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 disabled:opacity-50">Xác nhận giữ chỗ</button>
          </div>
        </form>
      )}

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Bệnh nhân</th>
                <th className="px-4 py-3 text-left font-medium">Khoa / Phòng / Giường</th>
                <th className="px-4 py-3 text-left font-medium">Loại giữ chỗ</th>
                <th className="px-4 py-3 text-left font-medium">Hạn giữ chỗ</th>
                <th className="px-4 py-3 text-left font-medium">Người thực hiện</th>
                <th className="px-4 py-3 text-left font-medium">Trạng thái</th>
                <th className="px-4 py-3 text-right font-medium">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {reservations.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Chưa có lượt giữ chỗ nào.</td></tr>
              ) : reservations.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">{r.patient_name}</td>
                  <td className="px-4 py-3 text-slate-700">
                    {r.department_name} · {r.room_name} {r.bed_code ? `· ${r.bed_code}` : ''}
                  </td>
                  <td className="px-4 py-3 text-xs font-medium">
                    {r.is_whole_room ? (
                      <span className="text-amber-700">Bao trọn phòng ({r.locked_bed_ids.length} giường)</span>
                    ) : (
                      <span className="text-slate-700">Giữ 1 giường</span>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600">{formatDateTimeVN(r.expires_at)}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{r.created_by_name}</td>
                  <td className="px-4 py-3 text-xs font-semibold">
                    <span className={r.status === 'ACTIVE' ? 'text-amber-700' : r.status === 'CONVERTED' ? 'text-emerald-700' : 'text-slate-500'}>
                      {r.status === 'ACTIVE' ? 'Đang giữ chỗ' : r.status === 'PENDING_CONFIRMATION' ? 'Chờ đồng thuận' : r.status === 'CONVERTED' ? 'Đã tiếp nhận' : 'Đã hủy'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                    {r.status === 'ACTIVE' && (
                      <>
                        <button type="button" onClick={() => handleExtend(r.id)} className="text-xs font-medium text-sky-700 hover:underline">
                          +6 giờ
                        </button>
                        <button type="button" onClick={() => setCancelTarget(r)} className="text-xs font-medium text-rose-600 hover:underline">
                          Hủy giữ chỗ
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ConfirmModal
        open={Boolean(cancelTarget)}
        title="Hủy giữ chỗ giường/phòng"
        description={`Xác nhận hủy giữ chỗ cho ${cancelTarget?.patient_name}? Các giường bị khóa sẽ được giải phóng ngay về trạng thái Trống.`}
        danger
        confirmLabel="Hủy giữ chỗ"
        onConfirm={handleCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
}
