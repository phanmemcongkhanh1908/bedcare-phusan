import type { EChartsOption } from 'echarts';
import { ArrowRight, RefreshCw } from 'lucide-react';
import { EChartBox } from '../../components/EChartBox';
import type { ScreenId } from '../../components/LayoutShell';
import type { Department, SystemAlert } from '../../types/bedcare';
import type { VacancyPredictionSummary } from '../../utils/vacancyPredictor';

export interface TriagePatientItem {
  id: string;
  admission_code: string;
  patient_name: string;
  patient_code: string;
  bed_id: string;
  bed_code: string;
  room_id: string;
  room_name: string;
  department_id: string;
  department_name: string;
  diagnosis_group: string;
  priority: 'CRITICAL' | 'HIGH' | 'NORMAL';
  vitals_alert: string;
  medication_deadline_at: string | null;
  expected_discharge_at: string;
  reason_summary: string;
}

export interface DashboardOverviewData {
  summary: {
    totalDepartments: number;
    totalRooms: number;
    totalBeds: number;
    operationalBeds: number;
    vacantBeds: number;
    occupiedBeds: number;
    reservedBeds: number;
    pendingConfirmationBeds: number;
    cleaningBeds: number;
    maintenanceBeds: number;
    inactiveBeds: number;
    activeInpatients: number;
    dueSoonBeds: number;
    overdueBeds: number;
    occupancyRate: number;
    occupancyFormula: string;
    demoModeActive: boolean;
  };
  deptStats: Department[];
  criticalCapacityDepartments?: Department[];
  triagePatients?: TriagePatientItem[];
  alerts: SystemAlert[];
  vacancyPrediction?: VacancyPredictionSummary;
}

interface DashboardPageProps {
  data: DashboardOverviewData | null;
  loading: boolean;
  onRefresh: () => void;
  onNavigate: (id: ScreenId) => void;
  onOpenDepartmentBeds?: (deptId: string) => void;
}

export function DashboardPage({ data, loading, onRefresh, onNavigate, onOpenDepartmentBeds }: DashboardPageProps) {
  if (loading && !data) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 rounded-lg border border-slate-200 bg-white animate-pulse" />
          ))}
        </div>
        <div className="h-72 rounded-lg border border-slate-200 bg-white animate-pulse" />
      </div>
    );
  }

  if (!data) return null;
  const {
    summary,
    deptStats,
    criticalCapacityDepartments = [],
    triagePatients = [],
    alerts,
    vacancyPrediction,
  } = data;

  const barOption: EChartsOption = {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { bottom: 0, textStyle: { fontSize: 12, color: '#475569' } },
    grid: { left: 32, right: 16, top: 20, bottom: 54, containLabel: true },
    xAxis: {
      type: 'category',
      data: deptStats.map((d) => d.name),
      axisLabel: { color: '#334155', fontSize: 11, interval: 0, width: 105, overflow: 'break', lineHeight: 15 },
    },
    yAxis: {
      type: 'value',
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    series: [
      {
        name: 'Đang sử dụng',
        type: 'bar',
        stack: 'beds',
        itemStyle: { color: '#0284c7' },
        data: deptStats.map((d) => d.occupied_beds ?? 0),
      },
      {
        name: 'Giữ chỗ',
        type: 'bar',
        stack: 'beds',
        itemStyle: { color: '#d97706' },
        data: deptStats.map((d) => d.reserved_beds ?? 0),
      },
      {
        name: 'Còn trống',
        type: 'bar',
        stack: 'beds',
        itemStyle: { color: '#16a34a' },
        data: deptStats.map((d) => d.vacant_beds ?? 0),
      },
      {
        name: 'Vệ sinh / Bảo trì',
        type: 'bar',
        stack: 'beds',
        itemStyle: { color: '#0d9488' },
        data: deptStats.map((d) => (d.cleaning_beds ?? 0) + (d.maintenance_beds ?? 0)),
      },
    ],
  };

  const donutOption: EChartsOption = {
    tooltip: { trigger: 'item', formatter: '{b}: {c} giường ({d}%)' },
    legend: { bottom: 0, textStyle: { fontSize: 11, color: '#475569' } },
    title: {
      text: `${summary.occupancyRate}%`,
      subtext: 'Công suất',
      left: 'center',
      top: '36%',
      textStyle: { fontSize: 22, fontWeight: 700, color: '#0f172a', fontFamily: 'JetBrains Mono, monospace' },
      subtextStyle: { fontSize: 11, color: '#64748b' },
    },
    series: [
      {
        type: 'pie',
        radius: ['50%', '72%'],
        center: ['50%', '43%'],
        label: { show: false },
        data: [
          { name: 'Trống', value: summary.vacantBeds, itemStyle: { color: '#16a34a' } },
          { name: 'Đang sử dụng', value: summary.occupiedBeds, itemStyle: { color: '#0284c7' } },
          { name: 'Đang giữ chỗ', value: summary.reservedBeds, itemStyle: { color: '#d97706' } },
          { name: 'Vệ sinh', value: summary.cleaningBeds, itemStyle: { color: '#0d9488' } },
          { name: 'Bảo trì', value: summary.maintenanceBeds, itemStyle: { color: '#dc2626' } },
          { name: 'Chờ xác nhận', value: summary.pendingConfirmationBeds, itemStyle: { color: '#ea580c' } },
        ].filter((d) => d.value > 0),
      },
    ],
  };

  const kpiCards = [
    { label: 'Tổng giường / Hoạt động', value: `${summary.totalBeds} / ${summary.operationalBeds}`, sub: `${summary.totalDepartments} khoa · ${summary.totalRooms} phòng`, tone: 'text-slate-900' },
    { label: 'Công suất sử dụng giường', value: `${summary.occupancyRate}%`, sub: `${summary.occupiedBeds} giường đang nằm`, tone: 'text-sky-700' },
    { label: 'Giường trống sẵn sàng', value: `${summary.vacantBeds}`, sub: `${summary.reservedBeds} đang giữ chỗ · ${summary.cleaningBeds} vệ sinh`, tone: 'text-emerald-700' },
    { label: 'Sắp trả / Quá ngày', value: `${summary.dueSoonBeds} / ${summary.overdueBeds}`, sub: `${summary.activeInpatients} bệnh nhân đang nằm`, tone: summary.overdueBeds > 0 ? 'text-rose-700' : 'text-amber-700' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-xl font-semibold text-slate-900">Tổng quan công suất giường bệnh</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Công thức công suất: {summary.occupancyFormula}
            {summary.demoModeActive && (
              <>
                {' · '}
                <button
                  type="button"
                  onClick={() => onNavigate('settings')}
                  className="text-amber-700 font-medium hover:underline"
                >
                  Đang dùng dữ liệu demo (Cấu hình)
                </button>
              </>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onRefresh}
            className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Làm mới</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('beds')}
            className="flex items-center gap-1.5 rounded-md bg-sky-700 px-3.5 py-1.5 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap"
          >
            <span>Mở sơ đồ giường</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((k) => (
          <div key={k.label} className="rounded-lg border border-slate-200 bg-white p-5">
            <div className="text-xs font-medium text-slate-500">{k.label}</div>
            <div className={`mt-2 text-2xl font-bold font-mono tabular-nums ${k.tone}`}>
              {k.value}
            </div>
            <div className="mt-1.5 text-xs text-slate-500">{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Critical Capacity (>90% Occupancy) */}
      <section aria-label="Công suất tới hạn trên 90%" className="rounded-lg border border-slate-200 bg-white p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Cảnh báo Công suất tới hạn (&gt; 90%)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Theo dõi các khoa vượt ngưỡng công suất 90% để kịp thời điều phối giường hoặc mở rộng giường dự phòng.
            </p>
          </div>
          <span
            className={`text-xs font-semibold px-2.5 py-1 rounded border ${
              criticalCapacityDepartments.length > 0
                ? 'border-rose-200 bg-rose-50 text-rose-700'
                : 'border-emerald-200 bg-emerald-50 text-emerald-700'
            }`}
          >
            {criticalCapacityDepartments.length > 0
              ? `${criticalCapacityDepartments.length} khoa vượt ngưỡng 90%`
              : 'Tất cả khoa đang trong ngưỡng an toàn (≤ 90%)'}
          </span>
        </div>

        {criticalCapacityDepartments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {criticalCapacityDepartments.map((d) => (
              <div key={d.id} className="rounded-lg border border-rose-200 bg-rose-50/50 p-4 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-rose-950">{d.name}</div>
                  <div className="text-xs text-rose-800 mt-0.5 font-mono tabular-nums whitespace-nowrap">
                    Công suất: {d.occupancy_rate}% · {d.occupied_beds}/{d.total_beds} giường
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => (onOpenDepartmentBeds ? onOpenDepartmentBeds(d.id) : onNavigate('beds'))}
                  className="shrink-0 rounded-md bg-rose-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-rose-800 whitespace-nowrap"
                >
                  Mở sơ đồ giường
                </button>
              </div>
            ))}
          </div>
        ) : (
          deptStats.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-slate-100 bg-slate-50 px-4 py-2.5 text-xs text-slate-600">
              <span>
                Khoa có công suất cao nhất hiện tại:{' '}
                <strong className="text-slate-900">
                  {[...deptStats].sort((a, b) => Number(b.occupancy_rate ?? 0) - Number(a.occupancy_rate ?? 0))[0]?.name}
                </strong>{' '}
                (
                <span className="font-mono font-semibold text-slate-900">
                  {[...deptStats].sort((a, b) => Number(b.occupancy_rate ?? 0) - Number(a.occupancy_rate ?? 0))[0]?.occupancy_rate}%
                </span>
                )
              </span>
              <button
                type="button"
                onClick={() => {
                  const topDept = [...deptStats].sort(
                    (a, b) => Number(b.occupancy_rate ?? 0) - Number(a.occupancy_rate ?? 0)
                  )[0];
                  if (topDept && onOpenDepartmentBeds) onOpenDepartmentBeds(topDept.id);
                  else onNavigate('beds');
                }}
                className="font-medium text-sky-700 hover:underline"
              >
                Xem sơ đồ giường khoa này
              </button>
            </div>
          )
        )}
      </section>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-lg border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold text-slate-900">Phân bổ trạng thái giường theo khoa</h3>
            <button
              type="button"
              onClick={() => onNavigate('departments')}
              className="text-xs font-medium text-sky-700 hover:underline whitespace-nowrap"
            >
              Chi tiết theo khoa
            </button>
          </div>
          <EChartBox option={barOption} height={290} />
        </div>

        <div className="lg:col-span-4 rounded-lg border border-slate-200 bg-white p-5">
          <h3 className="text-base font-semibold text-slate-900 mb-3">Tỷ trọng trạng thái toàn viện</h3>
          <EChartBox option={donutOption} height={290} />
        </div>
      </div>

      {/* ML 4-Hour Bed Vacancy Prediction Indicator */}
      {vacancyPrediction && (
        <section aria-label="Dự báo khả năng trống giường 4 giờ tới" className="rounded-lg border border-slate-200 bg-white p-5 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 border-b border-slate-100 pb-3.5">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Dự báo giường trống trong 4 giờ tới
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {vacancyPrediction.modelType} · Phân tích từ {vacancyPrediction.historicalSampleCount} ca đã xuất viện và lịch trả giường hiện tại
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('beds')}
              className="text-xs font-medium text-sky-700 hover:underline whitespace-nowrap self-start md:self-auto"
            >
              Xem sơ đồ giường trống
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
            <div className="md:col-span-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-1 gap-3">
              <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
                <div className="text-xs font-medium text-slate-500">Xác suất có giường trống (4h)</div>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-2xl font-bold font-mono tabular-nums text-sky-700">
                    {vacancyPrediction.anyVacancyProbabilityPct}%
                  </span>
                  <span className="text-xs font-mono tabular-nums text-slate-600">
                    (~{vacancyPrediction.expectedVacanciesNext4h} giường)
                  </span>
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
                <div className="text-xs font-medium text-slate-500">ALOS trung bình (Ngày nằm)</div>
                <div className="mt-1 text-xl font-bold font-mono tabular-nums text-slate-900">
                  {vacancyPrediction.avgLengthOfStayDays} ngày
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5">
                <div className="text-xs font-medium text-slate-500">Đến hạn ≤ 4h / Vệ sinh</div>
                <div className="mt-1 text-xl font-bold font-mono tabular-nums text-emerald-700">
                  {vacancyPrediction.upcomingDischarges4hCount} ca / {vacancyPrediction.cleaningTurnaroundCount} giường
                </div>
              </div>
            </div>

            <div className="md:col-span-8">
              <div className="text-xs font-medium text-slate-500 mb-2">
                Các giường có xác suất giải phóng cao nhất trong 4 giờ tới
              </div>
              {vacancyPrediction.topCandidates.length === 0 ? (
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-4 text-sm text-slate-500">
                  Chưa có giường đang sử dụng hoặc vệ sinh sắp giải phóng trong 4 giờ tới.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 rounded-lg border border-slate-200">
                  {vacancyPrediction.topCandidates.map((c) => {
                    const barColor =
                      c.probabilityPct >= 75
                        ? 'bg-emerald-600'
                        : c.probabilityPct >= 40
                          ? 'bg-amber-500'
                          : 'bg-sky-600';
                    const textColor =
                      c.probabilityPct >= 75
                        ? 'text-emerald-700'
                        : c.probabilityPct >= 40
                          ? 'text-amber-700'
                          : 'text-sky-700';
                    return (
                      <div key={c.bedId} className="px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 text-sm">
                            <span className="font-mono font-bold text-slate-900">{c.bedCode}</span>
                            <span className="text-slate-300">·</span>
                            <span className="text-slate-700 truncate">{c.departmentName}</span>
                            {c.patientName && (
                              <>
                                <span className="text-slate-300">·</span>
                                <span className="text-slate-600 truncate">{c.patientName}</span>
                              </>
                            )}
                          </div>
                          <div className="text-xs text-slate-500 mt-0.5">{c.reasonSummary}</div>
                        </div>
                        <div className="flex items-center gap-3 shrink-0 sm:w-44">
                          <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${barColor}`}
                              style={{ width: `${c.probabilityPct}%` }}
                            />
                          </div>
                          <span className={`w-10 text-right font-mono tabular-nums text-xs font-bold ${textColor}`}>
                            {c.probabilityPct}%
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Automated Triage Priority */}
      <section aria-label="Phân loại ưu tiên lưu trú tự động" className="rounded-lg border border-slate-200 bg-white p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Phân loại Ưu tiên theo Dấu hiệu &amp; Mốc lịch giường (Triage Priority)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Tự động phân màu bệnh nhân đang nằm giường theo cảnh báo sinh hiệu, mốc lịch chăm sóc/thuốc và hạn trả giường từ máy chủ.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('inpatients')}
            className="text-xs font-medium text-sky-700 hover:underline whitespace-nowrap"
          >
            Xem danh sách đang nằm
          </button>
        </div>

        {triagePatients.length === 0 ? (
          <div className="text-sm text-slate-500 py-2">Hiện chưa có bệnh nhân đang nằm giường.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {triagePatients.map((tp) => {
              const badgeCls =
                tp.priority === 'CRITICAL'
                  ? 'border-rose-300 bg-rose-50/70 text-rose-900'
                  : tp.priority === 'HIGH'
                    ? 'border-amber-300 bg-amber-50/70 text-amber-900'
                    : 'border-emerald-200 bg-emerald-50/50 text-emerald-900';
              const tagCls =
                tp.priority === 'CRITICAL'
                  ? 'bg-rose-700 text-white'
                  : tp.priority === 'HIGH'
                    ? 'bg-amber-600 text-white'
                    : 'bg-emerald-700 text-white';
              const label =
                tp.priority === 'CRITICAL'
                  ? 'Khẩn cấp'
                  : tp.priority === 'HIGH'
                    ? 'Ưu tiên cao'
                    : 'Ổn định';
              return (
                <div key={tp.id} className={`rounded-lg border p-3.5 flex items-start justify-between gap-3 ${badgeCls}`}>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-sm font-semibold">
                      <span className="font-mono">{tp.bed_code}</span>
                      <span>·</span>
                      <span className="truncate">{tp.patient_name}</span>
                    </div>
                    <div className="text-xs opacity-80 mt-0.5">
                      {tp.department_name} · {tp.room_name} · {tp.diagnosis_group}
                    </div>
                    <div className="text-xs mt-1.5 font-medium">{tp.reason_summary}</div>
                  </div>
                  <span className={`shrink-0 rounded px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap ${tagCls}`}>
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Bottom Row: Department Table + Priority Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-lg border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Công suất từng khoa</h3>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="text-xs font-medium text-sky-700 hover:underline"
            >
              Xem báo cáo đầy đủ
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left font-medium">Khoa nội trú</th>
                  <th className="px-4 py-2.5 text-right font-medium">Tổng giường</th>
                  <th className="px-4 py-2.5 text-right font-medium">Đang nằm</th>
                  <th className="px-4 py-2.5 text-right font-medium">Trống</th>
                  <th className="px-4 py-2.5 text-right font-medium">Công suất</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {deptStats.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50">
                    <td className="px-4 py-2.5 font-medium text-slate-900">{d.name}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-600">{d.total_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-sky-700 font-medium">{d.occupied_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-emerald-700 font-medium">{d.vacant_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums font-semibold text-slate-900">{d.occupancy_rate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-lg border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Cảnh báo ưu tiên</h3>
            <button
              type="button"
              onClick={() => onNavigate('alerts')}
              className="text-xs font-medium text-sky-700 hover:underline"
            >
              Xem tất cả ({alerts.length})
            </button>
          </div>
          {alerts.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">Không có cảnh báo nào cần xử lý.</div>
          ) : (
            <div className="divide-y divide-slate-100">
              {alerts.slice(0, 6).map((al) => (
                <div key={al.id} className="px-5 py-3 flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">{al.title}</div>
                    <div className="text-xs text-slate-500 mt-0.5 line-clamp-2">{al.message}</div>
                  </div>
                  <span
                    className={`shrink-0 text-xs font-semibold whitespace-nowrap ${
                      al.priority === 'CRITICAL'
                        ? 'text-rose-700'
                        : al.priority === 'HIGH'
                        ? 'text-amber-700'
                        : 'text-sky-700'
                    }`}
                  >
                    {al.priority === 'CRITICAL' ? 'Khẩn cấp' : al.priority === 'HIGH' ? 'Cao' : 'Trung bình'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
