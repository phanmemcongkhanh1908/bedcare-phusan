import { useEffect, useState } from 'react';
import type { ScreenId } from '../../components/LayoutShell';
import { apiFetch } from '../../services/api';
import type { Registration, RoomStandard } from '../../types/bedcare';
import { formatDateTimeVN, formatDateVN } from '../../utils/formatters';

interface WaitlistPageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
  onNavigate: (id: ScreenId) => void;
}

export function WaitlistPage({ onNotify, onNavigate }: WaitlistPageProps) {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [standards, setStandards] = useState<RoomStandard[]>([]);
  const [pendingReqs, setPendingReqs] = useState<Array<Record<string, unknown>>>([]);

  const load = async () => {
    try {
      const [regs, stds, cluster] = await Promise.all([
        apiFetch<Registration[]>('/registrations'),
        apiFetch<RoomStandard[]>('/room-standards'),
        apiFetch<{ pendingRequests: Array<Record<string, unknown>> }>('/cluster/status'),
      ]);
      setRegistrations(regs.filter((r) => r.status === 'WAITING' || r.status === 'PENDING_CONFIRMATION'));
      setStandards(stds);
      setPendingReqs(cluster.pendingRequests.filter((p) => p.status === 'WAITING_QUORUM'));
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const stdMap = Object.fromEntries(standards.map((s) => [s.id, s.name]));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Danh sách Chờ phân bổ &amp; Chờ xác nhận</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Theo dõi bệnh nhân đăng ký chưa xác định khoa/giường và các giao dịch đang chờ đồng thuận P2P.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('admissions')}
          className="rounded-md bg-sky-700 px-4 py-2 text-sm font-medium text-white hover:bg-sky-800 whitespace-nowrap"
        >
          Chuyển sang Tiếp nhận vào khoa
        </button>
      </div>

      {pendingReqs.length > 0 && (
        <div className="rounded-lg border border-orange-200 bg-orange-50 p-5 space-y-2">
          <div className="text-sm font-semibold text-orange-900">
            Có {pendingReqs.length} yêu cầu cấp/giữ giường đang chờ đồng thuận quorum
          </div>
          <div className="text-xs text-orange-800">
            Các yêu cầu này được ghi nhận khi mạng bị phân vùng hoặc không đủ nút xác nhận. Mở mục Đồng bộ &amp; Đồng thuận để đối chiếu khi mạng khôi phục.
          </div>
        </div>
      )}

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Mã đăng ký</th>
                <th className="px-4 py-3 text-left font-medium">Bệnh nhân</th>
                <th className="px-4 py-3 text-left font-medium">Chẩn đoán</th>
                <th className="px-4 py-3 text-left font-medium">Tiêu chuẩn mong muốn</th>
                <th className="px-4 py-3 text-left font-medium">Dự kiến nhập</th>
                <th className="px-4 py-3 text-left font-medium">Thời gian đăng ký</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {registrations.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">Không có hồ sơ nào trong danh sách chờ.</td></tr>
              ) : registrations.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-mono text-xs font-semibold text-slate-900">{r.registration_code}</td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-900">{r.patient_name}</div>
                    <div className="text-xs text-slate-500">{r.patient_code} · {r.phone || 'Chưa có SĐT'}</div>
                  </td>
                  <td className="px-4 py-3 text-slate-700">{r.diagnosis_group}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">
                    {(r.desired_standard_ids || []).map((id) => stdMap[id] || id).join(' · ') || 'Không yêu cầu cụ thể'}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-700">{formatDateVN(r.expected_admission_date)}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-500">{formatDateTimeVN(r.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
