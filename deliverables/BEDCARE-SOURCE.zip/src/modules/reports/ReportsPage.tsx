import type { EChartsOption } from 'echarts';
import { Download, Printer } from 'lucide-react';
import { useEffect, useState } from 'react';
import { EChartBox } from '../../components/EChartBox';
import { apiFetch } from '../../services/api';
import type { Department } from '../../types/bedcare';
import { exportToExcel, exportToPdf } from '../../utils/exportUtils';
import { formatDateTimeVN } from '../../utils/formatters';

interface AnalyticsPayload {
  kpi: {
    totalAdmissions: number;
    totalDischarges: number;
    totalBedDays: number;
    totalExtensions: number;
    totalTransfers: number;
    avgStayDays: number;
    occupancyRate: number;
  };
  deptUsage: Array<{
    department_id: string;
    department_name: string;
    total_beds: number;
    operational_beds: number;
    occupied_beds: number;
    occupancy_rate: number;
    admission_count: number;
    discharge_count: number;
  }>;
  roomUsage: Array<{
    room_id: string;
    room_code: string;
    room_name: string;
    room_type: string;
    capacity: number;
    occupied: number;
    occupancy_rate: number;
  }>;
  overdueList: Array<Record<string, unknown>>;
  dueSoonList: Array<Record<string, unknown>>;
  transfers: Array<Record<string, unknown>>;
  extensions: Array<Record<string, unknown>>;
}

interface ReportsPageProps {
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export function ReportsPage({ onNotify }: ReportsPageProps) {
  const [data, setData] = useState<AnalyticsPayload | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [deptFilter, setDeptFilter] = useState('');
  const [activeReportTab, setActiveReportTab] = useState<'dept' | 'room' | 'overdue' | 'duesoon' | 'transfers'>('dept');

  const load = async () => {
    try {
      const [rep, depts] = await Promise.all([
        apiFetch<AnalyticsPayload>(deptFilter ? `/reports/analytics?departmentId=${deptFilter}` : '/reports/analytics'),
        apiFetch<Department[]>('/departments'),
      ]);
      setData(rep);
      setDepartments(depts);
    } catch (e) {
      onNotify((e as Error).message, 'error');
    }
  };

  useEffect(() => {
    load();
  }, [deptFilter]);

  if (!data) return <div className="h-64 rounded-lg border border-slate-200 bg-white animate-pulse" />;

  const chartOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    grid: { left: 40, right: 20, top: 24, bottom: 40, containLabel: true },
    xAxis: {
      type: 'category',
      data: data.deptUsage.map((d) => d.department_name),
      axisLabel: { color: '#334155', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      max: 100,
      axisLabel: { formatter: '{value}%', color: '#64748b' },
    },
    series: [
      {
        name: 'Công suất sử dụng (%)',
        type: 'bar',
        barMaxWidth: 44,
        itemStyle: { color: '#0369a1', borderRadius: [4, 4, 0, 0] },
        data: data.deptUsage.map((d) => d.occupancy_rate),
      },
    ],
  };

  const handleExportExcel = async () => {
    await exportToExcel(
      'Bao-cao-cong-suat-giuong-BEDCARE',
      'CongSuatTheoKhoa',
      [
        { header: 'Khoa nội trú', key: 'department_name', width: 26 },
        { header: 'Tổng giường', key: 'total_beds', width: 14 },
        { header: 'Giường hoạt động', key: 'operational_beds', width: 18 },
        { header: 'Đang sử dụng', key: 'occupied_beds', width: 15 },
        { header: 'Công suất (%)', key: 'occupancy_rate', width: 15 },
        { header: 'Lượt tiếp nhận', key: 'admission_count', width: 16 },
        { header: 'Lượt trả giường', key: 'discharge_count', width: 16 },
      ],
      data.deptUsage
    );
    onNotify('Đã xuất báo cáo Excel (.xlsx) thành công.');
  };

  const handleExportPdf = async () => {
    await exportToPdf(
      'Bao-cao-thong-ke-BEDCARE',
      'BÁO CÁO CÔNG SUẤT SỬ DỤNG GIƯỜNG BỆNH - BEDCARE',
      `Công suất toàn viện: ${data.kpi.occupancyRate}% · Tổng ngày giường: ${data.kpi.totalBedDays} ngày`,
      [
        { header: 'Khoa nội trú', key: 'department_name' },
        { header: 'Tổng giường', key: 'total_beds' },
        { header: 'Hoạt động', key: 'operational_beds' },
        { header: 'Đang nằm', key: 'occupied_beds' },
        { header: 'Công suất (%)', key: 'occupancy_rate' },
        { header: 'Tiếp nhận', key: 'admission_count' },
        { header: 'Trả giường', key: 'discharge_count' },
      ],
      data.deptUsage
    );
    onNotify('Đã xuất báo cáo PDF (.pdf) với font Unicode tiếng Việt.');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Báo cáo &amp; Thống kê chuyên sâu</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Số liệu được tính trực tiếp từ giao dịch thực tế trong SQLite (không dùng số liệu giả lập).
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 no-print">
          <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} aria-label="Lọc theo khoa" className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
            <option value="">Toàn viện</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Xuất Excel</span>
          </button>
          <button
            type="button"
            onClick={handleExportPdf}
            className="flex items-center gap-1.5 rounded-md border border-sky-300 bg-sky-50 px-3 py-2 text-xs font-semibold text-sky-800 hover:bg-sky-100 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Xuất PDF</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>In báo cáo</span>
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Công suất giường', val: `${data.kpi.occupancyRate}%` },
          { label: 'Lượt tiếp nhận', val: `${data.kpi.totalAdmissions}` },
          { label: 'Lượt trả giường', val: `${data.kpi.totalDischarges}` },
          { label: 'Tổng ngày giường', val: `${data.kpi.totalBedDays}` },
          { label: 'Lượt gia hạn', val: `${data.kpi.totalExtensions}` },
          { label: 'Thời gian TB (ngày)', val: `${data.kpi.avgStayDays}` },
        ].map((k) => (
          <div key={k.label} className="rounded-lg border border-slate-200 bg-white p-4">
            <div className="text-xs text-slate-500">{k.label}</div>
            <div className="mt-1.5 text-xl font-bold font-mono tabular-nums text-slate-900">{k.val}</div>
          </div>
        ))}
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-5">
        <h3 className="text-base font-semibold text-slate-900 mb-3">Biểu đồ công suất sử dụng giường theo khoa</h3>
        <EChartBox option={chartOption} height={260} />
      </div>

      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center gap-1.5 bg-slate-50">
          {[
            { id: 'dept', label: 'Sử dụng theo khoa' },
            { id: 'room', label: 'Sử dụng theo phòng' },
            { id: 'overdue', label: `Bệnh nhân quá ngày (${data.overdueList.length})` },
            { id: 'duesoon', label: `Giường sắp trả (${data.dueSoonList.length})` },
            { id: 'transfers', label: `Lịch sử điều chuyển (${data.transfers.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveReportTab(t.id as typeof activeReportTab)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                activeReportTab === t.id ? 'bg-white text-sky-800 shadow-sm border border-slate-200' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="overflow-x-auto">
          {activeReportTab === 'dept' && (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Khoa</th>
                  <th className="px-4 py-2.5 text-right">Tổng giường</th>
                  <th className="px-4 py-2.5 text-right">Hoạt động</th>
                  <th className="px-4 py-2.5 text-right">Đang nằm</th>
                  <th className="px-4 py-2.5 text-right">Công suất</th>
                  <th className="px-4 py-2.5 text-right">Tiếp nhận</th>
                  <th className="px-4 py-2.5 text-right">Trả giường</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.deptUsage.map((d) => (
                  <tr key={d.department_id}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{d.department_name}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{d.total_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{d.operational_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-sky-700">{d.occupied_beds}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums font-semibold">{d.occupancy_rate}%</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{d.admission_count}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{d.discharge_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'room' && (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Phòng</th>
                  <th className="px-4 py-2.5 text-left">Loại phòng</th>
                  <th className="px-4 py-2.5 text-right">Quy mô giường</th>
                  <th className="px-4 py-2.5 text-right">Đang sử dụng</th>
                  <th className="px-4 py-2.5 text-right">Công suất</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.roomUsage.map((r) => (
                  <tr key={r.room_id}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{r.room_name} ({r.room_code})</td>
                    <td className="px-4 py-2.5 text-slate-600">{r.room_type}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{r.capacity}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-sky-700">{r.occupied}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums font-semibold">{r.occupancy_rate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {(activeReportTab === 'overdue' || activeReportTab === 'duesoon') && (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Bệnh nhân</th>
                  <th className="px-4 py-2.5 text-left">Khoa / Giường</th>
                  <th className="px-4 py-2.5 text-left">Dự kiến trả</th>
                  <th className="px-4 py-2.5 text-right">Đã nằm</th>
                  <th className="px-4 py-2.5 text-right">Chênh lệch</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(activeReportTab === 'overdue' ? data.overdueList : data.dueSoonList).map((item) => {
                  const m = item.stay_metrics as { daysStayed: number; daysRemaining: number };
                  return (
                    <tr key={String(item.id)}>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{String(item.patient_name)}</td>
                      <td className="px-4 py-2.5 text-slate-700">{String(item.department_name)} · {String(item.bed_code)}</td>
                      <td className="px-4 py-2.5 font-mono text-xs">{formatDateTimeVN(String(item.expected_discharge_at))}</td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums">{m.daysStayed} ngày</td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums font-semibold text-rose-700">{m.daysRemaining} ngày</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {activeReportTab === 'transfers' && (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 text-left">Bệnh nhân</th>
                  <th className="px-4 py-2.5 text-left">Lý do</th>
                  <th className="px-4 py-2.5 text-left">Người thực hiện</th>
                  <th className="px-4 py-2.5 text-left">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.transfers.map((t) => (
                  <tr key={String(t.id)}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{String(t.patient_name)}</td>
                    <td className="px-4 py-2.5 text-slate-700">{String(t.reason)}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-600">{String(t.performed_by_name)}</td>
                    <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{formatDateTimeVN(String(t.performed_at))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
