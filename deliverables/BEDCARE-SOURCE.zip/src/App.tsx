import { CheckCircle2, X, XCircle } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { HelpCenter } from './components/HelpCenter';
import { LayoutShell, type ScreenId } from './components/LayoutShell';
import { AdmissionsPage } from './modules/admissions/AdmissionsPage';
import { AlertsPage } from './modules/alerts/AlertsPage';
import { LoginScreen } from './modules/auth/LoginScreen';
import { BackupRestorePage } from './modules/backup/BackupRestorePage';
import { BedsMapPage } from './modules/beds/BedsMapPage';
import { CleaningPage } from './modules/cleaning/CleaningPage';
import { DashboardPage, type DashboardOverviewData } from './modules/dashboard/DashboardPage';
import { DepartmentsPage } from './modules/departments/DepartmentsPage';
import { DevicesPage } from './modules/devices/DevicesPage';
import { DischargePage } from './modules/discharge/DischargePage';
import { ExtensionsPage } from './modules/extensions/ExtensionsPage';
import { InpatientsPage } from './modules/patients/InpatientsPage';
import { RegistrationsPage } from './modules/registrations/RegistrationsPage';
import { ReportsPage } from './modules/reports/ReportsPage';
import { ReservationsPage } from './modules/reservations/ReservationsPage';
import { RoomsPage } from './modules/rooms/RoomsPage';
import { SettingsPage } from './modules/settings/SettingsPage';
import { SyncConsensusPage } from './modules/sync/SyncConsensusPage';
import { TransfersPage } from './modules/transfers/TransfersPage';
import { UsersPage } from './modules/users/UsersPage';
import { WaitlistPage } from './modules/waitlist/WaitlistPage';
import { apiFetch, getAuthToken, setAuthToken } from './services/api';
import type { UserRole } from './types/bedcare';

interface AuthSession {
  user: {
    id: string;
    username: string;
    full_name: string;
    role: UserRole;
    department_id: string | null;
  };
  activeNode: {
    deviceId: string;
    nodeName: string;
    isCoordinator: boolean;
  };
}

export default function App() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [activeScreen, setActiveScreen] = useState<ScreenId>('dashboard');
  const [overview, setOverview] = useState<DashboardOverviewData | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('');
  const [helpOpen, setHelpOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const notify = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 5000);
  }, []);

  const loadOverview = useCallback(async () => {
    setLoadingOverview(true);
    try {
      const data = await apiFetch<DashboardOverviewData>('/dashboard/overview');
      setOverview(data);
    } catch {
      // Ignore if logged out
    } finally {
      setLoadingOverview(false);
    }
  }, []);

  const checkAuth = useCallback(async () => {
    const token = getAuthToken();
    if (!token) {
      setCheckingAuth(false);
      return;
    }
    try {
      const me = await apiFetch<AuthSession>('/auth/me');
      setSession(me);
      await loadOverview();
    } catch {
      setAuthToken(null);
      setSession(null);
    } finally {
      setCheckingAuth(false);
    }
  }, [loadOverview]);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  // Real-time WebSocket listener for P2P cluster events
  useEffect(() => {
    if (!session) return;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${window.location.host}/ws/p2p`);
    ws.onmessage = () => {
      loadOverview();
    };
    return () => ws.close();
  }, [session, loadOverview]);

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-sm text-slate-600">
        Đang khởi tạo phiên làm việc BEDCARE...
      </div>
    );
  }

  if (!session) {
    return (
      <LoginScreen
        onSuccess={(res) => {
          setSession({ user: res.user, activeNode: res.activeNode });
          setActiveScreen('dashboard');
          loadOverview();
        }}
      />
    );
  }

  const handleLogout = () => {
    setAuthToken(null);
    setSession(null);
    setOverview(null);
  };

  return (
    <>
      <LayoutShell
        activeScreen={activeScreen}
        onNavigate={(id) => {
          setActiveScreen(id);
          loadOverview();
        }}
        user={session.user}
        activeNodeId={session.activeNode.deviceId}
        activeNodeName={session.activeNode.nodeName}
        alertCount={overview?.alerts.length ?? 0}
        globalSearch={globalSearch}
        onGlobalSearchChange={(val) => {
          setGlobalSearch(val);
          if (val.trim() && activeScreen === 'dashboard') {
            setActiveScreen('beds');
          }
        }}
        onOpenHelp={() => setHelpOpen(true)}
        onLogout={handleLogout}
      >
        {activeScreen === 'dashboard' && (
          <DashboardPage
            data={overview}
            loading={loadingOverview}
            onRefresh={loadOverview}
            onNavigate={setActiveScreen}
            onOpenDepartmentBeds={(deptId) => {
              setSelectedDeptFilter(deptId);
              setActiveScreen('beds');
            }}
          />
        )}
        {activeScreen === 'departments' && (
          <DepartmentsPage
            userRole={session.user.role}
            onNotify={notify}
            onSelectDepartment={(deptId) => {
              setSelectedDeptFilter(deptId);
              setActiveScreen('rooms');
            }}
          />
        )}
        {activeScreen === 'rooms' && (
          <RoomsPage
            userRole={session.user.role}
            initialDepartmentFilter={selectedDeptFilter}
            onNotify={notify}
          />
        )}
        {activeScreen === 'beds' && (
          <BedsMapPage
            userRole={session.user.role}
            userDeptId={session.user.department_id}
            initialDepartmentFilter={selectedDeptFilter}
            globalSearch={globalSearch}
            onNotify={notify}
            onNavigate={setActiveScreen}
          />
        )}
        {activeScreen === 'registrations' && <RegistrationsPage onNotify={notify} />}
        {activeScreen === 'reservations' && <ReservationsPage onNotify={notify} />}
        {activeScreen === 'waitlist' && (
          <WaitlistPage onNotify={notify} onNavigate={setActiveScreen} />
        )}
        {activeScreen === 'admissions' && (
          <AdmissionsPage userDeptId={session.user.department_id} onNotify={notify} />
        )}
        {activeScreen === 'inpatients' && (
          <InpatientsPage globalSearch={globalSearch} onNotify={notify} />
        )}
        {activeScreen === 'extensions' && <ExtensionsPage onNotify={notify} />}
        {activeScreen === 'transfers' && <TransfersPage onNotify={notify} />}
        {activeScreen === 'discharge' && <DischargePage onNotify={notify} />}
        {activeScreen === 'cleaning' && <CleaningPage onNotify={notify} />}
        {activeScreen === 'alerts' && (
          <AlertsPage
            alerts={overview?.alerts ?? []}
            departments={overview?.deptStats ?? []}
            onNavigate={setActiveScreen}
          />
        )}
        {activeScreen === 'reports' && <ReportsPage onNotify={notify} />}
        {activeScreen === 'users' && (
          <UsersPage
            currentUserId={session.user.id}
            currentUserRole={session.user.role}
            onNotify={notify}
          />
        )}
        {activeScreen === 'devices' && (
          <DevicesPage
            currentUserRole={session.user.role}
            onNotify={notify}
            onNodeSwitched={checkAuth}
          />
        )}
        {activeScreen === 'sync' && (
          <SyncConsensusPage userRole={session.user.role} onNotify={notify} />
        )}
        {activeScreen === 'backup' && <BackupRestorePage onNotify={notify} />}
        {activeScreen === 'settings' && (
          <SettingsPage
            userRole={session.user.role}
            onNotify={notify}
            onDataChanged={loadOverview}
          />
        )}
      </LayoutShell>

      {toast && (
        <div
          role="status"
          aria-live="polite"
          className={`no-print fixed bottom-5 right-5 z-50 flex items-center gap-2.5 rounded-lg border px-4 py-3 text-sm font-medium shadow-lg max-w-md ${
            toast.type === 'error'
              ? 'border-rose-200 bg-rose-50 text-rose-800'
              : 'border-emerald-200 bg-emerald-50 text-emerald-900'
          }`}
        >
          {toast.type === 'error' ? (
            <XCircle className="h-4 w-4 text-rose-600 shrink-0" />
          ) : (
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          )}
          <span className="flex-1">{toast.message}</span>
          <button
            type="button"
            onClick={() => setToast(null)}
            aria-label="Đóng thông báo"
            className="text-slate-400 hover:text-slate-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      <HelpCenter
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        currentScreen={activeScreen}
        onNavigate={(id) => {
          setActiveScreen(id);
          loadOverview();
        }}
      />
    </>
  );
}
