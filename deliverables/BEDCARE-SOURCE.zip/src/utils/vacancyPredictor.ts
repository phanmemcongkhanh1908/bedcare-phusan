export interface HistoricalDischargeInput {
  diagnosis_group: string;
  bed_assigned_at: string;
  actual_discharge_at: string;
}

export interface DiagnosisBaselineInput {
  name: string;
  default_days: number;
}

export interface ActiveStayInput {
  id: string;
  bed_id: string;
  bed_code: string;
  room_id: string;
  room_name: string;
  department_id: string;
  department_name: string;
  patient_name: string;
  diagnosis_group: string;
  bed_assigned_at: string;
  expected_discharge_at: string;
  extension_count: number;
  is_whole_room: number | boolean;
  status: string;
}

export interface TurnaroundBedInput {
  id: string;
  code: string;
  room_id: string;
  room_name: string;
  department_id: string;
  department_name: string;
  status: string;
  updated_at?: string;
}

export interface VacancyCandidate {
  bedId: string;
  bedCode: string;
  roomName: string;
  departmentId: string;
  departmentName: string;
  sourceType: 'ADMISSION_DISCHARGE' | 'CLEANING_TURNAROUND';
  patientName?: string;
  diagnosisGroup?: string;
  probabilityPct: number;
  hoursToExpected: number;
  alosDays: number;
  daysStayed: number;
  reasonSummary: string;
}

export interface DepartmentVacancyForecast {
  departmentId: string;
  departmentName: string;
  expectedVacancies4h: number;
  anyVacancyProbabilityPct: number;
  candidateCount: number;
}

export interface VacancyPredictionSummary {
  modelType: string;
  horizonHours: number;
  anyVacancyProbabilityPct: number;
  expectedVacanciesNext4h: number;
  avgLengthOfStayDays: number;
  historicalSampleCount: number;
  upcomingDischarges4hCount: number;
  cleaningTurnaroundCount: number;
  topCandidates: VacancyCandidate[];
  departmentForecasts: DepartmentVacancyForecast[];
  generatedAt: string;
}

function sigmoid(z: number): number {
  if (z > 20) return 0.9999;
  if (z < -20) return 0.0001;
  return 1 / (1 + Math.exp(-z));
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function computeDiagnosisAlosMap(
  historicalDischarges: HistoricalDischargeInput[],
  diagnosisBaselines: DiagnosisBaselineInput[]
): { byDiagnosis: Record<string, number>; globalAlos: number } {
  const baselineMap: Record<string, number> = {};
  for (const d of diagnosisBaselines) {
    baselineMap[d.name] = Math.max(0.5, Number(d.default_days) || 3);
  }

  const samplesByDiag = new Map<string, number[]>();
  const allDurations: number[] = [];

  for (const h of historicalDischarges) {
    const startMs = new Date(h.bed_assigned_at).getTime();
    const endMs = new Date(h.actual_discharge_at).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) continue;
    const days = clamp((endMs - startMs) / 86400000, 0.25, 60);
    allDurations.push(days);
    const arr = samplesByDiag.get(h.diagnosis_group) ?? [];
    arr.push(days);
    samplesByDiag.set(h.diagnosis_group, arr);
  }

  const byDiagnosis: Record<string, number> = { ...baselineMap };
  for (const [diag, samples] of samplesByDiag.entries()) {
    const empMean = samples.reduce((s, v) => s + v, 0) / samples.length;
    const prior = baselineMap[diag] ?? 3;
    // Bayesian shrinkage: blend empirical discharges with clinical diagnosis prior (weight=3)
    const blended = (empMean * samples.length + prior * 3) / (samples.length + 3);
    byDiagnosis[diag] = Number(blended.toFixed(2));
  }

  const baselineValues = Object.values(baselineMap);
  const priorGlobal = baselineValues.length > 0
    ? baselineValues.reduce((a, b) => a + b, 0) / baselineValues.length
    : 3;

  const globalAlos =
    allDurations.length > 0
      ? Number(
          (
            (allDurations.reduce((a, b) => a + b, 0) + priorGlobal * 3) /
            (allDurations.length + 3)
          ).toFixed(2)
        )
      : Number(priorGlobal.toFixed(2));

  return { byDiagnosis, globalAlos };
}

export function predict4HourBedVacancies(params: {
  activeAdmissions: ActiveStayInput[];
  turnaroundBeds: TurnaroundBedInput[];
  historicalDischarges: HistoricalDischargeInput[];
  diagnosisBaselines: DiagnosisBaselineInput[];
  nowIso?: string;
}): VacancyPredictionSummary {
  const nowMs = new Date(params.nowIso ?? new Date().toISOString()).getTime();
  const { byDiagnosis, globalAlos } = computeDiagnosisAlosMap(
    params.historicalDischarges,
    params.diagnosisBaselines
  );

  const candidates: VacancyCandidate[] = [];
  let upcomingDischarges4hCount = 0;

  for (const adm of params.activeAdmissions) {
    if (adm.status !== 'ACTIVE') continue;
    const assignedMs = new Date(adm.bed_assigned_at).getTime();
    const expectedMs = new Date(adm.expected_discharge_at).getTime();
    const daysStayed = Math.max(0, (nowMs - assignedMs) / 86400000);
    const hoursToExpected = (expectedMs - nowMs) / 3600000;
    const alosDays = byDiagnosis[adm.diagnosis_group] ?? globalAlos;
    const alosRatio = clamp(daysStayed / Math.max(0.5, alosDays), 0, 2.5);

    if (hoursToExpected <= 4) {
      upcomingDischarges4hCount++;
    }

    // Calibrated Logistic Regression log-odds for 4h vacancy likelihood:
    // Positive drivers: schedule <= 4h, overdue, high ALOS progress ratio
    // Negative drivers: far future schedule, multiple active extensions
    const scheduleSignal =
      hoursToExpected <= 0
        ? 2.2 // Already overdue / discharge imminent
        : hoursToExpected <= 4
          ? 1.9 - (hoursToExpected / 4) * 0.6 // Scheduled within next 4 hours
          : hoursToExpected <= 12
            ? -0.9 - ((hoursToExpected - 4) / 8) * 1.1
            : -3.2;

    const alosSignal = (alosRatio - 0.75) * 1.35;
    const extensionPenalty = -0.35 * Math.min(3, Number(adm.extension_count) || 0);
    const intercept = -0.15;

    const prob = clamp(sigmoid(intercept + scheduleSignal + alosSignal + extensionPenalty), 0.01, 0.96);
    const probabilityPct = Math.round(prob * 100);

    let reasonSummary = '';
    if (hoursToExpected <= 0) {
      reasonSummary = `Quá hạn dự kiến trả ${Math.abs(hoursToExpected).toFixed(1)}h · Đã nằm ${daysStayed.toFixed(1)}/${alosDays.toFixed(1)} ngày ALOS`;
    } else if (hoursToExpected <= 4) {
      reasonSummary = `Đến hạn trả sau ${hoursToExpected.toFixed(1)}h · Đã nằm ${daysStayed.toFixed(1)}/${alosDays.toFixed(1)} ngày ALOS`;
    } else if (alosRatio >= 0.9) {
      reasonSummary = `Tiệm cận ALOS (${daysStayed.toFixed(1)}/${alosDays.toFixed(1)} ngày) · Còn ${hoursToExpected.toFixed(0)}h theo lịch`;
    } else {
      reasonSummary = `Còn ${hoursToExpected.toFixed(0)}h theo lịch · ALOS chuẩn ${alosDays.toFixed(1)} ngày`;
    }

    candidates.push({
      bedId: adm.bed_id,
      bedCode: adm.bed_code,
      roomName: adm.room_name,
      departmentId: adm.department_id,
      departmentName: adm.department_name,
      sourceType: 'ADMISSION_DISCHARGE',
      patientName: adm.patient_name,
      diagnosisGroup: adm.diagnosis_group,
      probabilityPct,
      hoursToExpected: Number(hoursToExpected.toFixed(1)),
      alosDays: Number(alosDays.toFixed(1)),
      daysStayed: Number(daysStayed.toFixed(1)),
      reasonSummary,
    });
  }

  let cleaningTurnaroundCount = 0;
  for (const bed of params.turnaroundBeds) {
    if (bed.status !== 'CLEANING' && bed.status !== 'PENDING_CLEANING') continue;
    cleaningTurnaroundCount++;
    const prob = bed.status === 'CLEANING' ? 0.94 : 0.85;
    candidates.push({
      bedId: bed.id,
      bedCode: bed.code,
      roomName: bed.room_name,
      departmentId: bed.department_id,
      departmentName: bed.department_name,
      sourceType: 'CLEANING_TURNAROUND',
      probabilityPct: Math.round(prob * 100),
      hoursToExpected: bed.status === 'CLEANING' ? 0.5 : 1.5,
      alosDays: 0,
      daysStayed: 0,
      reasonSummary:
        bed.status === 'CLEANING'
          ? 'Đang vệ sinh khử khuẩn · Dự kiến sẵn sàng trong ~30 phút'
          : 'Đang chờ vệ sinh sau trả giường · Chu kỳ hoàn tất < 2 giờ',
    });
  }

  candidates.sort((a, b) => b.probabilityPct - a.probabilityPct);

  const probs = candidates.map((c) => c.probabilityPct / 100);
  const expectedVacanciesNext4h = Number(probs.reduce((sum, p) => sum + p, 0).toFixed(1));
  const noneVacantProb = probs.reduce((acc, p) => acc * (1 - p), 1);
  const anyVacancyProbabilityPct = probs.length > 0 ? Math.round((1 - noneVacantProb) * 100) : 0;

  const deptMap = new Map<string, { name: string; probs: number[] }>();
  for (const c of candidates) {
    const entry = deptMap.get(c.departmentId) ?? { name: c.departmentName, probs: [] };
    entry.probs.push(c.probabilityPct / 100);
    deptMap.set(c.departmentId, entry);
  }

  const departmentForecasts: DepartmentVacancyForecast[] = Array.from(deptMap.entries())
    .map(([departmentId, info]) => {
      const exp = info.probs.reduce((s, p) => s + p, 0);
      const anyProb = 1 - info.probs.reduce((a, p) => a * (1 - p), 1);
      return {
        departmentId,
        departmentName: info.name,
        expectedVacancies4h: Number(exp.toFixed(1)),
        anyVacancyProbabilityPct: Math.round(anyProb * 100),
        candidateCount: info.probs.length,
      };
    })
    .sort((a, b) => b.anyVacancyProbabilityPct - a.anyVacancyProbabilityPct);

  return {
    modelType: 'Logistic Hazard (ALOS + Lịch trả giường + Vệ sinh)',
    horizonHours: 4,
    anyVacancyProbabilityPct,
    expectedVacanciesNext4h,
    avgLengthOfStayDays: globalAlos,
    historicalSampleCount: params.historicalDischarges.length,
    upcomingDischarges4hCount,
    cleaningTurnaroundCount,
    topCandidates: candidates.slice(0, 5),
    departmentForecasts,
    generatedAt: new Date(nowMs).toISOString(),
  };
}
