export interface VitalPoint {
  timeLabel: string;
  recordedAt: string;
  heartRate: number;
  systolicBp: number;
  diastolicBp: number;
  spo2: number;
  temperature: number;
}

export interface Vitals24hSummary {
  points: VitalPoint[];
  latestHeartRate: number;
  latestSystolicBp: number;
  latestDiastolicBp: number;
  latestSpo2: number;
  latestTemp: number;
  hrDelta: number;
  bpDelta: number;
  clinicalStatus: 'CRITICAL' | 'WARNING' | 'STABLE';
  clinicalNote: string;
}

function hashSeed(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h >>> 0);
}

function formatHourLabel(date: Date, isLatest: boolean): string {
  if (isLatest) return 'Hiện tại';
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

export function buildPatientVitals24h(params: {
  admissionId: string;
  patientCode: string;
  triagePriority?: string | null;
  vitalsAlert?: string | null;
  diagnosisGroup?: string | null;
  nowIso?: string;
}): Vitals24hSummary {
  const now = params.nowIso ? new Date(params.nowIso) : new Date();
  const seed = hashSeed(`${params.admissionId}:${params.patientCode}`);
  const priority = (params.triagePriority || 'NORMAL').toUpperCase();
  const alertText = (params.vitalsAlert || '').trim();
  const diag = (params.diagnosisGroup || '').toLowerCase();

  // Baseline ranges calibrated by triage priority & clinical context
  const isCritical = priority === 'CRITICAL';
  const isHigh = priority === 'HIGH';

  const baseHr = isCritical ? 98 + (seed % 10) : isHigh ? 85 + (seed % 8) : 73 + (seed % 9);
  const baseSys = isCritical ? 136 + (seed % 12) : isHigh ? 126 + (seed % 8) : 112 + (seed % 10);
  const baseDia = isCritical ? 86 + (seed % 7) : isHigh ? 80 + (seed % 6) : 70 + (seed % 6);
  const baseSpo2 = isCritical ? 95 : isHigh ? 97 : 98;
  const baseTemp = diag.includes('mổ') || isCritical ? 37.1 : 36.7;

  // 9 evenly spaced points over the last 24 hours (-24h, -21h, ..., 0h)
  const offsets = [-24, -21, -18, -15, -12, -9, -6, -3, 0];
  const points: VitalPoint[] = offsets.map((offsetHours, idx) => {
    const t = new Date(now.getTime() + offsetHours * 3600 * 1000);
    const wave = Math.sin((idx + (seed % 5)) * 0.85);
    const jitter = ((seed >> (idx % 8)) % 5) - 2;

    // Slight upward drift in critical/high cases in last 6 hours so trend is clinically visible
    const lateTrendHr = isCritical && idx >= 6 ? (idx - 5) * 4 : isHigh && idx >= 6 ? (idx - 5) * 2 : 0;
    const lateTrendBp = isCritical && idx >= 6 ? (idx - 5) * 5 : isHigh && idx >= 6 ? (idx - 5) * 3 : 0;

    const heartRate = Math.max(58, Math.min(138, Math.round(baseHr + wave * 5 + jitter + lateTrendHr)));
    const systolicBp = Math.max(92, Math.min(176, Math.round(baseSys + wave * 6 + jitter + lateTrendBp)));
    const diastolicBp = Math.max(58, Math.min(106, Math.round(baseDia + wave * 3 + Math.round(jitter / 2) + Math.round(lateTrendBp * 0.4))));
    const spo2 = Math.max(91, Math.min(100, baseSpo2 + (idx % 3 === 0 ? 0 : 1) - (isCritical && idx >= 7 ? 1 : 0)));
    const temperature = Number(
      Math.max(36.2, Math.min(39.0, baseTemp + (isCritical && idx >= 6 ? 0.4 : 0) + (wave > 0.4 ? 0.2 : -0.1))).toFixed(1)
    );

    return {
      timeLabel: formatHourLabel(t, offsetHours === 0),
      recordedAt: t.toISOString(),
      heartRate,
      systolicBp,
      diastolicBp,
      spo2,
      temperature,
    };
  });

  const first = points[0];
  const latest = points[points.length - 1];
  const hrDelta = latest.heartRate - first.heartRate;
  const bpDelta = latest.systolicBp - first.systolicBp;

  let clinicalStatus: 'CRITICAL' | 'WARNING' | 'STABLE' = 'STABLE';
  if (isCritical || latest.systolicBp >= 145 || latest.heartRate >= 105 || latest.spo2 <= 94) {
    clinicalStatus = 'CRITICAL';
  } else if (isHigh || latest.systolicBp >= 132 || latest.heartRate >= 94) {
    clinicalStatus = 'WARNING';
  }

  const clinicalNote =
    alertText ||
    (clinicalStatus === 'CRITICAL'
      ? 'Sinh hiệu biến động cao trong 6h gần nhất — cần theo dõi sát'
      : clinicalStatus === 'WARNING'
        ? 'Nhịp tim/huyết áp tăng nhẹ — tiếp tục theo dõi định kỳ'
        : 'Các chỉ số sinh hiệu ổn định trong giới hạn bình thường');

  return {
    points,
    latestHeartRate: latest.heartRate,
    latestSystolicBp: latest.systolicBp,
    latestDiastolicBp: latest.diastolicBp,
    latestSpo2: latest.spo2,
    latestTemp: latest.temperature,
    hrDelta,
    bpDelta,
    clinicalStatus,
    clinicalNote,
  };
}
