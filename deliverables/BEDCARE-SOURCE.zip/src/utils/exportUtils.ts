import ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface ExportColumn {
  header: string;
  key: string;
  width?: number;
}

export async function exportToExcel(
  fileName: string,
  sheetName: string,
  columns: ExportColumn[],
  rows: Array<Record<string, string | number | null | undefined>>
) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'BEDCARE';
  wb.created = new Date();
  const sheet = wb.addWorksheet(sheetName);

  sheet.columns = columns.map((c) => ({
    header: c.header,
    key: c.key,
    width: c.width ?? 22,
  }));

  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF0369A1' },
  };

  for (const row of rows) {
    sheet.addRow(row);
  }

  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

let cachedFontBase64: { normal: string; bold: string } | null = null;

async function loadDejaVuFonts(): Promise<{ normal: string; bold: string } | null> {
  if (cachedFontBase64) return cachedFontBase64;
  try {
    const [normRes, boldRes] = await Promise.all([
      fetch('/fonts/DejaVuSans.ttf'),
      fetch('/fonts/DejaVuSans-Bold.ttf'),
    ]);
    if (!normRes.ok || !boldRes.ok) return null;
    const [normBuf, boldBuf] = await Promise.all([normRes.arrayBuffer(), boldRes.arrayBuffer()]);
    cachedFontBase64 = {
      normal: arrayBufferToBase64(normBuf),
      bold: arrayBufferToBase64(boldBuf),
    };
    return cachedFontBase64;
  } catch {
    return null;
  }
}

export async function exportToPdf(
  fileName: string,
  title: string,
  subtitle: string,
  columns: ExportColumn[],
  rows: Array<Record<string, string | number | null | undefined>>
) {
  const doc = new jsPDF({ orientation: columns.length > 5 ? 'landscape' : 'portrait', unit: 'mm', format: 'a4' });
  const fonts = await loadDejaVuFonts();
  let fontName = 'helvetica';
  if (fonts) {
    doc.addFileToVFS('DejaVuSans.ttf', fonts.normal);
    doc.addFont('DejaVuSans.ttf', 'DejaVuSans', 'normal');
    doc.addFileToVFS('DejaVuSans-Bold.ttf', fonts.bold);
    doc.addFont('DejaVuSans-Bold.ttf', 'DejaVuSans', 'bold');
    fontName = 'DejaVuSans';
    doc.setFont('DejaVuSans', 'bold');
  }

  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(title, 14, 16);

  if (fonts) doc.setFont('DejaVuSans', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`${subtitle} · Xuất lúc ${new Date().toLocaleString('vi-VN')}`, 14, 22);

  autoTable(doc, {
    startY: 27,
    head: [columns.map((c) => c.header)],
    body: rows.map((r) => columns.map((c) => String(r[c.key] ?? '—'))),
    styles: {
      font: fontName,
      fontSize: 8.5,
      cellPadding: 2.5,
    },
    headStyles: {
      fillColor: [3, 105, 161],
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
  });

  doc.save(fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`);
}

export function escapeCsvCell(value: string | number | null | undefined): string {
  const str = String(value ?? '');
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function buildCsvString(
  columns: ExportColumn[],
  rows: Array<Record<string, string | number | null | undefined>>
): string {
  const headerLine = columns.map((c) => escapeCsvCell(c.header)).join(',');
  const dataLines = rows.map((r) => columns.map((c) => escapeCsvCell(r[c.key])).join(','));
  return '\uFEFF' + [headerLine, ...dataLines].join('\r\n');
}

export function exportToCsv(
  fileName: string,
  columns: ExportColumn[],
  rows: Array<Record<string, string | number | null | undefined>>
) {
  const csv = buildCsvString(columns, rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName.endsWith('.csv') ? fileName : `${fileName}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export async function exportHandoverPdf(
  fileName: string,
  filterSummary: string,
  columns: ExportColumn[],
  rows: Array<Record<string, string | number | null | undefined>>
) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const fonts = await loadDejaVuFonts();
  let fontName = 'helvetica';
  if (fonts) {
    doc.addFileToVFS('DejaVuSans.ttf', fonts.normal);
    doc.addFont('DejaVuSans.ttf', 'DejaVuSans', 'normal');
    doc.addFileToVFS('DejaVuSans-Bold.ttf', fonts.bold);
    doc.addFont('DejaVuSans-Bold.ttf', 'DejaVuSans', 'bold');
    fontName = 'DejaVuSans';
    doc.setFont('DejaVuSans', 'bold');
  }

  doc.setFontSize(14);
  doc.setTextColor(12, 74, 110);
  doc.text('PHIẾU BÀN GIAO CA ĐIỀU DƯỠNG — BỆNH NHÂN NỘI TRÚ', 14, 15);

  if (fonts) doc.setFont('DejaVuSans', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`${filterSummary} · Xuất lúc ${new Date().toLocaleString('vi-VN')}`, 14, 21);

  autoTable(doc, {
    startY: 26,
    head: [columns.map((c) => c.header)],
    body: rows.map((r) => columns.map((c) => String(r[c.key] ?? '—'))),
    styles: {
      font: fontName,
      fontSize: 8,
      cellPadding: 2.4,
      textColor: [30, 41, 59],
    },
    headStyles: {
      font: fontName,
      fillColor: [3, 105, 161],
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
  });

  const finalY = (doc as unknown as { lastAutoTable?: { finalY?: number } }).lastAutoTable?.finalY ?? 150;
  const sigY = Math.min(finalY + 12, 182);
  if (fonts) doc.setFont('DejaVuSans', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text('Điều dưỡng giao ca (Ký, ghi rõ họ tên)', 40, sigY);
  doc.text('Điều dưỡng nhận ca (Ký, ghi rõ họ tên)', 195, sigY);

  doc.save(fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`);
}

export async function parseSpreadsheetFile(file: File): Promise<{
  headers: string[];
  rows: Array<Record<string, string>>;
}> {
  const lower = file.name.toLowerCase();
  if (lower.endsWith('.csv')) {
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length === 0) return { headers: [], rows: [] };
    const splitCsv = (line: string) =>
      line.split(',').map((cell) => cell.trim().replace(/^"|"$/g, ''));
    const headers = splitCsv(lines[0]);
    const rows = lines.slice(1).map((line) => {
      const vals = splitCsv(line);
      const obj: Record<string, string> = {};
      headers.forEach((h, idx) => {
        obj[h] = vals[idx] ?? '';
      });
      return obj;
    });
    return { headers, rows };
  }

  const wb = new ExcelJS.Workbook();
  const buf = await file.arrayBuffer();
  await wb.xlsx.load(buf);
  const sheet = wb.worksheets[0];
  if (!sheet) return { headers: [], rows: [] };

  const headers: string[] = [];
  const rows: Array<Record<string, string>> = [];
  sheet.eachRow((row, rowNumber) => {
    const values = (row.values as Array<unknown>).slice(1).map((v) => String(v ?? '').trim());
    if (rowNumber === 1) {
      values.forEach((h, idx) => headers.push(h || `Cột ${idx + 1}`));
    } else if (values.some((v) => v.length > 0)) {
      const obj: Record<string, string> = {};
      headers.forEach((h, idx) => {
        obj[h] = values[idx] ?? '';
      });
      rows.push(obj);
    }
  });
  return { headers, rows };
}
