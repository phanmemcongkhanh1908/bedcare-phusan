import {
  Activity,
  ArrowLeftRight,
  BarChart3,
  BedDouble,
  Bell,
  Building2,
  CalendarClock,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  ClipboardList,
  Clock,
  DatabaseBackup,
  DoorOpen,
  HardDrive,
  HelpCircle,
  LogOut,
  Menu,
  Network,
  Search,
  Settings,
  Sparkles,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import type { UserRole } from '../types/bedcare';
import { ROLE_LABELS } from '../utils/formatters';

export type ScreenId =
  | 'dashboard'
  | 'departments'
  | 'rooms'
  | 'beds'
  | 'registrations'
  | 'reservations'
  | 'waitlist'
  | 'inpatients'
  | 'admissions'
  | 'extensions'
  | 'transfers'
  | 'discharge'
  | 'cleaning'
  | 'alerts'
  | 'reports'
  | 'users'
  | 'devices'
  | 'sync'
  | 'backup'
  | 'settings';

export interface NavItem {
  id: ScreenId;
  label: string;
  group: string;
  roles: UserRole[];
  icon: typeof Activity;
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Tổng quan công suất', group: 'Điều phối Giường bệnh', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: Activity },
  { id: 'beds', label: 'Sơ đồ giường bệnh', group: 'Điều phối Giường bệnh', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: BedDouble },
  { id: 'alerts', label: 'Cảnh báo & Nhắc việc', group: 'Điều phối Giường bệnh', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: Bell },
  { id: 'cleaning', label: 'Vệ sinh giường', group: 'Điều phối Giường bệnh', roles: ['SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'], icon: Sparkles },

  { id: 'registrations', label: 'Đăng ký trước', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'], icon: ClipboardList },
  { id: 'reservations', label: 'Giữ chỗ giường/phòng', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'], icon: CalendarClock },
  { id: 'waitlist', label: 'Danh sách chờ giường', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'], icon: Clock },
  { id: 'admissions', label: 'Tiếp nhận', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'], icon: UserCheck },
  { id: 'inpatients', label: 'Bệnh nhân đang nằm', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: Users },
  { id: 'extensions', label: 'Gia hạn ngày giường', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'], icon: ClipboardCheck },
  { id: 'transfers', label: 'Điều chuyển giường', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'], icon: ArrowLeftRight },
  { id: 'discharge', label: 'Xuất viện', group: 'Theo dõi Bệnh nhân', roles: ['SUPER_ADMIN', 'ADMIN', 'WARD_STAFF'], icon: LogOut },

  { id: 'reports', label: 'Báo cáo & Thống kê', group: 'Hồ sơ Y tế & Báo cáo', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: BarChart3 },
  { id: 'departments', label: 'Tổng hợp theo Khoa', group: 'Hồ sơ Y tế & Báo cáo', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: Building2 },
  { id: 'rooms', label: 'Tổng hợp theo Phòng', group: 'Hồ sơ Y tế & Báo cáo', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF', 'EXECUTIVE'], icon: DoorOpen },

  { id: 'settings', label: 'Danh mục Quản trị', group: 'Quản trị Hệ thống', roles: ['SUPER_ADMIN', 'ADMIN'], icon: Settings },
  { id: 'users', label: 'Tài khoản & Phân quyền', group: 'Quản trị Hệ thống', roles: ['SUPER_ADMIN', 'ADMIN'], icon: Users },
  { id: 'devices', label: 'Quản lý thiết bị P2P', group: 'Quản trị Hệ thống', roles: ['SUPER_ADMIN', 'ADMIN'], icon: HardDrive },
  { id: 'sync', label: 'Đồng bộ & Đồng thuận', group: 'Quản trị Hệ thống', roles: ['SUPER_ADMIN', 'ADMIN', 'CASHIER', 'WARD_STAFF'], icon: Network },
  { id: 'backup', label: 'Sao lưu & Phục hồi', group: 'Quản trị Hệ thống', roles: ['SUPER_ADMIN', 'ADMIN'], icon: DatabaseBackup },
];

interface LayoutShellProps {
  activeScreen: ScreenId;
  onNavigate: (id: ScreenId) => void;
  user: { full_name: string; username: string; role: UserRole; department_id?: string | null };
  activeNodeName: string;
  activeNodeId: string;
  alertCount: number;
  globalSearch: string;
  onGlobalSearchChange: (v: string) => void;
  onOpenHelp?: () => void;
  onLogout: () => void;
  children: ReactNode;
}

export function LayoutShell({
  activeScreen,
  onNavigate,
  user,
  activeNodeName,
  activeNodeId,
  alertCount,
  globalSearch,
  onGlobalSearchChange,
  onOpenHelp,
  onLogout,
  children,
}: LayoutShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const allowedItems = NAV_ITEMS.filter((item) => item.roles.includes(user.role));
  const groups = Array.from(new Set(allowedItems.map((i) => i.group)));
  const currentItem = NAV_ITEMS.find((i) => i.id === activeScreen);

  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    'Điều phối Giường bệnh': true,
    'Theo dõi Bệnh nhân': true,
    'Hồ sơ Y tế & Báo cáo': false,
    'Quản trị Hệ thống': true,
  });

  useEffect(() => {
    if (currentItem?.group) {
      setExpandedGroups((prev) => ({ ...prev, [currentItem.group]: true }));
    }
  }, [currentItem?.group]);

  const toggleGroup = (grp: string) => {
    setExpandedGroups((prev) => ({ ...prev, [grp]: !prev[grp] }));
  };

  const sidebarContent = (
    <div className="flex h-full flex-col bg-white border-r border-slate-200">
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
        <div>
          <span className="text-lg font-bold tracking-tight text-sky-800 whitespace-nowrap">
            BEDCARE
          </span>
          <p className="text-xs text-slate-500 mt-0.5 truncate max-w-[190px]">
            {activeNodeName}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          aria-label="Đóng thanh điều hướng"
          className="lg:hidden rounded p-1.5 text-slate-500 hover:bg-slate-100"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-2.5" aria-label="Điều hướng chính">
        {groups.map((grp) => {
          const itemsInGroup = allowedItems.filter((i) => i.group === grp);
          const isOpen = expandedGroups[grp] ?? true;
          const hasActive = itemsInGroup.some((i) => i.id === activeScreen);
          return (
            <div key={grp} className="rounded-lg border border-slate-100 bg-slate-50/40 p-1">
              <button
                type="button"
                onClick={() => toggleGroup(grp)}
                aria-expanded={isOpen}
                className={`w-full flex items-center justify-between px-2.5 py-2 text-left text-xs font-semibold rounded-md transition-colors ${
                  hasActive ? 'text-sky-800' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span className="truncate">{grp}</span>
                {isOpen ? (
                  <ChevronDown className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                ) : (
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                )}
              </button>
              {isOpen && (
                <div className="mt-0.5 space-y-0.5">
                  {itemsInGroup.map((item) => {
                    const Icon = item.icon;
                    const active = item.id === activeScreen;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          onNavigate(item.id);
                          setMobileOpen(false);
                        }}
                        className={`w-full flex items-center justify-between gap-2 rounded-md px-2.5 py-2 text-left text-sm font-medium transition-colors ${
                          active
                            ? 'bg-sky-100/80 text-sky-900'
                            : 'text-slate-700 hover:bg-white hover:text-slate-900'
                        }`}
                      >
                        <span className="flex items-center gap-2.5 min-w-0">
                          <Icon
                            className={`h-4 w-4 shrink-0 ${
                              active ? 'text-sky-700' : 'text-slate-400'
                            }`}
                          />
                          <span className="truncate">{item.label}</span>
                        </span>
                        {item.id === 'alerts' && alertCount > 0 && (
                          <span className="font-mono tabular-nums text-xs font-semibold text-rose-700">
                            {alertCount}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="border-t border-slate-200 p-4 space-y-2.5">
        <div className="text-xs text-slate-500 space-y-0.5">
          <div className="font-semibold text-slate-800 truncate">{user.full_name}</div>
          <div className="truncate">{ROLE_LABELS[user.role]}</div>
          <div className="font-mono text-[11px] text-slate-400 truncate">{activeNodeId}</div>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Đăng xuất</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-[272px] shrink-0 sticky top-0 h-screen no-print">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative w-[276px] max-w-[85vw] h-full z-10">
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 lg:px-8 py-3 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Mở menu điều hướng"
              className="lg:hidden rounded-md p-2 text-slate-600 hover:bg-slate-100"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-400 hidden sm:inline whitespace-nowrap">
                {currentItem?.group}
              </span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <h1 className="text-base font-semibold text-slate-900 truncate">
                {currentItem?.label || 'BEDCARE'}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="relative hidden sm:block">
              <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={globalSearch}
                onChange={(e) => onGlobalSearchChange(e.target.value)}
                placeholder="Tìm BN, mã giường, phòng..."
                aria-label="Tìm kiếm nhanh toàn hệ thống"
                className="w-64 lg:w-72 rounded-md border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-sm text-slate-800 placeholder:text-slate-400 focus:border-sky-600 focus:bg-white focus:outline-none"
              />
            </div>

            <button
              type="button"
              onClick={() => onNavigate('alerts')}
              aria-label={`Xem cảnh báo (${alertCount})`}
              className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <Bell className={`h-3.5 w-3.5 ${alertCount > 0 ? 'text-rose-600' : 'text-slate-500'}`} />
              <span>Cảnh báo</span>
              <span className="font-mono tabular-nums font-semibold text-slate-900">
                {alertCount}
              </span>
            </button>

            {onOpenHelp && (
              <button
                type="button"
                onClick={onOpenHelp}
                aria-label="Mở Trung tâm Hướng dẫn"
                className="flex items-center gap-1.5 rounded-md border border-sky-200 bg-sky-50 px-3 py-1.5 text-xs font-medium text-sky-800 hover:bg-sky-100 whitespace-nowrap"
              >
                <HelpCircle className="h-3.5 w-3.5 text-sky-700" />
                <span className="hidden sm:inline">Hướng dẫn</span>
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-8 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
